"use strict";
(self["webpackChunkwebmonitor2"] = self["webpackChunkwebmonitor2"] || []).push([["src_app_widgets_label-widget_label-widget_module_ts"],{

/***/ 76950:
/*!****************************************************************!*\
  !*** ./src/app/widgets/label-widget/label-widget.component.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LabelWidgetComponent": () => (/* binding */ LabelWidgetComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _core_database_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core/database.service */ 67084);
/* harmony import */ var _shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../shared/widget/widget.component */ 81522);
/* harmony import */ var _shared_date_range_form_date_range_form_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../shared/date-range-form/date-range-form.component */ 63747);
/* harmony import */ var _shared_fill_run_ls_form_fill_run_ls_form_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/fill-run-ls-form/fill-run-ls-form.component */ 49207);





class LabelWidgetComponent {
    constructor(dbService) {
        this.dbService = dbService;
        this.value = undefined;
        this.queryURL = undefined;
        this.queryBody = undefined;
        this.parseValue = undefined;
        this.info = {
            timestamp: (new Date()).toISOString()
        };
    }
    set config(newConfig) {
        this._config = newConfig;
    }
    get config() {
        return this._config;
    }
    ngOnInit() {
        if (!this.config.hasOwnProperty('wrapper')) {
            this.config['wrapper'] = {};
        }
        this.config['wrapper'] = Object.assign(this.config['wrapper'], {
            controlsEnabled: true,
            infoEnabled: true,
            startEnabled: true,
            refreshEnabled: true,
            optionsEnabled: true
        });
        this.resolveQuery(this.config['widget']);
        this.setValueParser(this.config['widget']);
        this.refresh();
    }
    resolveQuery(cfg) {
        switch (cfg['aggregation']) {
            case 'count': {
                this.queryURL = cfg.path + '/_count';
                this.queryBody = undefined;
                break;
            }
            case 'avg': {
            }
            case 'newest': {
            }
            default: {
            }
        }
    }
    setValueParser(cfg) {
        switch (cfg['aggregation']) {
            case 'count': {
                this.parseValue = (response) => {
                    return response['count'];
                };
                break;
            }
            case 'avg': {
            }
            case 'newest': {
            }
            default: {
                this.parseValue = (response) => response;
            }
        }
    }
    refresh() {
        if (!this.queryURL) {
            console.error('Empty query URL.');
        }
        this.dbService.query(this.queryURL, this.queryBody)
            .subscribe(r => this.value = this.parseValue(r));
    }
    onTimerTick() {
        this.info = Object.assign({}, this.info, {
            timestamp: (new Date()).toISOString()
        });
    }
    query(range) {
        console.log(range);
    }
}
LabelWidgetComponent.ɵfac = function LabelWidgetComponent_Factory(t) { return new (t || LabelWidgetComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_core_database_service__WEBPACK_IMPORTED_MODULE_0__.DatabaseService)); };
LabelWidgetComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({ type: LabelWidgetComponent, selectors: [["wm-label-widget"]], inputs: { config: "config" }, decls: 11, vars: 6, consts: [[3, "config", "info", "timer", "refresh"], [1, "widget-options"], [1, "widget-queries"], [3, "query"], [1, "widget-content"], [1, "main-text", "text-primary"], [1, "sub-text"]], template: function LabelWidgetComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "wm-widget", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("timer", function LabelWidgetComponent_Template_wm_widget_timer_0_listener() { return ctx.onTimerTick(); })("refresh", function LabelWidgetComponent_Template_wm_widget_refresh_0_listener() { return ctx.refresh(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2, "label widget options");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 2)(4, "wm-date-range-form", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("query", function LabelWidgetComponent_Template_wm_date_range_form_query_4_listener($event) { return ctx.query($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "wm-fill-run-ls-form", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("query", function LabelWidgetComponent_Template_wm_fill_run_ls_form_query_5_listener($event) { return ctx.query($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "div", 4)(7, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("config", ctx.config ? ctx.config.wrapper : undefined)("info", ctx.info);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate3"](" ", ctx.config.widget.pre, "", ctx.value, "", ctx.config.widget.post, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", ctx.config.widget.sub, " ");
    } }, dependencies: [_shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_1__.WidgetComponent, _shared_date_range_form_date_range_form_component__WEBPACK_IMPORTED_MODULE_2__.DateRangeFormComponent, _shared_fill_run_ls_form_fill_run_ls_form_component__WEBPACK_IMPORTED_MODULE_3__.FillRunLsFormComponent], styles: [".main-text[_ngcontent-%COMP%] {\r\n    width: 100%;\r\n    text-align: center;\r\n    font-size: 36pt;\r\n    line-height: normal;\r\n    font-weight: bold;\r\n}\r\n\r\n.sub-text[_ngcontent-%COMP%] {\r\n    width: 100%;\r\n    text-align: center;\r\n    font-size: 16pt;\r\n    line-height: 16pt;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxhYmVsLXdpZGdldC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksV0FBVztJQUNYLGtCQUFrQjtJQUNsQixlQUFlO0lBQ2YsbUJBQW1CO0lBQ25CLGlCQUFpQjtBQUNyQjs7QUFFQTtJQUNJLFdBQVc7SUFDWCxrQkFBa0I7SUFDbEIsZUFBZTtJQUNmLGlCQUFpQjtBQUNyQiIsImZpbGUiOiJsYWJlbC13aWRnZXQuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYWluLXRleHQge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDM2cHQ7XHJcbiAgICBsaW5lLWhlaWdodDogbm9ybWFsO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuXHJcbi5zdWItdGV4dCB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtc2l6ZTogMTZwdDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxNnB0O1xyXG59XHJcbiJdfQ== */"] });


/***/ }),

/***/ 4359:
/*!*************************************************************!*\
  !*** ./src/app/widgets/label-widget/label-widget.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LabelWidgetModule": () => (/* binding */ LabelWidgetModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../shared/shared.module */ 44466);
/* harmony import */ var _label_widget_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./label-widget.component */ 76950);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);




class LabelWidgetModule {
}
LabelWidgetModule.entry = _label_widget_component__WEBPACK_IMPORTED_MODULE_1__.LabelWidgetComponent;
LabelWidgetModule.ɵfac = function LabelWidgetModule_Factory(t) { return new (t || LabelWidgetModule)(); };
LabelWidgetModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: LabelWidgetModule });
LabelWidgetModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
        _shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](LabelWidgetModule, { declarations: [_label_widget_component__WEBPACK_IMPORTED_MODULE_1__.LabelWidgetComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
        _shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule] }); })();


/***/ })

}]);
//# sourceMappingURL=src_app_widgets_label-widget_label-widget_module_ts.js.map