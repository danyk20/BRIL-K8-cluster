"use strict";
(self["webpackChunkwebmonitor2"] = self["webpackChunkwebmonitor2"] || []).push([["src_app_widgets_event-bus-test-widget_event-bus-test-widget_module_ts"],{

/***/ 2442:
/*!**********************************************************************************!*\
  !*** ./src/app/widgets/event-bus-test-widget/event-bus-test-widget.component.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EventBusTestWidgetComponent": () => (/* binding */ EventBusTestWidgetComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var app_core_event_bus_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/core/event-bus.service */ 40699);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 2508);



class EventBusTestWidgetComponent {
    constructor(eventBus) {
        this.eventBus = eventBus;
        this.events = '';
        this.eventBus.events$.subscribe(event => {
            this.events += JSON.stringify(event) + '\n';
        });
    }
    ngOnInit() {
    }
}
EventBusTestWidgetComponent.ɵfac = function EventBusTestWidgetComponent_Factory(t) { return new (t || EventBusTestWidgetComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](app_core_event_bus_service__WEBPACK_IMPORTED_MODULE_0__.EventBusService)); };
EventBusTestWidgetComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: EventBusTestWidgetComponent, selectors: [["wm-event-bus-test-widget"]], decls: 1, vars: 1, consts: [[3, "ngModel", "ngModelChange"]], template: function EventBusTestWidgetComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "textarea", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function EventBusTestWidgetComponent_Template_textarea_ngModelChange_0_listener($event) { return ctx.events = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.events);
    } }, dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgModel], styles: ["textarea[_ngcontent-%COMP%] {\r\n    width: 100%;\r\n    height: 100%;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImV2ZW50LWJ1cy10ZXN0LXdpZGdldC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksV0FBVztJQUNYLFlBQVk7QUFDaEIiLCJmaWxlIjoiZXZlbnQtYnVzLXRlc3Qtd2lkZ2V0LmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyJ0ZXh0YXJlYSB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogMTAwJTtcclxufVxyXG4iXX0= */"] });


/***/ }),

/***/ 4794:
/*!*******************************************************************************!*\
  !*** ./src/app/widgets/event-bus-test-widget/event-bus-test-widget.module.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EventBusTestWidgetModule": () => (/* binding */ EventBusTestWidgetModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/shared/shared.module */ 44466);
/* harmony import */ var _event_bus_test_widget_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./event-bus-test-widget.component */ 2442);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);




class EventBusTestWidgetModule {
}
EventBusTestWidgetModule.entry = _event_bus_test_widget_component__WEBPACK_IMPORTED_MODULE_1__.EventBusTestWidgetComponent;
EventBusTestWidgetModule.ɵfac = function EventBusTestWidgetModule_Factory(t) { return new (t || EventBusTestWidgetModule)(); };
EventBusTestWidgetModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: EventBusTestWidgetModule });
EventBusTestWidgetModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
        app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](EventBusTestWidgetModule, { declarations: [_event_bus_test_widget_component__WEBPACK_IMPORTED_MODULE_1__.EventBusTestWidgetComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
        app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule] }); })();


/***/ })

}]);
//# sourceMappingURL=src_app_widgets_event-bus-test-widget_event-bus-test-widget_module_ts.js.map