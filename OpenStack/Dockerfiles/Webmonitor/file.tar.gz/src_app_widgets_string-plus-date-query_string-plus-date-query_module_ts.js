"use strict";
(self["webpackChunkwebmonitor2"] = self["webpackChunkwebmonitor2"] || []).push([["src_app_widgets_string-plus-date-query_string-plus-date-query_module_ts"],{

/***/ 95375:
/*!************************************************************************************!*\
  !*** ./src/app/widgets/string-plus-date-query/string-plus-date-query.component.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StringPlusDateQueryComponent": () => (/* binding */ StringPlusDateQueryComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var app_core_event_bus_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/core/event-bus.service */ 40699);
/* harmony import */ var _shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../shared/widget/widget.component */ 81522);
/* harmony import */ var _shared_string_plus_date_form_string_plus_date_form_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../shared/string-plus-date-form/string-plus-date-form.component */ 37054);




class StringPlusDateQueryComponent {
    constructor(eventBus) {
        this.eventBus = eventBus;
    }
    ngOnInit() {
        this.config = this.config || {};
        if (!this.config.hasOwnProperty('widget')) {
            this.config['widget'] = {};
        }
        this.key = this.config['widget']['key'];
        this.label = this.config['widget']['label'];
    }
    query(event) {
        const ebEvent = { type: 'string_plus_date_query', payload: event };
        this.eventBus.emit(this.config['widget']['channel'], ebEvent);
    }
}
StringPlusDateQueryComponent.ɵfac = function StringPlusDateQueryComponent_Factory(t) { return new (t || StringPlusDateQueryComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](app_core_event_bus_service__WEBPACK_IMPORTED_MODULE_0__.EventBusService)); };
StringPlusDateQueryComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({ type: StringPlusDateQueryComponent, selectors: [["wm-string-plus-date-query-widget"]], inputs: { config: "config" }, decls: 3, vars: 3, consts: [[3, "config"], [1, "widget-content"], [3, "key", "label", "query"]], template: function StringPlusDateQueryComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "wm-widget", 0)(1, "div", 1)(2, "wm-string-plus-date-form", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("query", function StringPlusDateQueryComponent_Template_wm_string_plus_date_form_query_2_listener($event) { return ctx.query($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("config", ctx.config ? ctx.config.wrapper : undefined);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("key", ctx.key)("label", ctx.label);
    } }, dependencies: [_shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_1__.WidgetComponent, _shared_string_plus_date_form_string_plus_date_form_component__WEBPACK_IMPORTED_MODULE_2__.StringPlusDateFormComponent], encapsulation: 2 });


/***/ }),

/***/ 3248:
/*!*********************************************************************************!*\
  !*** ./src/app/widgets/string-plus-date-query/string-plus-date-query.module.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StringPlusDateQueryModule": () => (/* binding */ StringPlusDateQueryModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/shared/shared.module */ 44466);
/* harmony import */ var _string_plus_date_query_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./string-plus-date-query.component */ 95375);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);




class StringPlusDateQueryModule {
}
StringPlusDateQueryModule.entry = _string_plus_date_query_component__WEBPACK_IMPORTED_MODULE_1__.StringPlusDateQueryComponent;
StringPlusDateQueryModule.ɵfac = function StringPlusDateQueryModule_Factory(t) { return new (t || StringPlusDateQueryModule)(); };
StringPlusDateQueryModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: StringPlusDateQueryModule });
StringPlusDateQueryModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
        app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](StringPlusDateQueryModule, { declarations: [_string_plus_date_query_component__WEBPACK_IMPORTED_MODULE_1__.StringPlusDateQueryComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
        app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule] }); })();


/***/ })

}]);
//# sourceMappingURL=src_app_widgets_string-plus-date-query_string-plus-date-query_module_ts.js.map