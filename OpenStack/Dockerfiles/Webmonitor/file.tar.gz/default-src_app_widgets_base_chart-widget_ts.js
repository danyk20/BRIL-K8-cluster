(self["webpackChunkwebmonitor2"] = self["webpackChunkwebmonitor2"] || []).push([["default-src_app_widgets_base_chart-widget_ts"],{

/***/ 99593:
/*!***************************************!*\
  !*** ./src/app/shared/chart-utils.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "buttonDownloadCsv": () => (/* binding */ buttonDownloadCsv),
/* harmony export */   "buttonDownloadImage": () => (/* binding */ buttonDownloadImage),
/* harmony export */   "configureDefaultLayout": () => (/* binding */ configureDefaultLayout),
/* harmony export */   "detectWebGLContext": () => (/* binding */ detectWebGLContext),
/* harmony export */   "disableNavigation2d": () => (/* binding */ disableNavigation2d),
/* harmony export */   "getDefaultConfig": () => (/* binding */ getDefaultConfig),
/* harmony export */   "getDefaultLayout": () => (/* binding */ getDefaultLayout),
/* harmony export */   "getLegendConfig": () => (/* binding */ getLegendConfig),
/* harmony export */   "makeDefaultReflowFunction": () => (/* binding */ makeDefaultReflowFunction),
/* harmony export */   "makeQueryRangeFromStrings": () => (/* binding */ makeQueryRangeFromStrings),
/* harmony export */   "makeQueryRangeFromZoomEvent": () => (/* binding */ makeQueryRangeFromZoomEvent),
/* harmony export */   "makeSeparatorLines": () => (/* binding */ makeSeparatorLines),
/* harmony export */   "makeTooltipText": () => (/* binding */ makeTooltipText),
/* harmony export */   "parseStringTimestamp": () => (/* binding */ parseStringTimestamp),
/* harmony export */   "parseUNIXTimestamp": () => (/* binding */ parseUNIXTimestamp),
/* harmony export */   "setAutorange": () => (/* binding */ setAutorange),
/* harmony export */   "setXRange": () => (/* binding */ setXRange),
/* harmony export */   "subscribeReflow": () => (/* binding */ subscribeReflow)
/* harmony export */ });
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! file-saver */ 65226);
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(file_saver__WEBPACK_IMPORTED_MODULE_0__);

const buttonDownloadImage = {
    name: 'toImage',
    title: 'Download plot as a png',
    icon: Plotly.Icons.camera,
    click: function (gd) {
        const opts = {
            format: 'png',
            width: 900,
            height: 600
        };
        Plotly.downloadImage(gd, opts);
    }
};
const buttonDownloadCsv = {
    name: "downloadCsv",
    title: "Download plot as csv",
    icon: Plotly.Icons.disk,
    click: function (gd) {
        let extraKeys = [];
        let columnNames = [];
        let legendNameAvailable = false;
        let _extraAvailable = false;
        let errorYAvailable = false;
        let zAxisAvailable = false;
        if (gd.layout.xaxis.title !== undefined) {
            columnNames.push(gd.layout.xaxis.title.text);
        }
        else {
            columnNames.push("xaxis");
        }
        if (gd.layout.yaxis.title !== undefined) {
            columnNames.push(gd.layout.yaxis.title.text);
        }
        else {
            columnNames.push("yaxis");
        }
        if (gd.data[0].z !== undefined && gd.data[0].z.length) {
            zAxisAvailable = true;
            columnNames[0] = columnNames[1] + ' \\ ' + columnNames[0];
            delete columnNames[1];
            gd.data[0].x.forEach((xvalue, i) => {
                columnNames[i + 1] = xvalue;
            });
        }
        if ("error_y" in gd.data[0]) {
            columnNames.push("error_y");
            errorYAvailable = true;
        }
        if ("name" in gd.data[0]) {
            columnNames.push("legendNames");
            legendNameAvailable = true;
        }
        if ("_extra" in gd.data[0]) {
            extraKeys = Object.keys(gd.data[0]._extra);
            const index = extraKeys.indexOf("errors", 0);
            if (index > -1 && errorYAvailable) {
                extraKeys.splice(index, 1);
            }
            columnNames = columnNames.concat(extraKeys);
            _extraAvailable = true;
        }
        let csvData = [
            columnNames.join(","),
        ];
        if (gd.data[0].type === "heatmap") {
            gd.data[0].y.forEach((yvalue, i) => {
                let row = [yvalue];
                gd.data[0].z[i].forEach((zvalue, j) => {
                    row.push(zvalue);
                });
                csvData.push(row.join(","));
            });
        }
        else {
            gd.data[0].x.forEach((xvalue, i) => {
                gd.data.forEach(dataArray => {
                    let row = [dataArray.x[i], dataArray.y[i]];
                    if (zAxisAvailable)
                        row.push(dataArray.z[i]);
                    if (errorYAvailable)
                        row.push(dataArray.error_y.array[i]);
                    if (legendNameAvailable)
                        row.push(dataArray.name);
                    if (_extraAvailable) {
                        extraKeys.forEach((extraKey) => {
                            row.push(dataArray._extra[extraKey][i]);
                        });
                    }
                    csvData.push(row.join(","));
                });
            });
        }
        let blob = new Blob([csvData.join("\r\n")], { type: "text/csv" });
        (0,file_saver__WEBPACK_IMPORTED_MODULE_0__.saveAs)(blob, "export.csv");
    }
};
function getDefaultLayout() {
    return {
        margin: {
            b: 48,
            l: 60,
            r: 36,
            t: 12
        },
        showlegend: true,
        legend: {
            orientation: 'v',
            bgcolor: '#EAFAFF90',
            bordercolor: 'whitesmoke',
            borderwidth: 1
        },
        autosize: true
    };
}
function configureDefaultLayout(widget) {
    const layout = getDefaultLayout();
    const update = {
        xaxis: {
            title: "Date UTC",
            type: "date"
        },
        yaxis: {
            title: widget['yAxisTitle'],
            type: widget['yAxisScale'] || 'lin'
        },
        legend: getLegendConfig(widget['legend'])
    };
    if (widget['yAxis2Enabled']) {
        update['yaxis2'] = {
            title: widget['yAxis2Title'],
            type: widget['yAxisScale'] || 'lin',
            overlaying: 'y',
            side: 'right'
        };
    }
    if (widget['scientific']) {
        update['yaxis']['showexponent'] = 'all';
        update['yaxis']['exponentformat'] = 'E';
    }
    return Object.assign(layout, update);
}
function getLegendConfig(preset) {
    const common = {
        orientation: 'v',
        bgcolor: '#EAFAFFC0',
        bordercolor: 'whitesmoke',
        borderwidth: 1
    };
    let update;
    switch (preset) {
        case 'outside-left': {
            update = { x: -0.05, xanchor: 'right' };
            break;
        }
        case 'left': {
            update = { x: 0, xanchor: 'left' };
            break;
        }
        case 'outside-right': {
            update = { x: 1, xanchor: 'left', y: 0.97, yanchor: 'top' };
            break;
        }
        case 'right': {
            update = { x: 1, xanchor: 'right', y: 0.97, yanchor: 'top' };
            break;
        }
        case 'horizontal': {
            update = { orientation: 'h' };
            break;
        }
        default: {
            update = { x: 1, xanchor: 'left', y: 0.97, yanchor: 'top' };
        }
    }
    return Object.assign(common, update);
}
function getDefaultConfig() {
    return {
        modeBarButtonsToRemove: ['sendDataToCloud', 'lasso2d', 'toImage'],
        modeBarButtonsToAdd: [buttonDownloadImage, buttonDownloadCsv],
        displaylogo: false
    };
}
function disableNavigation2d(layout, config) {
    const xaxis = layout['xaxis'] = layout['xaxis'] || {};
    xaxis['fixedrange'] = true;
    xaxis['autorange'] = false;
    config['modeBarButtonsToRemove'] = [
        'zoom2d', 'pan2d', 'zoomIn2d', 'zoomOut2d', 'select2d'
    ].concat(config['modeBarButtonsToRemove']);
}
function makeDefaultReflowFunction(element) {
    return () => {
        setTimeout(() => {
            Plotly.relayout(element, { width: null, height: null });
        });
    };
}
function subscribeReflow(eventBus, reflow) {
    return eventBus.getEvents(0, 'global_reflow').subscribe(reflow);
}
function setAutorange(layout) {
    const xaxis = layout['xaxis'] = (layout['xaxis'] || {});
    const yaxis = layout['yaxis'] = (layout['yaxis'] || {});
    xaxis['autorange'] = true;
    xaxis['range'] = undefined;
    yaxis['autorange'] = true;
    yaxis['range'] = undefined;
    return { xaxis: xaxis, yaxis: yaxis };
}
function setXRange(layout, min, max) {
    const xaxis = layout['xaxis'] = (layout['xaxis'] || {});
    const newRange = [min, max];
    xaxis['range'] = newRange;
    xaxis['autorange'] = false;
    return { xaxis: xaxis };
}
function detectWebGLContext() {
    const canvas = document.createElement("canvas");
    const gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl");
    let detected = false;
    if (gl && gl instanceof WebGLRenderingContext) {
        detected = true;
    }
    canvas.remove();
    return detected;
}
function parseUNIXTimestamp(ts) {
    return new Date(ts * 1000);
}
function parseStringTimestamp(ts) {
    return new Date(ts);
}
function makeQueryRangeFromZoomEvent(event) {
    if (!event['xaxis.range[0]'] || !event['xaxis.range[1]']) {
        return undefined;
    }
    const min = event['xaxis.range[0]'] + 'Z';
    const max = event['xaxis.range[1]'] + 'Z';
    return {
        'from': new Date(min),
        'to': new Date(max),
        'tsFrom': (new Date(min)).getTime() / 1000,
        'tsTo': (new Date(max)).getTime() / 1000,
        'msecFrom': (new Date(min)).getTime(),
        'msecTo': (new Date(max)).getTime(),
        'strFrom': (new Date(min)).toISOString().split('.')[0] + 'Z',
        'strTo': (new Date(max)).toISOString().split('.')[0] + 'Z',
        'utc': true
    };
}
function makeQueryRangeFromStrings(min, max) {
    return {
        'from': new Date(min),
        'to': new Date(max),
        'tsFrom': (new Date(min)).getTime() / 1000,
        'tsTo': (new Date(max)).getTime() / 1000,
        'msecFrom': (new Date(min)).getTime(),
        'msecTo': (new Date(max)).getTime(),
        'strFrom': min,
        'strTo': max,
        'utc': true
    };
}
function getFieldChanges(chartData, fields) {
    const changes = [];
    chartData.forEach(series => {
        if (!series['_extra']) {
            return;
        }
        const perSeries = {};
        fields.forEach(field => {
            if (!series['_extra'][field.fieldname]) {
                return;
            }
            const values = series['_extra'][field.fieldname];
            const perField = [];
            values.forEach((v, i) => {
                if (i === 0) {
                    perField.push({
                        changedFrom: undefined,
                        changedTo: v,
                        index: i,
                        x: series.x[i],
                        x_ts: (new Date(series.x[i])).getTime()
                    });
                    return;
                }
                if (values[i - 1] !== v && typeof v != 'undefined') {
                    perField.push({
                        changedFrom: values[i - 1],
                        changedTo: v,
                        index: i,
                        x: series.x[i],
                        x_ts: (new Date(series.x[i])).getTime()
                    });
                }
            });
            perSeries[field.fieldname] = perField;
        });
        changes.push(perSeries);
    });
    return changes;
}
function filterGlobalFieldChanges(changes, fields) {
    function tsSort(a, b) {
        if (a.x_ts < b.x_ts) {
            return -1;
        }
        if (a.x_ts > b.x_ts) {
            return 1;
        }
        return 0;
    }
    ;
    const globalChanges = {};
    fields.forEach(field => {
        let fromAllSeries = [];
        changes.forEach(perSeries => {
            if (!perSeries[field.fieldname]) {
                return;
            }
            fromAllSeries = fromAllSeries.concat(perSeries[field.fieldname]);
        });
        fromAllSeries.sort(tsSort);
        const filtered = [];
        fromAllSeries.forEach(v => {
            if (!filtered.length) {
                filtered.push(v);
                return;
            }
            if (v['changedTo'] !== filtered[filtered.length - 1]['changedTo']) {
                filtered.push(v);
            }
        });
        if (filtered.length > 0 && filtered[0]['index'] === 0) {
            filtered.shift();
        }
        globalChanges[field.fieldname] = filtered;
    });
    return globalChanges;
}
function makeSeparatorLines(chartData, fields, aggregated = false) {
    if (aggregated) {
        fields = fields.filter(f => !f.excludeWhenAggregated);
    }
    const changes = getFieldChanges(chartData, fields);
    const globalChanges = filterGlobalFieldChanges(changes, fields);
    const shapes = [];
    const annotations = [];
    fields.forEach(field => {
        globalChanges[field.fieldname].forEach(change => {
            shapes.push({
                type: 'line',
                xref: 'x',
                yref: 'paper',
                x0: change['x'],
                x1: change['x'],
                y0: 0,
                y1: 1,
                line: {
                    color: field.lineColor,
                    width: field.lineWidth,
                    dash: field.lineDash
                }
            });
            annotations.push({
                xref: 'x',
                yref: 'paper',
                x: change['x'],
                xanchor: 'left',
                y: 1,
                yanchor: 'top',
                text: (field.text || '') + change['changedTo'],
                textangle: -90,
                showarrow: false
            });
        });
    });
    return { shapes: shapes, annotations: annotations };
}
function makeTooltipText(chartDataPoint, fields) {
    if (!fields || fields.length < 1) {
        return '';
    }
    return fields.map(f => {
        if (typeof chartDataPoint[f.fieldname] != 'undefined') {
            return (f.text || f.fieldname) + ': ' + chartDataPoint[f.fieldname];
        }
        else {
            return undefined;
        }
    }).filter(Boolean).join('<br>');
}


/***/ }),

/***/ 47397:
/*!**********************************************!*\
  !*** ./src/app/widgets/base/chart-widget.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChartWidget": () => (/* binding */ ChartWidget)
/* harmony export */ });
/* harmony import */ var app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/shared/chart-utils */ 99593);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 36646);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var app_core_event_bus_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! app/core/event-bus.service */ 40699);





const _c0 = ["plot"];
const _c1 = ["widgetWrapper"];
class ChartWidget {
    constructor(eventBus) {
        this.eventBus = eventBus;
        this.chartData = [];
        this.chartConfig = app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__.getDefaultConfig();
        this.tsToDate = app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__.parseStringTimestamp;
        this.tsToChartTimestamp = (ts) => ts;
        this.chartTimestampToTs = (ts) => ts;
        this.tsToMilliseconds = (ts) => this.tsToDate(ts).getTime();
        this.queryEventTypes = ['range_query', 'time_range_query', 'fill_run_ls_query'];
    }
    ngOnDestroy() {
        if (this.resizeEventSubs) {
            this.resizeEventSubs.unsubscribe();
        }
        if (this.queryEventSubs) {
            this.queryEventSubs.unsubscribe();
        }
    }
    ngOnInit(defaults) {
        this.wrapper = this.setupWrapper();
        this.widget = this.setupWidget(defaults);
        this.chartLayout = app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__.configureDefaultLayout(this.widget);
    }
    setupWrapper() {
        return this.config['wrapper'] = Object.assign({
            controlsEnabled: true,
            optionsEnabled: true,
            queriesEnabled: true,
            startEnabled: true,
            refreshEnabled: true
        }, this.config['wrapper'] || {});
    }
    setupWidget(defaults) {
        this.widget = this.config['widget'] = this.config['widget'] || {};
        if (defaults) {
            Object.keys(defaults).forEach(key => {
                if (!this.widget.hasOwnProperty(key)) {
                    this.widget[key] = defaults[key];
                }
            });
        }
        if (this.widget.timestampUNIX) {
            this.tsToDate = app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__.parseUNIXTimestamp;
            this.tsToChartTimestamp = (ts) => this.tsToDate(ts).toISOString();
            this.chartTimestampToTs = (ts) => (new Date(ts)).getTime() / 1000;
        }
        if (this.widget.hasOwnProperty('queryChannel')) {
            this.resubscribeQueryEvents();
        }
        return this.widget;
    }
    ngAfterViewInit() {
        Plotly.newPlot(this.plot.nativeElement, this.chartData, this.chartLayout, this.chartConfig);
        this.reflow = app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__.makeDefaultReflowFunction(this.plot.nativeElement);
        this.resizeEventSubs = app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__.subscribeReflow(this.eventBus, this.reflow);
        this.reflow();
    }
    resubscribeQueryEvents() {
        if (this.queryEventSubs) {
            this.queryEventSubs.unsubscribe();
        }
        const ch = this.widget.queryChannel;
        let obs;
        this.queryEventTypes.forEach(eventType => {
            if (obs) {
                obs = (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.merge)(obs, this.eventBus.getEvents(ch, eventType));
            }
            else {
                obs = this.eventBus.getEvents(ch, eventType);
            }
        });
        this.queryEventSubs = obs.subscribe(this.queryFromEvent.bind(this));
    }
    autorange() {
        const mod = app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__.setAutorange(this.plot.nativeElement['layout']);
        Plotly.relayout(this.plot.nativeElement, mod);
    }
    disableInteraction() {
        this.chartConfig['staticPlot'] = true;
        this.chartLayout['plot_bgcolor'] = 'whitesmoke';
        Plotly.react(this.plot.nativeElement, this.chartData, this.chartLayout, this.chartConfig);
    }
    enableInteraction() {
        this.chartConfig['staticPlot'] = false;
        this.chartLayout['plot_bgcolor'] = undefined;
        Plotly.react(this.plot.nativeElement, this.chartData, this.chartLayout, this.chartConfig);
    }
    updateFieldSeparators(relayout = false, aggregated = false) {
        if (!this.widget.fieldChangeSeparators) {
            return;
        }
        if (this.widget.fieldChangeSeparators.enabled) {
            const s = app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__.makeSeparatorLines(this.chartData, this.widget.fieldChangeSeparators.fields, aggregated);
            this.plot.nativeElement['layout']['shapes'] = s['shapes'];
            this.plot.nativeElement['layout']['annotations'] = s['annotations'];
        }
        else {
            this.plot.nativeElement['layout']['shapes'] = [];
            this.plot.nativeElement['layout']['annotations'] = [];
        }
        if (relayout) {
            Plotly.relayout(this.plot.nativeElement, this.chartLayout);
        }
    }
}
ChartWidget.ɵfac = function ChartWidget_Factory(t) { return new (t || ChartWidget)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](app_core_event_bus_service__WEBPACK_IMPORTED_MODULE_1__.EventBusService)); };
ChartWidget.ɵdir = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineDirective"]({ type: ChartWidget, viewQuery: function ChartWidget_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵviewQuery"](_c1, 7);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.plot = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.widgetComponent = _t.first);
    } }, inputs: { config: "config" } });


/***/ }),

/***/ 65226:
/*!*******************************************************!*\
  !*** ./node_modules/file-saver/dist/FileSaver.min.js ***!
  \*******************************************************/
/***/ (function(module, exports) {

var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;(function (a, b) {
  if (true) !(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_FACTORY__ = (b),
		__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
		(__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__),
		__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));else {}
})(this, function () {
  "use strict";

  function b(a, b) {
    return "undefined" == typeof b ? b = {
      autoBom: !1
    } : "object" != typeof b && (console.warn("Deprecated: Expected third argument to be a object"), b = {
      autoBom: !b
    }), b.autoBom && /^\s*(?:text\/\S*|application\/xml|\S*\/\S*\+xml)\s*;.*charset\s*=\s*utf-8/i.test(a.type) ? new Blob(["\uFEFF", a], {
      type: a.type
    }) : a;
  }

  function c(a, b, c) {
    var d = new XMLHttpRequest();
    d.open("GET", a), d.responseType = "blob", d.onload = function () {
      g(d.response, b, c);
    }, d.onerror = function () {
      console.error("could not download file");
    }, d.send();
  }

  function d(a) {
    var b = new XMLHttpRequest();
    b.open("HEAD", a, !1);

    try {
      b.send();
    } catch (a) {}

    return 200 <= b.status && 299 >= b.status;
  }

  function e(a) {
    try {
      a.dispatchEvent(new MouseEvent("click"));
    } catch (c) {
      var b = document.createEvent("MouseEvents");
      b.initMouseEvent("click", !0, !0, window, 0, 0, 0, 80, 20, !1, !1, !1, !1, 0, null), a.dispatchEvent(b);
    }
  }

  var f = "object" == typeof window && window.window === window ? window : "object" == typeof self && self.self === self ? self : "object" == typeof global && global.global === global ? global : void 0,
      a = f.navigator && /Macintosh/.test(navigator.userAgent) && /AppleWebKit/.test(navigator.userAgent) && !/Safari/.test(navigator.userAgent),
      g = f.saveAs || ("object" != typeof window || window !== f ? function () {} : "download" in HTMLAnchorElement.prototype && !a ? function (b, g, h) {
    var i = f.URL || f.webkitURL,
        j = document.createElement("a");
    g = g || b.name || "download", j.download = g, j.rel = "noopener", "string" == typeof b ? (j.href = b, j.origin === location.origin ? e(j) : d(j.href) ? c(b, g, h) : e(j, j.target = "_blank")) : (j.href = i.createObjectURL(b), setTimeout(function () {
      i.revokeObjectURL(j.href);
    }, 4E4), setTimeout(function () {
      e(j);
    }, 0));
  } : "msSaveOrOpenBlob" in navigator ? function (f, g, h) {
    if (g = g || f.name || "download", "string" != typeof f) navigator.msSaveOrOpenBlob(b(f, h), g);else if (d(f)) c(f, g, h);else {
      var i = document.createElement("a");
      i.href = f, i.target = "_blank", setTimeout(function () {
        e(i);
      });
    }
  } : function (b, d, e, g) {
    if (g = g || open("", "_blank"), g && (g.document.title = g.document.body.innerText = "downloading..."), "string" == typeof b) return c(b, d, e);
    var h = "application/octet-stream" === b.type,
        i = /constructor/i.test(f.HTMLElement) || f.safari,
        j = /CriOS\/[\d]+/.test(navigator.userAgent);

    if ((j || h && i || a) && "undefined" != typeof FileReader) {
      var k = new FileReader();
      k.onloadend = function () {
        var a = k.result;
        a = j ? a : a.replace(/^data:[^;]*;/, "data:attachment/file;"), g ? g.location.href = a : location = a, g = null;
      }, k.readAsDataURL(b);
    } else {
      var l = f.URL || f.webkitURL,
          m = l.createObjectURL(b);
      g ? g.location = m : location.href = m, g = null, setTimeout(function () {
        l.revokeObjectURL(m);
      }, 4E4);
    }
  });
  f.saveAs = g.saveAs = g,  true && (module.exports = g);
});

/***/ })

}]);
//# sourceMappingURL=default-src_app_widgets_base_chart-widget_ts.js.map