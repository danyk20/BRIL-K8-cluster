"use strict";
(self["webpackChunkwebmonitor2"] = self["webpackChunkwebmonitor2"] || []).push([["src_app_widgets_numeric-field-split_numeric-field-split_module_ts"],{

/***/ 41163:
/*!******************************************************************************!*\
  !*** ./src/app/widgets/numeric-field-split/numeric-field-split.component.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NumericFieldSplitComponent": () => (/* binding */ NumericFieldSplitComponent)
/* harmony export */ });
/* harmony import */ var app_widgets_numeric_field_numeric_field_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/widgets/numeric-field/numeric-field.component */ 82257);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @clr/angular */ 4151);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../shared/widget/widget.component */ 81522);
/* harmony import */ var _shared_date_range_form_date_range_form_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../shared/date-range-form/date-range-form.component */ 63747);
/* harmony import */ var _shared_fill_run_ls_form_fill_run_ls_form_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/fill-run-ls-form/fill-run-ls-form.component */ 49207);
/* harmony import */ var _shared_range_form_range_form_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/range-form/range-form.component */ 2199);
/* harmony import */ var _shared_quick_date_form_quick_date_form_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/quick-date-form/quick-date-form.component */ 94891);










function NumericFieldSplitComponent_form_3_Template(rf, ctx) { if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "form", 10)(1, "clr-checkbox-container")(2, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, "Annotations");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](4, "clr-checkbox-wrapper")(5, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](6, "Enable Annotations");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](7, "input", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function NumericFieldSplitComponent_form_3_Template_input_ngModelChange_7_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r9); const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r8.config.widget.fieldChangeSeparators.enabled = $event); })("ngModelChange", function NumericFieldSplitComponent_form_3_Template_input_ngModelChange_7_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r9); const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r10.updateFieldSeparators(true)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngModel", ctx_r1.config.widget.fieldChangeSeparators.enabled);
} }
function NumericFieldSplitComponent_div_5_Template(rf, ctx) { if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div")(1, "wm-quick-date-form", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("query", function NumericFieldSplitComponent_div_5_Template_wm_quick_date_form_query_1_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r12); const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r11.queryDateRange($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("options", ctx_r2.wi.quickDateOptions);
} }
function NumericFieldSplitComponent_wm_fill_run_ls_form_7_Template(rf, ctx) { if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "wm-fill-run-ls-form", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("query", function NumericFieldSplitComponent_wm_fill_run_ls_form_7_Template_wm_fill_run_ls_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r14); const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r13.queryFillRun($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("fillEnabled", true)("runEnabled", false)("lsEnabled", false);
} }
function NumericFieldSplitComponent_wm_fill_run_ls_form_8_Template(rf, ctx) { if (rf & 1) {
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "wm-fill-run-ls-form", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("query", function NumericFieldSplitComponent_wm_fill_run_ls_form_8_Template_wm_fill_run_ls_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r16); const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r15.queryFillRun($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("fillEnabled", false)("runEnabled", true)("lsEnabled", false);
} }
function NumericFieldSplitComponent_wm_range_form_9_Template(rf, ctx) { if (rf & 1) {
    const _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "wm-range-form", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("query", function NumericFieldSplitComponent_wm_range_form_9_Template_wm_range_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r19); const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r18.queryRange($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const rq_r17 = ctx.$implicit;
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("key", rq_r17.fieldname)("label", rq_r17.label)("database", ctx_r5.wi.database)("index", ctx_r5.wi.rangeRefresh.index)("queryDetectors", ctx_r5.config.wrapper.queryDetectors)("queryFits", ctx_r5.config.wrapper.queryFits);
} }
function NumericFieldSplitComponent_div_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](1, "div", 16, 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} }
function NumericFieldSplitComponent_div_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](1, "div", 18, 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](3, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](4, "Ratios");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](5, "div", 20, 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} }
class NumericFieldSplitComponent extends app_widgets_numeric_field_numeric_field_component__WEBPACK_IMPORTED_MODULE_0__.NumericFieldComponent {
    ngOnInit() {
        super.ngOnInit();
        this.wi = this.wi;
        this.queryParams = this.queryParams;
        this.queryParams.sources.forEach(s => {
            s.extraFields.push({ 'name': s.split.field });
        });
        this.flatFields = [];
        this.makeSeries();
    }
    setData(newData) {
        this.queryParams.sources.forEach((source, i) => {
            const splits = this.splitSourceHits(newData[i], source);
            source.split.values.forEach((splitVal, j) => {
                const extra = this.makeSourceExtraFields(splits[splitVal], source);
                const text = this.makeSourceText(splits[splitVal]);
                const x = this.makeSourceXValues(splits[splitVal], source);
                source.fields.forEach((field, k) => {
                    const series = this.series[i][j][k];
                    series.x = x;
                    series.text = text;
                    series._extra = extra;
                    series.y = this.makeFieldYValues(splits[splitVal], field);
                    if (field.errorField) {
                        series.error_y = this.makeFieldErrorBars(splits[splitVal], field);
                    }
                });
            });
        });
        this.updateFieldSeparators();
        Plotly.redraw(this.plot.nativeElement, this.chartData);
        this.autorange();
    }
    splitSourceHits(sourceData, source) {
        const splits = {};
        source.split.values.forEach(splitVal => {
            splits[splitVal] = [];
        });
        sourceData.forEach(hit => {
            const splitVal = Number(hit[source.split.field]);
            try {
                splits[splitVal].push(hit);
            }
            catch (e) {
                // pass indexes that are returned by query but not configured
            }
        });
        return splits;
    }
    updateLive() {
        throw new Error("Live update not implemented for numeric-field-split widget");
    }
    makeSeries() {
        this.chartData.length = 0;
        this.series.length = 0;
        this.queryParams.sources.forEach((source, i) => {
            const seriesOfCurrentSource = [];
            source.split.values.forEach((splitVal, j) => {
                const seriesOfCurrentSplit = [];
                source.fields.forEach((field, k) => {
                    const newSeries = {
                        x: [],
                        y: [],
                        _extra: [],
                        text: [],
                        name: (field.seriesName || field.name) + source.split.text + splitVal,
                        type: 'scatter',
                        mode: (this.wi.forceMarkers || field.forceMarkers) ? 'lines+markers' : 'auto',
                        line: { width: field['lineWidth'] || 1 },
                        visible: (field['hidden'] ? 'legendonly' : true)
                    };
                    if (field['yAxis'] === 2) {
                        newSeries['yaxis'] = 'y2';
                    }
                    seriesOfCurrentSplit.push(newSeries);
                    this.chartData.push(newSeries);
                });
                seriesOfCurrentSource.push(seriesOfCurrentSplit);
            });
            this.series.push(seriesOfCurrentSource);
        });
    }
    onLegendClick(event) { }
}
NumericFieldSplitComponent.ɵfac = /*@__PURE__*/ function () { let ɵNumericFieldSplitComponent_BaseFactory; return function NumericFieldSplitComponent_Factory(t) { return (ɵNumericFieldSplitComponent_BaseFactory || (ɵNumericFieldSplitComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetInheritedFactory"](NumericFieldSplitComponent)))(t || NumericFieldSplitComponent); }; }();
NumericFieldSplitComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({ type: NumericFieldSplitComponent, selectors: [["wm-numeric-field-split-widget"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵInheritDefinitionFeature"]], decls: 12, vars: 9, consts: [[3, "config", "info", "refresh", "start", "timer"], ["widgetWrapper", ""], [1, "widget-options"], ["clrForm", "", 4, "ngIf"], [1, "widget-queries"], [4, "ngIf"], [3, "query"], [3, "fillEnabled", "runEnabled", "lsEnabled", "query", 4, "ngIf"], ["inputType", "number", 3, "key", "label", "database", "index", "queryDetectors", "queryFits", "query", 4, "ngFor", "ngForOf"], ["class", "widget-content", 4, "ngIf"], ["clrForm", ""], ["type", "checkbox", "clrCheckbox", "", "name", "separatorsCheckbox", 3, "ngModel", "ngModelChange"], [3, "options", "query"], [3, "fillEnabled", "runEnabled", "lsEnabled", "query"], ["inputType", "number", 3, "key", "label", "database", "index", "queryDetectors", "queryFits", "query"], [1, "widget-content"], [2, "height", "100%", "width", "100%"], ["plot", ""], [2, "height", "55%", "width", "100%"], [1, "h6", "content-separator"], [2, "flex", "1 1 auto", "width", "100%"], ["ratioPlot", ""]], template: function NumericFieldSplitComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "wm-widget", 0, 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("refresh", function NumericFieldSplitComponent_Template_wm_widget_refresh_0_listener() { return ctx.onRefreshEvent(); })("start", function NumericFieldSplitComponent_Template_wm_widget_start_0_listener() { return ctx.onStartEvent(); })("timer", function NumericFieldSplitComponent_Template_wm_widget_timer_0_listener() { return ctx.updateLive(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](3, NumericFieldSplitComponent_form_3_Template, 8, 1, "form", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](5, NumericFieldSplitComponent_div_5_Template, 2, 1, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](6, "wm-date-range-form", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("query", function NumericFieldSplitComponent_Template_wm_date_range_form_query_6_listener($event) { return ctx.queryDateRange($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](7, NumericFieldSplitComponent_wm_fill_run_ls_form_7_Template, 1, 3, "wm-fill-run-ls-form", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](8, NumericFieldSplitComponent_wm_fill_run_ls_form_8_Template, 1, 3, "wm-fill-run-ls-form", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](9, NumericFieldSplitComponent_wm_range_form_9_Template, 1, 6, "wm-range-form", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](10, NumericFieldSplitComponent_div_10_Template, 3, 0, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](11, NumericFieldSplitComponent_div_11_Template, 7, 0, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("config", ctx.config.wrapper)("info", ctx.info);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.config.widget.fieldChangeSeparators);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.wi.quickDateOptions);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.config.widget.fillQueriesEnabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.config.widget.runQueriesEnabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.wi.rangeQueries);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", !ctx.wi["ratios"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.wi["ratios"]);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _clr_angular__WEBPACK_IMPORTED_MODULE_8__.ClrLabel, _clr_angular__WEBPACK_IMPORTED_MODULE_8__.ClrForm, _clr_angular__WEBPACK_IMPORTED_MODULE_8__.ClrCheckbox, _clr_angular__WEBPACK_IMPORTED_MODULE_8__.ClrCheckboxContainer, _clr_angular__WEBPACK_IMPORTED_MODULE_8__.ClrCheckboxWrapper, _angular_forms__WEBPACK_IMPORTED_MODULE_9__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_9__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgModel, _angular_forms__WEBPACK_IMPORTED_MODULE_9__.NgForm, _shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_1__.WidgetComponent, _shared_date_range_form_date_range_form_component__WEBPACK_IMPORTED_MODULE_2__.DateRangeFormComponent, _shared_fill_run_ls_form_fill_run_ls_form_component__WEBPACK_IMPORTED_MODULE_3__.FillRunLsFormComponent, _shared_range_form_range_form_component__WEBPACK_IMPORTED_MODULE_4__.RangeFormComponent, _shared_quick_date_form_quick_date_form_component__WEBPACK_IMPORTED_MODULE_5__.QuickDateFormComponent], styles: [".widget-content[_ngcontent-%COMP%] {\r\n    width: 100%;\r\n    height: 100%;\r\n    overflow: hidden;\r\n    display: flex;\r\n    flex-flow: column;\r\n}\r\n\r\n.content-separator[_ngcontent-%COMP%] {\r\n    font-weight: bold;\r\n    text-align: center;\r\n    border-top: 1px silver solid;\r\n}\r\n\r\n.widget-queries[_ngcontent-%COMP%]    > *[_ngcontent-%COMP%] {\r\n    display: block;\r\n}\r\n\r\n.widget-queries[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]:hover {\r\n    background-color: #D9E4EA;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm51bWVyaWMtZmllbGQuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLFdBQVc7SUFDWCxZQUFZO0lBQ1osZ0JBQWdCO0lBQ2hCLGFBQWE7SUFDYixpQkFBaUI7QUFDckI7O0FBRUE7SUFDSSxpQkFBaUI7SUFDakIsa0JBQWtCO0lBQ2xCLDRCQUE0QjtBQUNoQzs7QUFFQTtJQUNJLGNBQWM7QUFDbEI7O0FBRUE7SUFDSSx5QkFBeUI7QUFDN0IiLCJmaWxlIjoibnVtZXJpYy1maWVsZC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLndpZGdldC1jb250ZW50IHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWZsb3c6IGNvbHVtbjtcclxufVxyXG5cclxuLmNvbnRlbnQtc2VwYXJhdG9yIHtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgYm9yZGVyLXRvcDogMXB4IHNpbHZlciBzb2xpZDtcclxufVxyXG5cclxuLndpZGdldC1xdWVyaWVzID4gKiB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxufVxyXG5cclxuLndpZGdldC1xdWVyaWVzPio6aG92ZXIge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0Q5RTRFQTtcclxufVxyXG4iXX0= */"] });


/***/ }),

/***/ 2300:
/*!***************************************************************************!*\
  !*** ./src/app/widgets/numeric-field-split/numeric-field-split.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NumericFieldSplitModule": () => (/* binding */ NumericFieldSplitModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/shared/shared.module */ 44466);
/* harmony import */ var _numeric_field_split_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./numeric-field-split.component */ 41163);
/* harmony import */ var _numeric_field_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../numeric-field/data.service */ 79081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);





class NumericFieldSplitModule {
}
NumericFieldSplitModule.entry = _numeric_field_split_component__WEBPACK_IMPORTED_MODULE_1__.NumericFieldSplitComponent;
NumericFieldSplitModule.ɵfac = function NumericFieldSplitModule_Factory(t) { return new (t || NumericFieldSplitModule)(); };
NumericFieldSplitModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: NumericFieldSplitModule });
NumericFieldSplitModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ providers: [_numeric_field_data_service__WEBPACK_IMPORTED_MODULE_2__.DataService], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
        app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](NumericFieldSplitModule, { declarations: [_numeric_field_split_component__WEBPACK_IMPORTED_MODULE_1__.NumericFieldSplitComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
        app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule] }); })();


/***/ })

}]);
//# sourceMappingURL=src_app_widgets_numeric-field-split_numeric-field-split_module_ts.js.map