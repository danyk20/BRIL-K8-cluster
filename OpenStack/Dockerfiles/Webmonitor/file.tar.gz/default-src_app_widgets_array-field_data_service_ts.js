"use strict";
(self["webpackChunkwebmonitor2"] = self["webpackChunkwebmonitor2"] || []).push([["default-src_app_widgets_array-field_data_service_ts"],{

/***/ 7529:
/*!***************************************************!*\
  !*** ./src/app/shared/query-cache/query-cache.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QueryCache": () => (/* binding */ QueryCache)
/* harmony export */ });
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs/operators */ 89196);

class QueryCache {
    constructor(timeToLive) {
        this.timeToLive = timeToLive;
        this.cache = {};
        if (!Number.isFinite(timeToLive) || timeToLive <= 0) {
            throw new Error('QueryCache timeToLive must be positive number');
        }
    }
    ask(key, queryRequest) {
        if (this.cache[key]) {
            return this.cache[key][0];
        }
        const rSubject = queryRequest.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_0__.shareReplay)());
        const timerID = setTimeout(() => {
            clearTimeout(this.cache[key][1]);
            delete this.cache[key];
        }, this.timeToLive);
        this.cache[key] = [rSubject, timerID];
        return rSubject;
    }
    clear() {
        Object.keys(this.cache).forEach(key => {
            clearTimeout(this.cache[key][1]);
            delete this.cache[key];
        });
    }
}


/***/ }),

/***/ 41977:
/*!*****************************************************!*\
  !*** ./src/app/widgets/array-field/data.service.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DataService": () => (/* binding */ DataService),
/* harmony export */   "MAX_QUERY_SIZE": () => (/* binding */ MAX_QUERY_SIZE),
/* harmony export */   "MAX_QUERY_SIZE_FOR_NEWEST": () => (/* binding */ MAX_QUERY_SIZE_FOR_NEWEST)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 25474);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var app_shared_query_cache_query_cache__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/shared/query-cache/query-cache */ 7529);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var app_core_database_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! app/core/database.service */ 67084);





const MAX_QUERY_SIZE = 10000;
const MAX_QUERY_SIZE_FOR_NEWEST = 200;
class DataService {
    constructor(db) {
        this.db = db;
        this.queryCache = new app_shared_query_cache_query_cache__WEBPACK_IMPORTED_MODULE_0__.QueryCache(1000);
    }
    queryExtremesByTerm(params, term) {
        let query = this.makeExtremesQuery(params);
        query[1]['query']['bool']['filter'].push({ "term": term });
        this.db.transformQueryWithNestedPath(query[1], params.nestedPath);
        return this.db.multiSearch(this.db.stringifyToNDJSON(query), params.db)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(this.extractExtremes));
    }
    _query(queryStr, params, aggregated = false) {
        let extractResponse;
        if (aggregated) {
            extractResponse = (response) => this.extractAggregatedResponseFields(response, params);
        }
        else {
            extractResponse = (response) => this.extractResponseFields(response, params);
        }
        const queryObs = this.db.multiSearch(queryStr, params.database)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(extractResponse));
        return this.queryCache.ask(aggregated + params.database + queryStr, queryObs);
    }
    queryRangeAggregated(params, min, max, aggregation = 'avg', buckets = 1800) {
        if (params.nestedPath) {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.throwError)('Cannot do aggregation queries with nestedPath');
        }
        let query = this.makeAggregationQuery(params, min, max, aggregation, buckets);
        return this._query(this.db.stringifyToNDJSON(query), params, true);
    }
    makeAggregationQuery(params, min, max, aggregation = 'avg', buckets = 1800) {
        const header = {
            index: params.index,
            type: params.documentType
        };
        const body = {
            'size': 0,
            'query': {
                'bool': { 'filter': [] }
            },
            'aggs': {
                'points': {
                    'aggs': {}
                }
            }
        };
        if (params.histogramAggregatedQuery) {
            const histogram = {
                'field': params.aggregationQueryParams.field,
                'interval': params.aggregationQueryParams.interval,
                'min_doc_count': 1
            };
            body['aggs']['points']['histogram'] = histogram;
            body['query']['bool']['filter'].push({
                'range': { [params.aggregationQueryParams.field]: { 'gte': min, 'lte': max } }
            });
        }
        else {
            const interval = Math.ceil(((new Date(max)).getTime() - (new Date(min)).getTime()) / buckets);
            const dateHistogram = {
                'field': params.timestampField,
                'interval': String(interval) + 'ms',
                'extended_bounds': {
                    'min': min,
                    'max': max
                }
            };
            body['aggs']['points']['date_histogram'] = dateHistogram;
            body['query']['bool']['filter'].push({
                'range': { 'timestamp': { 'gte': min, 'lte': max } }
            });
        }
        if (params.extraFields.length > 0) {
            body['aggs']['points']['aggs']['_extra'] = { 'top_hits': { 'size': 1 } };
            body['aggs']['points']['aggs']['_extra']['top_hits']['_source'] = {
                'include': params.extraFields
            };
        }
        params.series.forEach(s => {
            const agg = {};
            agg[aggregation] = {
                'script': {
                    'lang': 'painless',
                    'source': 'return params._source[params.field][params.index];',
                    'params': { 'field': params.field, 'index': s }
                }
            };
            body['aggs']['points']['aggs'][':' + s] = agg;
        });
        if (params.terms) {
            Object.keys(params.terms).forEach(k => {
                const term = {};
                term[k] = params.terms[k];
                body['query']['bool']['filter'].push({ 'term': term });
            });
        }
        return [header, body];
    }
    queryTerm(params, term) {
        let query = this.makeQueryTemplate(params);
        query[1]['query']['bool']['filter'].push({ "term": term });
        this.db.transformQueryWithNestedPath(query[1], params.nestedPath);
        return this._query(this.db.stringifyToNDJSON(query), params);
    }
    queryNewest(params, size) {
        let query = this.makeQueryTemplate(params);
        query[1]['size'] = size > MAX_QUERY_SIZE ? MAX_QUERY_SIZE : size;
        this.db.transformQueryWithNestedPath(query[1], params.nestedPath);
        return this._query(this.db.stringifyToNDJSON(query), params);
    }
    queryRange(params, min, max) {
        let query = this.makeQueryTemplate(params);
        const range = {};
        range[params.timestampField] = {
            "gte": min,
            "lte": max
        };
        query[1]['query']['bool']['filter'].push({ "range": range });
        this.db.transformQueryWithNestedPath(query[1], params.nestedPath);
        return this._query(this.db.stringifyToNDJSON(query), params);
    }
    queryNewestSince(params, since, includeEqual = true) {
        let query = this.makeQueryTemplate(params);
        query[1]['size'] = MAX_QUERY_SIZE_FOR_NEWEST;
        const range = {};
        if (includeEqual) {
            range[params.timestampField] = { "gte": since };
        }
        else {
            range[params.timestampField] = { "gt": since };
        }
        query[1]['query']['bool']['filter'].push({ "range": range });
        this.db.transformQueryWithNestedPath(query[1], params.nestedPath);
        return this._query(this.db.stringifyToNDJSON(query), params);
    }
    queryBasicX(params, xField, min, max, size = MAX_QUERY_SIZE) {
        let query = this.makeQueryTemplate(params, xField);
        query[1]['sort'] = {};
        query[1]['sort'][xField] = 'desc';
        query[1]['size'] = size > MAX_QUERY_SIZE ? MAX_QUERY_SIZE : size;
        if (typeof min != 'undefined' || typeof max != 'undefined') {
            const range = {};
            range[xField] = { "gte": min, "lte": max };
            query[1]['query']['bool']['filter'].push({ "range": range });
        }
        this.db.transformQueryWithNestedPath(query[1], params.nestedPath);
        return this._query(this.db.stringifyToNDJSON(query), params);
    }
    makeExtremesQuery(params) {
        const header = {
            index: params.index,
            type: params.documentType
        };
        const body = {
            "size": 0,
            "query": {
                "bool": {
                    "filter": []
                }
            },
            'aggs': {
                'min_ts': {
                    'min': {
                        'field': params.timestampField
                    }
                },
                'max_ts': {
                    'max': {
                        'field': params.timestampField
                    }
                }
            }
        };
        if (params.terms) {
            Object.keys(params.terms).forEach(k => {
                const term = {};
                term[k] = params.terms[k];
                body['query']['bool']['filter'].push({ 'term': term });
            });
        }
        return [header, body];
    }
    makeQueryTemplate(params, xField = undefined) {
        const header = {
            index: params.index,
            type: params.documentType
        };
        const body = {
            "_source": this.parseQueryFields(params, xField),
            "sort": {},
            "size": MAX_QUERY_SIZE,
            "query": {
                "bool": {
                    "filter": []
                }
            }
        };
        if (xField) {
            body['sort'][xField] = 'desc';
        }
        else {
            body['sort'][params.timestampField] = 'desc';
        }
        if (params.terms) {
            Object.keys(params.terms).forEach(k => {
                const term = {};
                term[k] = params.terms[k];
                body['query']['bool']['filter'].push({ 'term': term });
            });
        }
        return [header, body];
    }
    parseQueryFields(params, xField = undefined) {
        const fields = [params.field];
        xField ? fields.push(xField) : fields.push(params.timestampField);
        if (params.extraFields.length > 0) {
            return fields.concat(params.extraFields);
        }
        return fields;
    }
    extractResponseFields(response, params) {
        response = response['responses'][0]['hits']['hits'].reverse()
            .map(hit => hit['_source']);
        if (params.nestedPath) {
            response = response.map(hit => hit[params.nestedPath]);
        }
        return response;
    }
    extractAggregatedResponseFields(response, params) {
        const buckets = response['responses'][0]['aggregations']['points']['buckets'];
        const result = [];
        buckets.forEach(bucket => {
            const point = {};
            const fieldVal = [];
            const errors = [];
            if (params.histogramAggregatedQuery) {
                point[params.aggregationQueryParams.field] = bucket['key'];
            }
            else {
                point[params.timestampField] = bucket['key_as_string'];
            }
            params.series.forEach(s => {
                fieldVal[s] = bucket[':' + s]['value'] || bucket[':' + s]['avg'];
                if (params.aggregationAlgo === 'extended_stats') {
                    errors[s] = bucket[':' + s]['std_deviation'] / Math.sqrt(bucket[':' + s]['count']);
                }
            });
            point[params.field] = fieldVal;
            if (params.extraFields.length > 0) {
                const hit = bucket['_extra']['hits']['hits'][0];
                params.extraFields.forEach(f => {
                    point[f] = hit ? hit['_source'][f] : undefined;
                });
            }
            if (params.aggregationQueryParams.errorCalculation) {
                point[params.errorField] = errors;
            }
            result.push(point);
        });
        return result;
    }
    extractExtremes(response) {
        const aggs = response['responses'][0]['aggregations'];
        const min = aggs['min_ts'];
        const max = aggs['max_ts'];
        return {
            min: min,
            max: max
        };
    }
}
DataService.ɵfac = function DataService_Factory(t) { return new (t || DataService)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵinject"](app_core_database_service__WEBPACK_IMPORTED_MODULE_1__.DatabaseService)); };
DataService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({ token: DataService, factory: DataService.ɵfac });


/***/ })

}]);
//# sourceMappingURL=default-src_app_widgets_array-field_data_service_ts.js.map