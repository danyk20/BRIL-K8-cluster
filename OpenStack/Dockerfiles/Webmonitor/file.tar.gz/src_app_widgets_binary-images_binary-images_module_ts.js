"use strict";
(self["webpackChunkwebmonitor2"] = self["webpackChunkwebmonitor2"] || []).push([["src_app_widgets_binary-images_binary-images_module_ts"],{

/***/ 90358:
/*!******************************************************************!*\
  !*** ./src/app/widgets/binary-images/binary-images.component.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BinaryImagesComponent": () => (/* binding */ BinaryImagesComponent)
/* harmony export */ });
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./data.service */ 50774);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/platform-browser */ 34497);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @clr/angular */ 4151);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _shared_dynamic_form_dynamic_form_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../shared/dynamic-form/dynamic-form.component */ 36959);
/* harmony import */ var _shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../shared/widget/widget.component */ 81522);
/* harmony import */ var _shared_date_range_form_date_range_form_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/date-range-form/date-range-form.component */ 63747);
/* harmony import */ var _shared_range_form_range_form_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/range-form/range-form.component */ 2199);
/* harmony import */ var _shared_delimited_form_delimited_form_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/delimited-form/delimited-form.component */ 5263);












const _c0 = ["widgetWrapper"];
function BinaryImagesComponent_clr_dg_row_15_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "clr-dg-row", 33)(1, "clr-dg-cell");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
} if (rf & 2) {
    const t_r11 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("clrDgItem", t_r11);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](t_r11.name);
} }
function BinaryImagesComponent_option_32_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const queryType_r12 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngValue", queryType_r12);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", queryType_r12.label, " ");
} }
function BinaryImagesComponent_wm_date_range_form_34_Template(rf, ctx) { if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "wm-date-range-form", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("query", function BinaryImagesComponent_wm_date_range_form_34_Template_wm_date_range_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r14); const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r13.onDateRangeQuery($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} }
function BinaryImagesComponent_wm_range_form_35_Template(rf, ctx) { if (rf & 1) {
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "wm-range-form", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("query", function BinaryImagesComponent_wm_range_form_35_Template_wm_range_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r16); const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r15.onRangeConditionQuery($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("inputType", ctx_r4.selectedQuery.fieldType)("key", ctx_r4.selectedQuery.field);
} }
function BinaryImagesComponent_wm_delimited_form_36_Template(rf, ctx) { if (rf & 1) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "wm-delimited-form", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("query", function BinaryImagesComponent_wm_delimited_form_36_Template_wm_delimited_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r18); const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r17.onListConditionQuery($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("inputType", ctx_r5.selectedQuery.fieldType)("key", ctx_r5.selectedQuery.field)("label", ctx_r5.selectedQuery.label);
} }
function BinaryImagesComponent_div_37_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, "Unknown query type :(");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} }
function BinaryImagesComponent_option_57_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const opt_r19 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("value", opt_r19.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", opt_r19.label, " ");
} }
function BinaryImagesComponent_option_62_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "option", 38);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const opt_r20 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("value", opt_r20.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", opt_r20.label, " ");
} }
function BinaryImagesComponent_span_71_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](1, " is also the query limit ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](2, "span", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](4, ". Not everything matching the query may be retrieved. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx_r9.max_query_size);
} }
function BinaryImagesComponent_div_73_div_5_span_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "span", 49)(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, ": ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](4, "code", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
} if (rf & 2) {
    const f_r26 = ctx.$implicit;
    const img_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](f_r26);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](img_r23.meta[f_r26]);
} }
function BinaryImagesComponent_div_73_div_5_span_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "span", 49)(1, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, ": ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](4, "code", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
} if (rf & 2) {
    const img_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]().$implicit;
    const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx_r25.wi.timestampField);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](img_r23.meta[ctx_r25.wi.timestampField].toISOString());
} }
function BinaryImagesComponent_div_73_div_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 13)(1, "div", 43)(2, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](3, BinaryImagesComponent_div_73_div_5_span_3_Template, 6, 2, "span", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](4, BinaryImagesComponent_div_73_div_5_span_4_Template, 6, 2, "span", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](5, "div", 47);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](6, "img", 48);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
} if (rf & 2) {
    const img_r23 = ctx.$implicit;
    const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵstyleProp"]("width", ctx_r22.wi.imageWidth + "px");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx_r22.metaFieldsKeys);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx_r22.wi.timestampField);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("src", img_r23.src, _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsanitizeUrl"]);
} }
function BinaryImagesComponent_div_73_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "div", 40)(1, "span", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](2, "Group: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](3, "code", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](5, BinaryImagesComponent_div_73_div_5_Template, 7, 5, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    const group_r21 = ctx.$implicit;
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate2"]("", ctx_r10.wi.groupBy, " == ", group_r21.groupName, "");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", group_r21.images);
} }
class BinaryImagesComponent {
    constructor(dataService, sanatizer) {
        this.dataService = dataService;
        this.sanatizer = sanatizer;
        this.metaFields = {};
        this.filtersFormModel = {};
        this.filtersFormFields = [];
        this.groupByOptions = [];
        this.sortByOptions = [];
        this.selectedTypes = [];
        this.featuresSelectionModel = {};
        this.images = [];
        this.groupedImages = [];
        this.max_query_size = _data_service__WEBPACK_IMPORTED_MODULE_0__.MAX_QUERY_SIZE;
    }
    ngOnInit() {
        this.wi = this.config['widget'];
        this.metaFields = (this.wi.metaFields || {});
        this.metaFieldsKeys = Object.keys(this.metaFields);
        this.filtersFormFields = this.makeFiltersFormFields();
        this.groupByOptions = this.metaFieldsKeys.map(key => {
            return { value: key, label: this.metaFields[key]['label'] };
        });
        if (this.wi.timestampField) {
            this.groupByOptions.push({ value: this.wi.timestampField, label: 'Timestamp' });
        }
        this.sortByOptions = this.groupByOptions;
        this.setupQueryConfig();
    }
    setupQueryConfig() {
        const qc = this.wi['queryConfig'] = this.queryConfig = (this.wi['queryConfig'] || {});
        if (!qc.typesDisabled) {
            qc.typeSelectionTitle = qc.typeSelectionTitle || 'Image types';
            qc.availableTypes = qc.availableTypes || [];
        }
        if (!qc.featuresDisabled) {
            qc.featuresSelectionTitle = qc.featuresSelectionTitle || 'Conditions';
            qc.featuresSelectionFormFields = qc.featuresSelectionFormFields || [];
        }
        qc.querySelectionTitle = qc.querySelectionTitle || 'Query type';
        qc.availableQueries = (qc.availableQueries || [{ type: 'daterange', label: 'Date range' }]);
        this.selectedQuery = qc.availableQueries[0];
    }
    makeQueryParameters() {
        const terms = this.extractFeaturesTerms();
        return {
            database: this.wi.database,
            index: this.wi.index,
            useDocumentType: this.wi.useDocumentType,
            typeField: this.wi.typeField,
            timestampField: this.wi.timestampField,
            fields: this.metaFieldsKeys.concat([this.wi.imageDataField]),
            types: this.selectedTypes.length > 0 ? this.selectedTypes.map(t => t['name']) : undefined,
            singleTerms: terms.singleTerms,
            multiTerms: terms.multiTerms
        };
    }
    extractFeaturesTerms() {
        const singleTerms = {};
        const multiTerms = {};
        this.queryConfig.featuresSelectionFormFields.forEach((field, index) => {
            if (typeof this.featuresSelectionModel[index] === 'undefined') {
                return;
            }
            const value = this.featuresSelectionModel[index];
            if (value.hasOwnProperty('length') && value.length < 1) {
                // ignoring empty arrays and strings
                return;
            }
            if (['number', 'string'].includes(field.type.toString())) {
                singleTerms[index] = value;
            }
            else if (['delimited-numbers', 'delimited-strings'].includes(field.type.toString())) {
                multiTerms[index] = value;
            }
            else {
                throw Error('Unsupported field type: ' + field.type);
            }
        });
        return {
            singleTerms: Object.keys(singleTerms).length > 0 ? singleTerms : undefined,
            multiTerms: Object.keys(multiTerms).length > 0 ? multiTerms : undefined
        };
    }
    onRangeConditionQuery(event) {
        if (typeof event.min == 'undefined' || typeof event.max == 'undefined') {
            this.widgetComponent.log('Min and max must be set for a range query', 'danger', 3000);
            return;
        }
        const params = this.makeQueryParameters();
        this.dataService
            .queryRange(params, event.key, event.min, event.max)
            .subscribe(result => {
            this.images = this.parseImages(result);
            this.updateImageGroups();
        });
    }
    onListConditionQuery(event) {
        if (!Array.isArray(event.value)) {
            this.widgetComponent.log('Array of values is needed for a list query', 'danger', 3000);
            return;
        }
        else if (event.value.length == 0) {
            this.widgetComponent.log('List cannot be empty', 'danger', 3000);
            return;
        }
        console.log(event);
        const params = this.makeQueryParameters();
        if (typeof params.multiTerms == 'undefined') {
            const terms = {};
            terms[event.key] = event.value;
            params.multiTerms = terms;
        }
        else {
            params.multiTerms[event.key] = event.value;
        }
        this.dataService
            .query(params)
            .subscribe(result => {
            this.images = this.parseImages(result);
            this.updateImageGroups();
        });
    }
    onDateRangeQuery(event) {
        if (!this.wi.timestampField) {
            throw Error('Cannot perform date range query without timestampField');
        }
        const params = this.makeQueryParameters();
        let t_from;
        let t_to;
        if (this.wi.timestampFormat === 's') {
            t_from = event.tsFrom;
            t_to = event.tsTo;
        }
        else if (this.wi.timestampFormat === 'ms') {
            t_from = event.msecFrom;
            t_to = event.msecTo;
        }
        else if (this.wi.timestampFormat === 'string') {
            t_from = event.strFrom;
            t_to = event.strTo;
        }
        this.dataService
            .queryRange(params, this.wi.timestampField, t_from, t_to)
            .subscribe(result => {
            this.images = this.parseImages(result);
            this.updateImageGroups();
        });
    }
    parseImages(response) {
        return response.map(image => {
            return {
                src: this.sanatizer.bypassSecurityTrustResourceUrl('data:image/png;base64,' + image['img']),
                meta: this.extractMetadata(image)
            };
        });
    }
    updateImageGroups() {
        const groupBy = this.wi.groupBy;
        const filtered = this.filterImages();
        if (groupBy) {
            let groupNameFormatter = (group) => group;
            if (groupBy === this.wi.timestampField) {
                groupNameFormatter = (group) => group.toISOString();
            }
            const groups = {};
            filtered.forEach(img => {
                const group = groupNameFormatter(img['meta'][groupBy]);
                if (!groups.hasOwnProperty(group)) {
                    groups[group] = [];
                }
                groups[group].push(img);
            });
            this.groupedImages = Object.keys(groups).map(key => {
                return { groupName: key, images: groups[key] };
            });
        }
        else {
            this.groupedImages = [{ groupName: '', images: filtered }];
        }
        this.sortGroupedImages();
    }
    sortGroupedImages() {
        const sortBy = this.wi.sortBy;
        if (!sortBy) {
            return;
        }
        this.groupedImages.forEach(group => {
            group.images.sort((a, b) => {
                if (a['meta'][sortBy] < b['meta'][sortBy]) {
                    return -1;
                }
                else if (a['meta'][sortBy] > b['meta'][sortBy]) {
                    return 1;
                }
                else {
                    return 0;
                }
            });
        });
    }
    extractMetadata(image) {
        const metadata = {};
        this.metaFieldsKeys.forEach(f => {
            metadata[f] = image[f];
        });
        if (this.wi.timestampField) {
            if (this.wi.timestampFormat === 's') {
                metadata[this.wi.timestampField] =
                    new Date(image[this.wi.timestampField] * 1000);
            }
            else {
                metadata[this.wi.timestampField] =
                    new Date(image[this.wi.timestampField]);
            }
        }
        return metadata;
    }
    makeFiltersFormFields() {
        const fields = [];
        this.metaFieldsKeys.forEach(key => {
            if (!['number', 'string'].includes(this.metaFields[key].type)) {
                return;
            }
            fields.push({
                key: key,
                type: this.metaFields[key]['type'],
                templateOptions: { label: this.metaFields[key]['label'] }
            });
        });
        return fields;
    }
    filterImages() {
        let filtered = this.images;
        this.metaFieldsKeys.forEach(key => {
            if (this.filtersFormModel.hasOwnProperty(key)) {
                const filterValue = this.filtersFormModel[key];
                if (filterValue === null) {
                    return;
                }
                if (this.metaFields[key].type == 'string') {
                    filtered = filtered.filter(img => img['meta'][key].includes(filterValue));
                }
                else {
                    filtered = filtered.filter(img => img['meta'][key] == filterValue);
                }
            }
        });
        return filtered;
    }
    onClickApplyFilters() {
        this.updateImageGroups();
    }
    onClickClearFilters() {
        this.filtersFormModel = {};
        this.updateImageGroups();
    }
}
BinaryImagesComponent.ɵfac = function BinaryImagesComponent_Factory(t) { return new (t || BinaryImagesComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_data_service__WEBPACK_IMPORTED_MODULE_0__.DataService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__.DomSanitizer)); };
BinaryImagesComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({ type: BinaryImagesComponent, selectors: [["ng-component"]], viewQuery: function BinaryImagesComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵviewQuery"](_c0, 7);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵloadQuery"]()) && (ctx.widgetComponent = _t.first);
    } }, inputs: { config: "config" }, decls: 74, vars: 25, consts: [[3, "config"], ["widgetWrapper", ""], [1, "widget-content"], ["clrTabLink", ""], [1, "clr-row"], [1, "clr-col-auto", "selection", "type-selection"], [1, "datagrid-compact", 3, "clrDgSelected", "clrDgSelectedChange"], ["clrDgField", "name"], [3, "clrDgItem", 4, "clrDgItems", "clrDgItemsOf"], [3, "clrDgPageSize"], [1, "clr-col-auto", "selection", "feature-selection"], [3, "formFields", "model", "modelChange"], [1, "clr-col", "selection", "range-selection"], [1, "clr-col-auto"], ["clrForm", "", "clrLayout", "vertical"], ["name", "query-select", "clrSelect", "", 3, "ngModel", "ngModelChange"], [3, "ngValue", 4, "ngFor", "ngForOf"], [1, "clr-col", 3, "ngSwitch"], [3, "query", 4, "ngSwitchCase"], [3, "inputType", "key", "query", 4, "ngSwitchCase"], [3, "inputType", "key", "label", "query", 4, "ngSwitchCase"], [4, "ngSwitchDefault"], [1, "clr-col-12"], [1, "btn", 3, "click"], ["clrForm", "", "clrLayout", "horizontal"], ["name", "groupby-select", "clrSelect", "", 3, "ngModel", "ngModelChange"], [3, "value", 4, "ngFor", "ngForOf"], ["name", "sortby-select", "clrSelect", "", 3, "ngModel", "ngModelChange"], ["clrInput", "", "type", "number", "min", "64", "name", "input-image-width", 3, "ngModel", "ngModelChange"], [1, "badge", "badge-info"], [4, "ngIf"], [1, "image-container"], ["class", "clr-row image-group", 4, "ngFor", "ngForOf"], [3, "clrDgItem"], [3, "ngValue"], [3, "query"], [3, "inputType", "key", "query"], [3, "inputType", "key", "label", "query"], [3, "value"], [1, "badge", "badge-danger"], [1, "clr-row", "image-group"], [1, "clr-code"], ["class", "clr-col-auto", 4, "ngFor", "ngForOf"], [1, "card"], [1, "card-header", "meta-header"], ["class", "meta-field", 4, "ngFor", "ngForOf"], ["class", "meta-field", 4, "ngIf"], [1, "card-img"], [3, "src"], [1, "meta-field"]], template: function BinaryImagesComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "wm-widget", 0, 1)(2, "div", 2)(3, "clr-tabs")(4, "clr-tab")(5, "button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](6, "Queries");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](7, "clr-tab-content")(8, "div", 4)(9, "div", 5)(10, "h6");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](12, "clr-datagrid", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("clrDgSelectedChange", function BinaryImagesComponent_Template_clr_datagrid_clrDgSelectedChange_12_listener($event) { return ctx.selectedTypes = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](13, "clr-dg-column", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](14, "Name");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](15, BinaryImagesComponent_clr_dg_row_15_Template, 3, 2, "clr-dg-row", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](16, "clr-dg-footer");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](17, "clr-dg-pagination", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](18, "div", 10)(19, "h6");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](20);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](21, "wm-dynamic-form", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("modelChange", function BinaryImagesComponent_Template_wm_dynamic_form_modelChange_21_listener($event) { return ctx.featuresSelectionModel = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](22, "div", 12)(23, "h6");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](24);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](25, "div", 4)(26, "div", 13)(27, "form", 14)(28, "clr-select-container")(29, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](30, "Query type");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](31, "select", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function BinaryImagesComponent_Template_select_ngModelChange_31_listener($event) { return ctx.selectedQuery = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](32, BinaryImagesComponent_option_32_Template, 2, 2, "option", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](33, "div", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](34, BinaryImagesComponent_wm_date_range_form_34_Template, 1, 0, "wm-date-range-form", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](35, BinaryImagesComponent_wm_range_form_35_Template, 1, 2, "wm-range-form", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](36, BinaryImagesComponent_wm_delimited_form_36_Template, 1, 3, "wm-delimited-form", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](37, BinaryImagesComponent_div_37_Template, 2, 0, "div", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](38, "clr-tab")(39, "button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](40, "Filters");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](41, "clr-tab-content")(42, "div", 22)(43, "wm-dynamic-form", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("modelChange", function BinaryImagesComponent_Template_wm_dynamic_form_modelChange_43_listener($event) { return ctx.filtersFormModel = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](44, "button", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function BinaryImagesComponent_Template_button_click_44_listener() { return ctx.onClickApplyFilters(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](45, "Apply filters");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](46, "button", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function BinaryImagesComponent_Template_button_click_46_listener() { return ctx.onClickClearFilters(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](47, "Clear filters");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](48, "clr-tab")(49, "button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](50, "Options");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](51, "clr-tab-content")(52, "form", 24)(53, "clr-select-container")(54, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](55, "Group by");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](56, "select", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function BinaryImagesComponent_Template_select_ngModelChange_56_listener($event) { return ctx.wi.groupBy = $event; })("ngModelChange", function BinaryImagesComponent_Template_select_ngModelChange_56_listener() { return ctx.updateImageGroups(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](57, BinaryImagesComponent_option_57_Template, 2, 2, "option", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](58, "clr-select-container")(59, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](60, "Sort by");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](61, "select", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function BinaryImagesComponent_Template_select_ngModelChange_61_listener($event) { return ctx.wi.sortBy = $event; })("ngModelChange", function BinaryImagesComponent_Template_select_ngModelChange_61_listener() { return ctx.sortGroupedImages(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](62, BinaryImagesComponent_option_62_Template, 2, 2, "option", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](63, "clr-input-container")(64, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](65, "Image width");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](66, "input", 28);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("ngModelChange", function BinaryImagesComponent_Template_input_ngModelChange_66_listener($event) { return ctx.wi.imageWidth = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](67, "span", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](68, " Number of images queried ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](69, "span", 29);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](70);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](71, BinaryImagesComponent_span_71_Template, 5, 1, "span", 30);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](72, "div", 31);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](73, BinaryImagesComponent_div_73_Template, 6, 3, "div", 32);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("config", ctx.config ? ctx.config.wrapper : undefined);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx.queryConfig.typeSelectionTitle);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("clrDgSelected", ctx.selectedTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("clrDgItemsOf", ctx.queryConfig.availableTypes);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("clrDgPageSize", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx.queryConfig.featuresSelectionTitle);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("formFields", ctx.queryConfig.featuresSelectionFormFields)("model", ctx.featuresSelectionModel);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate1"](" ", ctx.queryConfig.querySelectionTitle, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngModel", ctx.selectedQuery);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.queryConfig.availableQueries);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngSwitch", ctx.selectedQuery.type);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngSwitchCase", "daterange");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngSwitchCase", "range");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngSwitchCase", "list");
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("formFields", ctx.filtersFormFields)("model", ctx.filtersFormModel);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngModel", ctx.wi.groupBy);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.groupByOptions);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngModel", ctx.wi.sortBy);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.sortByOptions);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngModel", ctx.wi.imageWidth);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtextInterpolate"](ctx.images.length);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.images.length == ctx.max_query_size);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngForOf", ctx.groupedImages);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgSwitch, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgSwitchCase, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgSwitchDefault, _clr_angular__WEBPACK_IMPORTED_MODULE_9__.ClrDatagrid, _clr_angular__WEBPACK_IMPORTED_MODULE_9__.ClrDatagridColumn, _clr_angular__WEBPACK_IMPORTED_MODULE_9__.ClrDatagridItems, _clr_angular__WEBPACK_IMPORTED_MODULE_9__.ClrDatagridRow, _clr_angular__WEBPACK_IMPORTED_MODULE_9__.ClrDatagridCell, _clr_angular__WEBPACK_IMPORTED_MODULE_9__.ClrDatagridFooter, _clr_angular__WEBPACK_IMPORTED_MODULE_9__.ClrDatagridPagination, _clr_angular__WEBPACK_IMPORTED_MODULE_9__["ÇlrDatagridMainRenderer"], _clr_angular__WEBPACK_IMPORTED_MODULE_9__["ÇlrDatagridHeaderRenderer"], _clr_angular__WEBPACK_IMPORTED_MODULE_9__["ÇlrDatagridRowRenderer"], _clr_angular__WEBPACK_IMPORTED_MODULE_9__["ÇlrDatagridCellRenderer"], _clr_angular__WEBPACK_IMPORTED_MODULE_9__["ÇlrDatagridWillyWonka"], _clr_angular__WEBPACK_IMPORTED_MODULE_9__["ÇlrActionableOompaLoompa"], _clr_angular__WEBPACK_IMPORTED_MODULE_9__["ÇlrExpandableOompaLoompa"], _clr_angular__WEBPACK_IMPORTED_MODULE_9__.ClrLabel, _clr_angular__WEBPACK_IMPORTED_MODULE_9__.ClrForm, _clr_angular__WEBPACK_IMPORTED_MODULE_9__.ClrLayout, _clr_angular__WEBPACK_IMPORTED_MODULE_9__.ClrInput, _clr_angular__WEBPACK_IMPORTED_MODULE_9__.ClrInputContainer, _clr_angular__WEBPACK_IMPORTED_MODULE_9__.ClrSelect, _clr_angular__WEBPACK_IMPORTED_MODULE_9__.ClrSelectContainer, _clr_angular__WEBPACK_IMPORTED_MODULE_9__.ClrTabContent, _clr_angular__WEBPACK_IMPORTED_MODULE_9__.ClrTab, _clr_angular__WEBPACK_IMPORTED_MODULE_9__.ClrTabs, _clr_angular__WEBPACK_IMPORTED_MODULE_9__.ClrTabLink, _clr_angular__WEBPACK_IMPORTED_MODULE_9__["ÇlrTabsWillyWonka"], _clr_angular__WEBPACK_IMPORTED_MODULE_9__["ÇlrActiveOompaLoompa"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_10__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.MinValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.NgModel, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.NgForm, _shared_dynamic_form_dynamic_form_component__WEBPACK_IMPORTED_MODULE_1__.DynamicFormComponent, _shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_2__.WidgetComponent, _shared_date_range_form_date_range_form_component__WEBPACK_IMPORTED_MODULE_3__.DateRangeFormComponent, _shared_range_form_range_form_component__WEBPACK_IMPORTED_MODULE_4__.RangeFormComponent, _shared_delimited_form_delimited_form_component__WEBPACK_IMPORTED_MODULE_5__.DelimitedFormComponent], styles: [".clr-row[_ngcontent-%COMP%] {\r\n    margin: 0px;\r\n}\r\n\r\nh6[_ngcontent-%COMP%] {\r\n    margin-top: 0.5rem;\r\n}\r\n\r\nform[_ngcontent-%COMP%] {\r\n    padding-top: 0px;\r\n}\r\n\r\n.clr-form-control[_ngcontent-%COMP%] {\r\n    margin-top: 0.5rem;\r\n}\r\n\r\n.selection[_ngcontent-%COMP%]:hover {\r\n    background-color: #F3F6FA;\r\n}\r\n\r\n.type-selection[_ngcontent-%COMP%] {\r\n    min-width: 240px;\r\n}\r\n\r\n.feature-selection[_ngcontent-%COMP%] {\r\n    min-width: 300px;\r\n}\r\n\r\n.range-selection[_ngcontent-%COMP%] {\r\n    min-width: 600px;\r\n    padding-bottom: 12px;\r\n}\r\n\r\n.image-container[_ngcontent-%COMP%] {\r\n    margin-top: 1rem;\r\n    width: 100%;\r\n    background-color: #F0F0F0;\r\n    box-shadow: 0px 0px 6px 0px #C0C0C0 inset;\r\n}\r\n\r\n.card[_ngcontent-%COMP%] {\r\n    margin-top: 0.5rem;\r\n}\r\n\r\n.card-block[_ngcontent-%COMP%], .card-header[_ngcontent-%COMP%] {\r\n    padding: 0.2rem;\r\n}\r\n\r\n.meta-header[_ngcontent-%COMP%] {\r\n    font-size: 0.5rem;\r\n    display: flex;\r\n    flex-wrap: wrap;\r\n    \r\n    overflow-x: auto;\r\n}\r\n\r\n.meta-header-field-wrapper[_ngcontent-%COMP%] {\r\n\r\n}\r\n\r\n.meta-field[_ngcontent-%COMP%] {\r\n    padding: 0 0.1rem;\r\n    flex: 0 0 auto;\r\n}\r\n\r\n.meta-field[_ngcontent-%COMP%]::after {\r\n    content: \", \"\r\n}\r\n\r\n.meta-field[_ngcontent-%COMP%]:last-child::after {\r\n    content: \"\"\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJpbmFyeS1pbWFnZXMuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLFdBQVc7QUFDZjs7QUFFQTtJQUNJLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLGdCQUFnQjtBQUNwQjs7QUFFQTtJQUNJLGtCQUFrQjtBQUN0Qjs7QUFFQTtJQUNJLHlCQUF5QjtBQUM3Qjs7QUFFQTtJQUNJLGdCQUFnQjtBQUNwQjs7QUFFQTtJQUNJLGdCQUFnQjtBQUNwQjs7QUFFQTtJQUNJLGdCQUFnQjtJQUNoQixvQkFBb0I7QUFDeEI7O0FBRUE7SUFDSSxnQkFBZ0I7SUFDaEIsV0FBVztJQUNYLHlCQUF5QjtJQUN6Qix5Q0FBeUM7QUFDN0M7O0FBRUE7SUFDSSxrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxlQUFlO0FBQ25COztBQUVBO0lBQ0ksaUJBQWlCO0lBQ2pCLGFBQWE7SUFDYixlQUFlO0lBQ2YsNENBQTRDO0lBQzVDLGdCQUFnQjtBQUNwQjs7QUFFQTs7QUFFQTs7QUFFQTtJQUNJLGlCQUFpQjtJQUNqQixjQUFjO0FBQ2xCOztBQUVBO0lBQ0k7QUFDSjs7QUFFQTtJQUNJO0FBQ0oiLCJmaWxlIjoiYmluYXJ5LWltYWdlcy5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNsci1yb3cge1xyXG4gICAgbWFyZ2luOiAwcHg7XHJcbn1cclxuXHJcbmg2IHtcclxuICAgIG1hcmdpbi10b3A6IDAuNXJlbTtcclxufVxyXG5cclxuZm9ybSB7XHJcbiAgICBwYWRkaW5nLXRvcDogMHB4O1xyXG59XHJcblxyXG4uY2xyLWZvcm0tY29udHJvbCB7XHJcbiAgICBtYXJnaW4tdG9wOiAwLjVyZW07XHJcbn1cclxuXHJcbi5zZWxlY3Rpb246aG92ZXIge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0YzRjZGQTtcclxufVxyXG5cclxuLnR5cGUtc2VsZWN0aW9uIHtcclxuICAgIG1pbi13aWR0aDogMjQwcHg7XHJcbn1cclxuXHJcbi5mZWF0dXJlLXNlbGVjdGlvbiB7XHJcbiAgICBtaW4td2lkdGg6IDMwMHB4O1xyXG59XHJcblxyXG4ucmFuZ2Utc2VsZWN0aW9uIHtcclxuICAgIG1pbi13aWR0aDogNjAwcHg7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMTJweDtcclxufVxyXG5cclxuLmltYWdlLWNvbnRhaW5lciB7XHJcbiAgICBtYXJnaW4tdG9wOiAxcmVtO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRjBGMEYwO1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDBweCA2cHggMHB4ICNDMEMwQzAgaW5zZXQ7XHJcbn1cclxuXHJcbi5jYXJkIHtcclxuICAgIG1hcmdpbi10b3A6IDAuNXJlbTtcclxufVxyXG5cclxuLmNhcmQtYmxvY2ssIC5jYXJkLWhlYWRlciB7XHJcbiAgICBwYWRkaW5nOiAwLjJyZW07XHJcbn1cclxuXHJcbi5tZXRhLWhlYWRlciB7XHJcbiAgICBmb250LXNpemU6IDAuNXJlbTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LXdyYXA6IHdyYXA7XHJcbiAgICAvKiBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjsgYnJlYWtzIG92ZXJmbG93Ki9cclxuICAgIG92ZXJmbG93LXg6IGF1dG87XHJcbn1cclxuXHJcbi5tZXRhLWhlYWRlci1maWVsZC13cmFwcGVyIHtcclxuXHJcbn1cclxuXHJcbi5tZXRhLWZpZWxkIHtcclxuICAgIHBhZGRpbmc6IDAgMC4xcmVtO1xyXG4gICAgZmxleDogMCAwIGF1dG87XHJcbn1cclxuXHJcbi5tZXRhLWZpZWxkOjphZnRlciB7XHJcbiAgICBjb250ZW50OiBcIiwgXCJcclxufVxyXG5cclxuLm1ldGEtZmllbGQ6bGFzdC1jaGlsZDo6YWZ0ZXIge1xyXG4gICAgY29udGVudDogXCJcIlxyXG59XHJcbiJdfQ== */"] });


/***/ }),

/***/ 85892:
/*!***************************************************************!*\
  !*** ./src/app/widgets/binary-images/binary-images.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BinaryImagesModule": () => (/* binding */ BinaryImagesModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/shared/shared.module */ 44466);
/* harmony import */ var _binary_images_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./binary-images.component */ 90358);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);




class BinaryImagesModule {
}
BinaryImagesModule.entry = _binary_images_component__WEBPACK_IMPORTED_MODULE_1__.BinaryImagesComponent;
BinaryImagesModule.ɵfac = function BinaryImagesModule_Factory(t) { return new (t || BinaryImagesModule)(); };
BinaryImagesModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: BinaryImagesModule });
BinaryImagesModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
        app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](BinaryImagesModule, { declarations: [_binary_images_component__WEBPACK_IMPORTED_MODULE_1__.BinaryImagesComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
        app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule] }); })();


/***/ }),

/***/ 50774:
/*!*******************************************************!*\
  !*** ./src/app/widgets/binary-images/data.service.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DataService": () => (/* binding */ DataService),
/* harmony export */   "MAX_QUERY_SIZE": () => (/* binding */ MAX_QUERY_SIZE)
/* harmony export */ });
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var app_core_database_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/core/database.service */ 67084);



const MAX_QUERY_SIZE = 200;
class DataService {
    constructor(db) {
        this.db = db;
    }
    _query(queryStr, params, aggregated = false) {
        const queryObs = this.db.multiSearch(queryStr, params.database)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.map)(this.extractImages.bind(this)));
        return queryObs;
    }
    query(params) {
        let query = this.makeQueryTemplate(params);
        this.db.transformQueryWithNestedPath(query[1], params.nestedPath);
        return this._query(this.db.stringifyToNDJSON(query), params);
    }
    queryRange(params, field, min, max) {
        let query = this.makeQueryTemplate(params);
        const range = {};
        range[field] = { "gte": min, "lte": max };
        query[1]['query']['bool']['filter'].push({ "range": range });
        this.db.transformQueryWithNestedPath(query[1], params.nestedPath);
        return this._query(this.db.stringifyToNDJSON(query), params);
    }
    makeQueryTemplate(params) {
        const header = {
            index: params.index,
        };
        const body = {
            "_source": this.parseQueryFields(params),
            "size": MAX_QUERY_SIZE,
            "query": {
                "bool": {
                    "filter": []
                }
            }
        };
        if (params.timestampField) {
            body['sort'] = {};
            body['sort'][params.timestampField] = 'desc';
        }
        if (params.singleTerms) {
            Object.keys(params.singleTerms).forEach(k => {
                const term = {};
                term[k] = params.singleTerms[k];
                body['query']['bool']['filter'].push({ 'term': term });
            });
        }
        if (params.multiTerms) {
            Object.keys(params.multiTerms).forEach(k => {
                this.pushMultiTerms(body, k, params.multiTerms[k]);
            });
        }
        if (params.types && params.types.length > 0) {
            if (params.useDocumentType) {
                header['type'] = params.types;
            }
            else if (params.typeField) {
                this.pushMultiTerms(body, params.typeField, params.types);
            }
        }
        return [header, body];
    }
    parseQueryFields(params) {
        if (params.timestampField) {
            return [params.timestampField].concat(params.fields);
        }
        else {
            return params.fields;
        }
    }
    pushMultiTerms(queryBody, key, value) {
        const terms = {};
        terms[key] = value;
        queryBody['query']['bool']['filter'].push({ 'terms': terms });
    }
    extractImages(response) {
        return response['responses'][0]['hits']['hits'].map(hit => {
            if (!hit['_source'].hasOwnProperty('type')) {
                return Object.assign(hit['_source'], { 'type': hit['_type'] });
            }
            return hit['_source'];
        });
    }
}
DataService.ɵfac = function DataService_Factory(t) { return new (t || DataService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](app_core_database_service__WEBPACK_IMPORTED_MODULE_0__.DatabaseService)); };
DataService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({ token: DataService, factory: DataService.ɵfac, providedIn: 'root' });


/***/ })

}]);
//# sourceMappingURL=src_app_widgets_binary-images_binary-images_module_ts.js.map