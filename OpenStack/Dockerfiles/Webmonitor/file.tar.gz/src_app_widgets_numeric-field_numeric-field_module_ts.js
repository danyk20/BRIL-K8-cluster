"use strict";
(self["webpackChunkwebmonitor2"] = self["webpackChunkwebmonitor2"] || []).push([["src_app_widgets_numeric-field_numeric-field_module_ts"],{

/***/ 6778:
/*!***************************************************************!*\
  !*** ./src/app/widgets/numeric-field/numeric-field.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NumericFieldModule": () => (/* binding */ NumericFieldModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/shared/shared.module */ 44466);
/* harmony import */ var _numeric_field_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./numeric-field.component */ 82257);
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./data.service */ 79081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);





class NumericFieldModule {
}
NumericFieldModule.entry = _numeric_field_component__WEBPACK_IMPORTED_MODULE_1__.NumericFieldComponent;
NumericFieldModule.ɵfac = function NumericFieldModule_Factory(t) { return new (t || NumericFieldModule)(); };
NumericFieldModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: NumericFieldModule });
NumericFieldModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ providers: [_data_service__WEBPACK_IMPORTED_MODULE_2__.DataService], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
        app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](NumericFieldModule, { declarations: [_numeric_field_component__WEBPACK_IMPORTED_MODULE_1__.NumericFieldComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
        app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule] }); })();


/***/ })

}]);
//# sourceMappingURL=src_app_widgets_numeric-field_numeric-field_module_ts.js.map