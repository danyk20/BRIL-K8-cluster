"use strict";
(self["webpackChunkwebmonitor2"] = self["webpackChunkwebmonitor2"] || []).push([["src_app_widgets_vdm-bx_vdm-bx_module_ts"],{

/***/ 29377:
/*!****************************************************!*\
  !*** ./src/app/widgets/vdm-bx/vdm-bx.component.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VDMBXComponent": () => (/* binding */ VDMBXComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 20591);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 53158);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 81203);
/* harmony import */ var app_widgets_array_snapshot_array_snapshot_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/widgets/array-snapshot/array-snapshot.component */ 987);
/* harmony import */ var app_shared_string_plus_date_form_string_plus_date_form_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! app/shared/string-plus-date-form/string-plus-date-form.component */ 37054);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @clr/angular */ 4151);
/* harmony import */ var _shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../shared/widget/widget.component */ 81522);
/* harmony import */ var _shared_fill_run_ls_form_fill_run_ls_form_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/fill-run-ls-form/fill-run-ls-form.component */ 49207);









function VDMBXComponent_wm_fill_run_ls_form_4_Template(rf, ctx) { if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "wm-fill-run-ls-form", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("query", function VDMBXComponent_wm_fill_run_ls_form_4_Template_wm_fill_run_ls_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r5); const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r4.queryRunLs($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("fillEnabled", false)("runEnabled", true)("lsEnabled", true);
} }
function VDMBXComponent_clr_alert_6_Template(rf, ctx) { if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "clr-alert", 10)(1, "div", 11)(2, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, " This chart relies on WebGL technology, which is not supported or turned off in this browser. Would you like to try using fallback methods? ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "div", 13)(5, "button", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function VDMBXComponent_clr_alert_6_Template_button_click_5_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r7); const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r6.tryWebGLFallback()); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6, " Try fallback ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("clrAlertType", "alert-danger")("clrAlertClosable", false);
} }
class VDMBXComponent extends app_widgets_array_snapshot_array_snapshot_component__WEBPACK_IMPORTED_MODULE_0__.ArraySnapshotComponent {
    ngOnInit() {
        super.ngOnInit();
        this.widget = this.config['widget'];
        this.widget.detectorField = this.widget.detectorField || 'detector';
        this.widget.detectorFieldCase = this.widget.detectorFieldCase || 'upcase';
        this.wrapper.refreshEnabled = false;
        this.wrapper.startEnabled = false;
        this.widgetComponent.extraQueries = [{
                component: app_shared_string_plus_date_form_string_plus_date_form_component__WEBPACK_IMPORTED_MODULE_1__.StringPlusDateFormComponent,
                config: { key: 'vdmbx', label: 'Detector' }
            }];
        this.queryEventTypes.push('string_plus_date_query');
        this.resubscribeQueryEvents();
        // don't need to unsubscribe, because 'extraQueriesEvents' completes
        // when the widget is destroyed
        this.widgetComponent.extraQueriesEvents.subscribe((event) => {
            if (event.key === 'vdmbx') {
                this.queryDetectorAndTime(event);
            }
        });
    }
    refresh() {
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.empty)();
    }
    queryFromEvent(event) {
        if (event['type'] === 'string_plus_date_query') {
            this.widgetComponent.log('Received VDM-BX query', 'info');
            this.queryDetectorAndTime(event['payload']);
        }
        else {
            super.queryFromEvent(event);
        }
    }
    queryDetectorAndTime(event) {
        this.widgetComponent.stop();
        if (!event['text'] || !event['date']) {
            this.widgetComponent.log('Detector name and date must be specified', 'warning', 3500);
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.empty)();
        }
        const detector = this.transformDetectorName(event['text']);
        const detectorTerm = {};
        const tsRange = {};
        detectorTerm[this.widget.detectorField] = detector;
        if (this.widget.timestampUNIX) {
            tsRange[this.queryParams.timestampField] = { 'lte': event['ts'] };
        }
        else {
            tsRange[this.queryParams.timestampField] = { 'lte': event['dateStr'] };
        }
        const obs = this.dataService.queryTerms(this.queryParams, [detectorTerm], [tsRange]).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.map)(response => {
            return this.setData(response, detector + ' ');
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.catchError)(super.onQueryError.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.share)());
        obs.subscribe();
        return obs;
    }
    transformDetectorName(name) {
        if (this.widget.detectorFieldCase === 'upcase') {
            return name.toUpperCase();
        }
        else if (this.widget.detectorFieldCase === 'lowcase') {
            return name.toLowerCase();
        }
        else {
            return name;
        }
    }
}
VDMBXComponent.ɵfac = /*@__PURE__*/ function () { let ɵVDMBXComponent_BaseFactory; return function VDMBXComponent_Factory(t) { return (ɵVDMBXComponent_BaseFactory || (ɵVDMBXComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetInheritedFactory"](VDMBXComponent)))(t || VDMBXComponent); }; }();
VDMBXComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({ type: VDMBXComponent, selectors: [["wm-vdm-bx"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵInheritDefinitionFeature"]], decls: 9, vars: 4, consts: [[3, "config", "info", "refresh", "start", "timer"], ["widgetWrapper", ""], [1, "widget-options"], [1, "widget-queries"], [3, "fillEnabled", "runEnabled", "lsEnabled", "query", 4, "ngIf"], [1, "widget-content"], [3, "clrAlertType", "clrAlertClosable", 4, "ngIf"], [2, "height", "100%", "width", "100%"], ["plot", ""], [3, "fillEnabled", "runEnabled", "lsEnabled", "query"], [3, "clrAlertType", "clrAlertClosable"], ["clr-alert-item", "", 1, "alert-item"], [1, "alert-text"], [1, "alert-actions"], [1, "btn", "alert-action", 3, "click"]], template: function VDMBXComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "wm-widget", 0, 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("refresh", function VDMBXComponent_Template_wm_widget_refresh_0_listener() { return ctx.onRefreshEvent(); })("start", function VDMBXComponent_Template_wm_widget_start_0_listener() { return ctx.onStartEvent(); })("timer", function VDMBXComponent_Template_wm_widget_timer_0_listener() { return ctx.updateLive(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](4, VDMBXComponent_wm_fill_run_ls_form_4_Template, 1, 3, "wm-fill-run-ls-form", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](6, VDMBXComponent_clr_alert_6_Template, 7, 2, "clr-alert", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](7, "div", 7, 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("config", ctx.config.wrapper)("info", ctx.info);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.config.widget.runLsQueriesEnabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.needWebGLFallback);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_9__.NgIf, _clr_angular__WEBPACK_IMPORTED_MODULE_10__.ClrAlert, _clr_angular__WEBPACK_IMPORTED_MODULE_10__.ClrAlertText, _shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_2__.WidgetComponent, _shared_fill_run_ls_form_fill_run_ls_form_component__WEBPACK_IMPORTED_MODULE_3__.FillRunLsFormComponent], styles: [".widget-content[_ngcontent-%COMP%] {\r\n    width: 100%;\r\n    height: 100%;\r\n    overflow: hidden;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFycmF5LXNuYXBzaG90LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxXQUFXO0lBQ1gsWUFBWTtJQUNaLGdCQUFnQjtBQUNwQiIsImZpbGUiOiJhcnJheS1zbmFwc2hvdC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLndpZGdldC1jb250ZW50IHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxufVxyXG4iXX0= */"] });


/***/ }),

/***/ 25598:
/*!*************************************************!*\
  !*** ./src/app/widgets/vdm-bx/vdm-bx.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VDMBXModule": () => (/* binding */ VDMBXModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/shared/shared.module */ 44466);
/* harmony import */ var _vdm_bx_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./vdm-bx.component */ 29377);
/* harmony import */ var app_widgets_array_snapshot_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! app/widgets/array-snapshot/data.service */ 66036);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);





class VDMBXModule {
}
VDMBXModule.entry = _vdm_bx_component__WEBPACK_IMPORTED_MODULE_1__.VDMBXComponent;
VDMBXModule.ɵfac = function VDMBXModule_Factory(t) { return new (t || VDMBXModule)(); };
VDMBXModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: VDMBXModule });
VDMBXModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ providers: [app_widgets_array_snapshot_data_service__WEBPACK_IMPORTED_MODULE_2__.DataService], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
        app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](VDMBXModule, { declarations: [_vdm_bx_component__WEBPACK_IMPORTED_MODULE_1__.VDMBXComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
        app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule] }); })();


/***/ })

}]);
//# sourceMappingURL=src_app_widgets_vdm-bx_vdm-bx_module_ts.js.map