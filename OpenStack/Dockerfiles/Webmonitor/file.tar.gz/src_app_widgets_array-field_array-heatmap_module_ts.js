"use strict";
(self["webpackChunkwebmonitor2"] = self["webpackChunkwebmonitor2"] || []).push([["src_app_widgets_array-field_array-heatmap_module_ts"],{

/***/ 39750:
/*!****************************************************************!*\
  !*** ./src/app/widgets/array-field/array-heatmap.component.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ArrayHeatmapComponent": () => (/* binding */ ArrayHeatmapComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs */ 20591);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 19337);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs/operators */ 53158);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs/operators */ 81203);
/* harmony import */ var app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/shared/chart-utils */ 99593);
/* harmony import */ var app_widgets_base_chart_widget__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! app/widgets/base/chart-widget */ 47397);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var app_core_database_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! app/core/database.service */ 67084);
/* harmony import */ var app_core_event_bus_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! app/core/event-bus.service */ 40699);
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./data.service */ 41977);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/widget/widget.component */ 81522);
/* harmony import */ var _shared_date_range_form_date_range_form_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/date-range-form/date-range-form.component */ 63747);
/* harmony import */ var _shared_fill_run_ls_form_fill_run_ls_form_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../shared/fill-run-ls-form/fill-run-ls-form.component */ 49207);












function ArrayHeatmapComponent_wm_fill_run_ls_form_5_Template(rf, ctx) { if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "wm-fill-run-ls-form", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("query", function ArrayHeatmapComponent_wm_fill_run_ls_form_5_Template_wm_fill_run_ls_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r5); const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r4.queryFillRun($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("fillEnabled", true)("runEnabled", false)("lsEnabled", false);
} }
function ArrayHeatmapComponent_wm_fill_run_ls_form_6_Template(rf, ctx) { if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "wm-fill-run-ls-form", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("query", function ArrayHeatmapComponent_wm_fill_run_ls_form_6_Template_wm_fill_run_ls_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵrestoreView"](_r7); const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵresetView"](ctx_r6.queryFillRun($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("fillEnabled", false)("runEnabled", true)("lsEnabled", false);
} }
class ArrayHeatmapComponent extends app_widgets_base_chart_widget__WEBPACK_IMPORTED_MODULE_1__.ChartWidget {
    constructor(db, eventBus, dataService) {
        super(eventBus);
        this.db = db;
        this.eventBus = eventBus;
        this.dataService = dataService;
    }
    ngOnInit() {
        super.ngOnInit({
            'liveWindow': 600000,
            'refreshSize': 100,
            'timestampField': 'timestamp'
        });
        this.queryParams = {
            database: this.widget['database'],
            index: this.widget['index'],
            documentType: this.widget['documentType'],
            timestampField: this.widget['timestampField'],
            field: this.widget['field'],
            terms: this.widget['terms'],
            fillField: this.widget['fillField'],
            runField: this.widget['runField'],
            extraFields: this.widget['extraFields'] || [],
            series: []
        };
    }
    ngAfterViewInit() {
        super.ngAfterViewInit();
        if (!this.wrapper.started) {
            this.refresh();
        }
    }
    queryFromEvent(event) {
        if (event['type'] === 'time_range_query') {
            this.widgetComponent.log('Received time range query', 'info');
            this.queryRange(event['payload']);
        }
        else if (event['type'] === 'fill_run_ls_query') {
            if (this.widget['fillQueriesEnabled'] || this.widget['runQueriesEnabled']) {
                this.widgetComponent.log('Received FILL/RUN query', 'info');
                this.queryFillRun(event['payload']);
            }
        }
    }
    onRefreshEvent() {
        this.refresh();
    }
    onStartEvent() {
        this.updateLive();
    }
    onQueryError(error) {
        this.setData([]);
        throw (error);
    }
    refresh(size) {
        size = size || this.widget.refreshSize;
        this.disableInteraction();
        const obs = this.dataService.queryNewest(this.queryParams, size)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.map)(this.filterZValues.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.tap)(this.setData.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.tap)(this.enableInteraction.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.catchError)(this.onQueryError.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.share)());
        obs.subscribe();
        return obs;
    }
    offsetYValues(newSeries) {
        if (this.widget.yOffset) {
            const y = newSeries['z'].map((v, i) => {
                return i + this.widget.yOffset;
            });
            newSeries['y'] = y;
        }
        return newSeries;
    }
    setData(newData) {
        this.chartData.length = 0;
        if (!newData) {
            Plotly.redraw(this.plot.nativeElement, this.chartData);
            return;
        }
        const newSeries = this.getChartSeriesTemplate();
        newSeries.x = newData.map(hit => hit[this.queryParams.timestampField]);
        newSeries.z = [];
        const nRows = Math.max.apply(Math, newData.map(point => point[this.queryParams.field].length));
        for (let r = 0; r < nRows; ++r) {
            newSeries.z.push(newData.map(hit => hit[this.queryParams.field][r]));
        }
        this.offsetYValues(newSeries);
        this.chartData.push(newSeries);
        app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__.setAutorange(this.chartLayout);
        Plotly.redraw(this.plot.nativeElement, this.chartData, this.chartLayout);
    }
    queryRange(range) {
        this.widgetComponent.stop();
        const obs = this.dataService.queryRange(this.queryParams, range['strFrom'], range['strTo'])
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.map)(this.filterZValues.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.tap)(this.setData.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.tap)(this.enableInteraction.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.catchError)(this.onQueryError.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.share)());
        this.disableInteraction();
        obs.subscribe(() => {
            this.setXZoom(range['strFrom'], range['strTo']);
        });
        return obs;
    }
    queryFillRun(event) {
        this.widgetComponent.stop();
        const term = {};
        if (event['run']) {
            term[this.queryParams['runField']] = event['run'];
        }
        else if (event['fill']) {
            term[this.queryParams['fillField']] = event['fill'];
        }
        else {
            this.widgetComponent.log('One of [FILL,RUN] must be specified', 'warning');
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_13__.empty)();
        }
        const obs = this.dataService.queryTerm(this.queryParams, term)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.map)(this.setData.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.tap)(this.enableInteraction.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.catchError)(this.onQueryError.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.share)());
        this.disableInteraction();
        obs.subscribe();
        return obs;
    }
    updateLive() {
        if (this.chartData.length < 1 || this.chartData[0].x.length < 1) {
            this.refresh().subscribe(this.setXZoomToLiveWindow.bind(this));
            return;
        }
        else {
            this.dropPointsOutsideLiveWindow();
            this.setXZoomToLiveWindow();
        }
        const x = this.chartData[0].x;
        const lastX = x[x.length - 1];
        this.disableInteraction();
        this.dataService.queryNewestSince(this.queryParams, lastX, false)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.map)(resp => this.filterZValues(resp)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.tap)(newData => {
            if (newData.length < 1) {
                return;
            }
            this.chartData[0].x = this.chartData[0].x.concat(newData.map(hit => hit[this.queryParams.timestampField]));
            const z = this.chartData[0].z;
            const nRows = z.length;
            for (let r = 0; r < nRows; ++r) {
                z[r] = z[r].concat(newData.map(hit => hit[this.queryParams.field][r]));
            }
        }))
            .subscribe(() => {
            this.setXZoomToLiveWindow();
            if (this.dropPointsOutsideLiveWindow()) {
                Plotly.redraw(this.plot.nativeElement, this.chartData);
            }
            this.enableInteraction();
        });
    }
    dropPointsOutsideLiveWindow() {
        const x = this.chartData[0].x;
        const lastX = new Date(x[x.length - 1]);
        const lastXTime = lastX.getTime();
        const liveWindow = this.widget.liveWindow;
        const z = this.chartData[0].z;
        const nRows = z.length;
        let dropped = 0;
        while (lastXTime - (new Date(x[0])).getTime() > liveWindow) {
            dropped += 1;
            x.shift();
            for (let r = 0; r < nRows; ++r) {
                z[r].shift();
            }
        }
        return dropped;
    }
    setXZoom(min, max) {
        this.chartLayout['xaxis']['autorange'] = false;
        this.chartLayout['xaxis']['range'] = [min, max];
        Plotly.relayout(this.plot.nativeElement, this.chartLayout);
    }
    setXZoomToLiveWindow() {
        const x = this.chartData[0].x;
        const lastX = new Date(x[x.length - 1]);
        const max = lastX.getTime();
        const min = max - this.widget.liveWindow;
        this.setXZoom((new Date(min)).toISOString(), (new Date(max)).toISOString());
        Plotly.relayout(this.plot.nativeElement, this.chartLayout);
    }
    getChartSeriesTemplate() {
        return {
            type: 'heatmap',
            z: [],
            zauto: false,
            x: [],
            xgap: 0.2,
            connectgaps: false,
            y: undefined,
            xtype: "array",
            hoverinfo: "x+y+z+text",
            colorbar: {
                title: this.widget.zAxisTitle,
                titleside: "right",
                x: 1,
                thickness: 14,
                tickangle: -90
            },
            colorscale: [
                [0, 'rgb(0,0,255)'],
                [0.25, 'rgb(0,255,255)'],
                [0.5, 'rgb(0,255,0)'],
                [0.75, 'rgb(255,255,0)'],
                [1, 'rgb(255,0,0)']
            ]
        };
    }
    filterZValues(data) {
        const threshold = this.widget.filterZThreshold;
        const filterZeros = this.widget.filterZeros;
        if (Number.isFinite(threshold)) {
            data.forEach(hit => {
                hit[this.queryParams.field] = hit[this.queryParams.field]
                    .map(val => val < threshold ? null : val);
            });
        }
        if (filterZeros) {
            data.forEach(hit => {
                hit[this.queryParams.field] = hit[this.queryParams.field]
                    .map(val => val === 0 ? null : val);
            });
        }
        return data;
    }
}
ArrayHeatmapComponent.ɵfac = function ArrayHeatmapComponent_Factory(t) { return new (t || ArrayHeatmapComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](app_core_database_service__WEBPACK_IMPORTED_MODULE_2__.DatabaseService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](app_core_event_bus_service__WEBPACK_IMPORTED_MODULE_3__.EventBusService), _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdirectiveInject"](_data_service__WEBPACK_IMPORTED_MODULE_4__.DataService)); };
ArrayHeatmapComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineComponent"]({ type: ArrayHeatmapComponent, selectors: [["wm-array-heatmap"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵInheritDefinitionFeature"]], decls: 10, vars: 3, consts: [[3, "config", "refresh", "start", "timer"], ["widgetWrapper", ""], [1, "widget-options"], [1, "widget-queries"], [3, "query"], [3, "fillEnabled", "runEnabled", "lsEnabled", "query", 4, "ngIf"], [1, "widget-content"], [2, "height", "100%", "width", "100%"], ["plot", ""], [3, "fillEnabled", "runEnabled", "lsEnabled", "query"]], template: function ArrayHeatmapComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](0, "wm-widget", 0, 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("refresh", function ArrayHeatmapComponent_Template_wm_widget_refresh_0_listener() { return ctx.onRefreshEvent(); })("start", function ArrayHeatmapComponent_Template_wm_widget_start_0_listener() { return ctx.onStartEvent(); })("timer", function ArrayHeatmapComponent_Template_wm_widget_timer_0_listener() { return ctx.updateLive(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](3, "div", 3)(4, "wm-date-range-form", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵlistener"]("query", function ArrayHeatmapComponent_Template_wm_date_range_form_query_4_listener($event) { return ctx.queryRange($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](5, ArrayHeatmapComponent_wm_fill_run_ls_form_5_Template, 1, 3, "wm-fill-run-ls-form", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵtemplate"](6, ArrayHeatmapComponent_wm_fill_run_ls_form_6_Template, 1, 3, "wm-fill-run-ls-form", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementStart"](7, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelement"](8, "div", 7, 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵelementEnd"]()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("config", ctx.config.wrapper);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.config.widget.fillQueriesEnabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵproperty"]("ngIf", ctx.config.widget.runQueriesEnabled);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_14__.NgIf, _shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_5__.WidgetComponent, _shared_date_range_form_date_range_form_component__WEBPACK_IMPORTED_MODULE_6__.DateRangeFormComponent, _shared_fill_run_ls_form_fill_run_ls_form_component__WEBPACK_IMPORTED_MODULE_7__.FillRunLsFormComponent], styles: [".widget-content[_ngcontent-%COMP%] {\r\n    width: 100%;\r\n    height: 100%;\r\n    overflow: hidden;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFycmF5LWhlYXRtYXAuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLFdBQVc7SUFDWCxZQUFZO0lBQ1osZ0JBQWdCO0FBQ3BCIiwiZmlsZSI6ImFycmF5LWhlYXRtYXAuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi53aWRnZXQtY29udGVudCB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbn1cclxuIl19 */"] });


/***/ }),

/***/ 72585:
/*!*************************************************************!*\
  !*** ./src/app/widgets/array-field/array-heatmap.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ArrayHeatmapModule": () => (/* binding */ ArrayHeatmapModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _array_heatmap_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./array-heatmap.component */ 39750);
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./data.service */ 41977);
/* harmony import */ var app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! app/shared/shared.module */ 44466);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);





class ArrayHeatmapModule {
}
ArrayHeatmapModule.entry = _array_heatmap_component__WEBPACK_IMPORTED_MODULE_0__.ArrayHeatmapComponent;
ArrayHeatmapModule.ɵfac = function ArrayHeatmapModule_Factory(t) { return new (t || ArrayHeatmapModule)(); };
ArrayHeatmapModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: ArrayHeatmapModule });
ArrayHeatmapModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ providers: [_data_service__WEBPACK_IMPORTED_MODULE_1__.DataService], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
        app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](ArrayHeatmapModule, { declarations: [_array_heatmap_component__WEBPACK_IMPORTED_MODULE_0__.ArrayHeatmapComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
        app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule] }); })();


/***/ })

}]);
//# sourceMappingURL=src_app_widgets_array-field_array-heatmap_module_ts.js.map