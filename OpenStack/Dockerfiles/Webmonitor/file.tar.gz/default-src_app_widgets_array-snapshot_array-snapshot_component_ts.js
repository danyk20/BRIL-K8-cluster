"use strict";
(self["webpackChunkwebmonitor2"] = self["webpackChunkwebmonitor2"] || []).push([["default-src_app_widgets_array-snapshot_array-snapshot_component_ts"],{

/***/ 987:
/*!********************************************************************!*\
  !*** ./src/app/widgets/array-snapshot/array-snapshot.component.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ArraySnapshotComponent": () => (/* binding */ ArraySnapshotComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs */ 20591);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 53158);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ 81203);
/* harmony import */ var app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/shared/chart-utils */ 99593);
/* harmony import */ var app_widgets_base_chart_widget__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! app/widgets/base/chart-widget */ 47397);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var app_core_event_bus_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! app/core/event-bus.service */ 40699);
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./data.service */ 66036);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @clr/angular */ 4151);
/* harmony import */ var _shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/widget/widget.component */ 81522);
/* harmony import */ var _shared_fill_run_ls_form_fill_run_ls_form_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/fill-run-ls-form/fill-run-ls-form.component */ 49207);











function ArraySnapshotComponent_wm_fill_run_ls_form_4_Template(rf, ctx) { if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "wm-fill-run-ls-form", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("query", function ArraySnapshotComponent_wm_fill_run_ls_form_4_Template_wm_fill_run_ls_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r5); const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r4.queryRunLs($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("fillEnabled", false)("runEnabled", true)("lsEnabled", true);
} }
function ArraySnapshotComponent_clr_alert_6_Template(rf, ctx) { if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "clr-alert", 10)(1, "div", 11)(2, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](3, " This chart relies on WebGL technology, which is not supported or turned off in this browser. Would you like to try using fallback methods? ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](4, "div", 13)(5, "button", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("click", function ArraySnapshotComponent_clr_alert_6_Template_button_click_5_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵrestoreView"](_r7); const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵresetView"](ctx_r6.tryWebGLFallback()); });
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtext"](6, " Try fallback ");
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()()()();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("clrAlertType", "alert-danger")("clrAlertClosable", false);
} }
class ArraySnapshotComponent extends app_widgets_base_chart_widget__WEBPACK_IMPORTED_MODULE_1__.ChartWidget {
    constructor(eventBus, dataService) {
        super(eventBus);
        this.eventBus = eventBus;
        this.dataService = dataService;
        this.series = [];
        this.info = {};
        this.needWebGLFallback = false;
    }
    ngOnInit() {
        super.ngOnInit({ 'timestampField': 'timestamp' });
        this.widget = this.config['widget'];
        this.configureLayout();
        if (this.widget.chartType && this.widget.chartType.toLowerCase() === 'scattergl') {
            if (!app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__.detectWebGLContext()) {
                this.needWebGLFallback = true;
            }
        }
        this.queryParams = {
            database: this.widget.database,
            timestampField: this.widget.timestampField,
            index: this.widget.index,
            documentType: this.widget.documentType,
            terms: this.widget.terms,
            fields: this.widget.fields,
            runField: this.widget.runField,
            lsField: this.widget.lsField,
            nestedPath: this.widget.nestedPath
        };
    }
    ngAfterViewInit() {
        if (this.needWebGLFallback) {
            return;
        }
        super.ngAfterViewInit();
        if (!this.wrapper.started) {
            this.refresh();
        }
    }
    configureLayout() {
        const update = {
            xaxis: {
                type: 'linear',
                title: this.widget.xAxisTitle
            },
            yaxis: { title: this.widget.yAxisTitle },
            barmode: 'group'
        };
        this.chartLayout = Object.assign(this.chartLayout, update);
    }
    queryFromEvent(event) {
        if (event['type'] === 'fill_run_ls_query') {
            if (this.widget.runLsQueriesEnabled) {
                this.widgetComponent.log('Received RUN,LS query', 'info');
                this.queryRunLs(event['payload']);
            }
        }
    }
    onRefreshEvent() {
        this.widgetComponent.stop();
        this.refresh();
    }
    onStartEvent() {
        this.refresh();
    }
    onQueryError(error) {
        this.setData([]);
        this.widgetComponent.log(String(error), 'danger', 5000);
        throw (error);
    }
    refresh() {
        if (this.needWebGLFallback) {
            return;
        }
        const obs = this.dataService.queryNewest(this.queryParams).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)(this.setData.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.catchError)(this.onQueryError.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.share)());
        obs.subscribe();
        return obs;
    }
    queryRunLs(event) {
        this.widgetComponent.stop();
        if (!event['run'] || !event['ls']) {
            this.widgetComponent.log('RUN and LS must be specified', 'warning', 3500);
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_10__.empty)();
        }
        const runTerm = {};
        const lsTerm = {};
        runTerm[this.queryParams.runField] = event['run'];
        lsTerm[this.queryParams.lsField] = event['ls'];
        const obs = this.dataService.queryTerms(this.queryParams, [runTerm, lsTerm]).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.map)(this.setData.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.catchError)(this.onQueryError.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.share)());
        obs.subscribe();
        return obs;
    }
    setData(newData, namePrefix) {
        if (!newData[0]) {
            this.widgetComponent.log('Cannot draw chart: no data.', 'danger', 3500);
            return;
        }
        this.chartData.length = 0;
        this.series.length = 0;
        this.queryParams.fields.forEach((f, i) => {
            let y = newData[0][f.name];
            if (f.mask) {
                y = this.applyMask(y, newData[0][f.mask]);
            }
            const newSeries = {
                y: y,
                name: (namePrefix ? namePrefix : '') + f.seriesName,
                type: this.widget.chartType || 'bar',
                mode: 'markers',
                marker: { size: 5 }
            };
            if (f.error && newData[0][f.error]) {
                newSeries['error_y'] = {
                    type: 'data',
                    visible: true,
                    color: 'black',
                    array: newData[0][f.error]
                };
                // workaround for scattergl with error bars: needs 'lines'
                // Maybe not exactly the same, but seems related issue:
                // https://github.com/plotly/plotly.js/issues/2900
                newSeries['mode'] = 'lines+markers';
                newSeries['line'] = { width: 0 };
            }
            this.offsetXValues(newSeries);
            this.chartData.push(newSeries);
            this.series.push(newSeries);
        });
        this.updateAnnotation(newData);
        app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__.setAutorange(this.chartLayout);
        Plotly.redraw(this.plot.nativeElement, this.chartData, this.chartLayout);
        this.updateInfo(newData);
    }
    applyMask(data, mask) {
        return data.map((v, i) => mask[i] ? v : null);
    }
    updateInfo(newData) {
        this.info = {
            timestamp: newData[0][this.queryParams.timestampField]
        };
    }
    updateLive() {
        return this.refresh();
    }
    updateAnnotation(newData) {
        this.chartLayout['annotations'] = [{
                y: 1,
                x: 0.5,
                xref: 'paper',
                yref: 'paper',
                xanchor: 'middle',
                yanchor: 'top',
                bgcolor: 'FFFFFF80',
                text: this.tsToChartTimestamp(newData[0][this.widget.timestampField]),
                showarrow: false,
                font: { size: 18 }
            }];
    }
    offsetXValues(newSeries) {
        if (this.widget.xOffset) {
            const x = newSeries['y'].map((v, i) => {
                return i + this.widget.xOffset;
            });
            newSeries['x'] = x;
        }
        return newSeries;
    }
    tryWebGLFallback() {
        if (this.needWebGLFallback &&
            this.widget.chartType === 'scattergl') {
            this.widget.chartType = 'scatter';
            this.needWebGLFallback = false;
            this.ngAfterViewInit();
        }
    }
}
ArraySnapshotComponent.ɵfac = function ArraySnapshotComponent_Factory(t) { return new (t || ArraySnapshotComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](app_core_event_bus_service__WEBPACK_IMPORTED_MODULE_2__.EventBusService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdirectiveInject"](_data_service__WEBPACK_IMPORTED_MODULE_3__.DataService)); };
ArraySnapshotComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineComponent"]({ type: ArraySnapshotComponent, selectors: [["wm-array-snapshot"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵInheritDefinitionFeature"]], decls: 9, vars: 4, consts: [[3, "config", "info", "refresh", "start", "timer"], ["widgetWrapper", ""], [1, "widget-options"], [1, "widget-queries"], [3, "fillEnabled", "runEnabled", "lsEnabled", "query", 4, "ngIf"], [1, "widget-content"], [3, "clrAlertType", "clrAlertClosable", 4, "ngIf"], [2, "height", "100%", "width", "100%"], ["plot", ""], [3, "fillEnabled", "runEnabled", "lsEnabled", "query"], [3, "clrAlertType", "clrAlertClosable"], ["clr-alert-item", "", 1, "alert-item"], [1, "alert-text"], [1, "alert-actions"], [1, "btn", "alert-action", 3, "click"]], template: function ArraySnapshotComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](0, "wm-widget", 0, 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵlistener"]("refresh", function ArraySnapshotComponent_Template_wm_widget_refresh_0_listener() { return ctx.onRefreshEvent(); })("start", function ArraySnapshotComponent_Template_wm_widget_start_0_listener() { return ctx.onStartEvent(); })("timer", function ArraySnapshotComponent_Template_wm_widget_timer_0_listener() { return ctx.updateLive(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](4, ArraySnapshotComponent_wm_fill_run_ls_form_4_Template, 1, 3, "wm-fill-run-ls-form", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵtemplate"](6, ArraySnapshotComponent_clr_alert_6_Template, 7, 2, "clr-alert", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelement"](7, "div", 7, 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵelementEnd"]()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("config", ctx.config.wrapper)("info", ctx.info);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.config.widget.runLsQueriesEnabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵproperty"]("ngIf", ctx.needWebGLFallback);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_11__.NgIf, _clr_angular__WEBPACK_IMPORTED_MODULE_12__.ClrAlert, _clr_angular__WEBPACK_IMPORTED_MODULE_12__.ClrAlertText, _shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_4__.WidgetComponent, _shared_fill_run_ls_form_fill_run_ls_form_component__WEBPACK_IMPORTED_MODULE_5__.FillRunLsFormComponent], styles: [".widget-content[_ngcontent-%COMP%] {\r\n    width: 100%;\r\n    height: 100%;\r\n    overflow: hidden;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFycmF5LXNuYXBzaG90LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxXQUFXO0lBQ1gsWUFBWTtJQUNaLGdCQUFnQjtBQUNwQiIsImZpbGUiOiJhcnJheS1zbmFwc2hvdC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLndpZGdldC1jb250ZW50IHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxufVxyXG4iXX0= */"] });


/***/ }),

/***/ 66036:
/*!********************************************************!*\
  !*** ./src/app/widgets/array-snapshot/data.service.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DataService": () => (/* binding */ DataService)
/* harmony export */ });
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var app_core_database_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/core/database.service */ 67084);



class DataService {
    constructor(db) {
        this.db = db;
    }
    queryTerms(params, terms, ranges) {
        let query = this.makeQuery(params);
        if (terms.length) {
            terms.forEach(t => {
                query[1]['query']['bool']['filter'].push({ "term": t });
            });
        }
        if (ranges && ranges.length) {
            ranges.forEach(r => {
                query[1]['query']['bool']['filter'].push({ "range": r });
            });
        }
        this.db.transformQueryWithNestedPath(query[1], params.nestedPath);
        return this.db.multiSearch(this.db.stringifyToNDJSON(query), params.database)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.map)(response => this.extractResponseFields(response, params)));
    }
    queryNewest(params) {
        let query = this.makeQuery(params);
        this.db.transformQueryWithNestedPath(query[1], params.nestedPath);
        return this.db.multiSearch(this.db.stringifyToNDJSON(query), params.database)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.map)(response => this.extractResponseFields(response, params)));
    }
    makeQuery(params) {
        const header = {
            "index": params.index,
            "type": params.documentType
        };
        const body = {
            "_source": this.parseQueryFields(params),
            "size": 1,
            "sort": {},
            "query": {
                "bool": {
                    "filter": []
                }
            }
        };
        body['sort'][params.timestampField || 'timestamp'] = 'desc';
        if (params.terms) {
            Object.keys(params.terms).forEach(k => {
                const term = {};
                term[k] = params.terms[k];
                body['query']['bool']['filter'].push({ "term": term });
            });
        }
        return [header, body];
    }
    parseQueryFields(params) {
        const fields = [params.timestampField || 'timestamp'];
        params.fields.forEach(f => {
            fields.push(f.name);
            if (f.mask) {
                fields.push(f.mask);
            }
            if (f.error) {
                fields.push(f.error);
            }
        });
        return fields;
    }
    extractResponseFields(response, params) {
        response = response['responses'][0]['hits']['hits']
            .map(hit => hit['_source']);
        if (params.nestedPath) {
            response = response.map(hit => hit[params.nestedPath]);
        }
        return response;
    }
}
DataService.ɵfac = function DataService_Factory(t) { return new (t || DataService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](app_core_database_service__WEBPACK_IMPORTED_MODULE_0__.DatabaseService)); };
DataService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({ token: DataService, factory: DataService.ɵfac });


/***/ })

}]);
//# sourceMappingURL=default-src_app_widgets_array-snapshot_array-snapshot_component_ts.js.map