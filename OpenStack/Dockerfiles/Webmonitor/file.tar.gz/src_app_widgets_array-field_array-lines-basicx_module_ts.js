"use strict";
(self["webpackChunkwebmonitor2"] = self["webpackChunkwebmonitor2"] || []).push([["src_app_widgets_array-field_array-lines-basicx_module_ts"],{

/***/ 44990:
/*!*********************************************************************!*\
  !*** ./src/app/widgets/array-field/array-lines-basicx.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ArrayLinesBasicXComponent": () => (/* binding */ ArrayLinesBasicXComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 20591);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 19337);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 53158);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 81203);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var _array_lines_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./array-lines.component */ 14363);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../shared/widget/widget.component */ 81522);
/* harmony import */ var _shared_date_range_form_date_range_form_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../shared/date-range-form/date-range-form.component */ 63747);
/* harmony import */ var _shared_fill_run_ls_form_fill_run_ls_form_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/fill-run-ls-form/fill-run-ls-form.component */ 49207);
/* harmony import */ var _shared_range_form_range_form_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/range-form/range-form.component */ 2199);









function ArrayLinesBasicXComponent_wm_date_range_form_4_Template(rf, ctx) { if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "wm-date-range-form", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("query", function ArrayLinesBasicXComponent_wm_date_range_form_4_Template_wm_date_range_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r7); const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r6.queryRange($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} }
function ArrayLinesBasicXComponent_wm_fill_run_ls_form_5_Template(rf, ctx) { if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "wm-fill-run-ls-form", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("query", function ArrayLinesBasicXComponent_wm_fill_run_ls_form_5_Template_wm_fill_run_ls_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r9); const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r8.queryFillRun($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("fillEnabled", true)("runEnabled", false)("lsEnabled", false);
} }
function ArrayLinesBasicXComponent_wm_fill_run_ls_form_6_Template(rf, ctx) { if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "wm-fill-run-ls-form", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("query", function ArrayLinesBasicXComponent_wm_fill_run_ls_form_6_Template_wm_fill_run_ls_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r11); const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r10.queryFillRun($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("fillEnabled", false)("runEnabled", true)("lsEnabled", false);
} }
function ArrayLinesBasicXComponent_wm_range_form_7_Template(rf, ctx) { if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "wm-range-form", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("query", function ArrayLinesBasicXComponent_wm_range_form_7_Template_wm_range_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r13); const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r12.queryFromEvent($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("key", ctx_r4.wi.xField);
} }
class ArrayLinesBasicXComponent extends _array_lines_component__WEBPACK_IMPORTED_MODULE_0__.ArrayLinesComponent {
    setupWidget() {
        this.wi = super.setupWidget();
        this.wi['timestampField'] = undefined;
        this.queryParams['timestampField'] = undefined;
        return this.wi;
    }
    ngAfterViewInit() {
        super.ngAfterViewInit();
        const xAxisTitle = this.wi.xAxisTitle ? this.wi.xAxisTitle : this.wi.xField;
        const xAxisType = this.wi.xAxisType ? this.wi.xAxisType : 'category';
        this.chartLayout.xaxis.title = xAxisTitle;
        this.chartLayout.xaxis.type = xAxisType;
    }
    queryFromEvent(event) {
        if (event['type'] === 'range_query') {
            this.queryFillRun(event['payload']);
        }
        else if (this.wi.histogramAggregatedQuery) {
            this.queryFillRun(event);
        }
        else {
            this.onBasicXRangeQuery(event);
        }
    }
    refresh(size) {
        size = Number.isInteger(size) ? size : this.wi.refreshSize || 20;
        this.disableInteraction();
        const obs = this.dataService.queryBasicX(this.queryParams, this.wi.xField, undefined, undefined, size).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.tap)(() => this.aggregated = false), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.tap)(this.setChartData.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.tap)(this.enableInteraction.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.catchError)(this.onQueryError.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.share)());
        obs.subscribe();
        return obs;
    }
    onBasicXRangeQuery(event) {
        console.log(event);
        this.disableInteraction();
        const obs = this.dataService.queryBasicX(this.queryParams, this.wi.xField, event.min, event.max).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.tap)(() => this.aggregated = false), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.tap)(this.setChartData.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.tap)(this.enableInteraction.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.catchError)(this.onQueryError.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.share)());
        obs.subscribe();
        return obs;
    }
    _parseXValues(hits) {
        return hits.map(hit => hit[this.wi.xField]);
    }
    queryRange(range) {
        throw new Error("Date range query not supproted on array-lines-basicx widget");
    }
    queryFillRun(event) {
        this.widgetComponent.stop();
        if (Number.isNaN(event['min']) && Number.isNaN(event['max'])) {
            console.log("NaN");
            this.widgetComponent.log('Specify Min fill and/or Max fill', 'danger');
            return rxjs__WEBPACK_IMPORTED_MODULE_9__.EMPTY;
        }
        this.disableInteraction();
        let obs;
        obs = this.dataService.queryRangeAggregated(this.queryParams, event['min'], event['max'], this.wi.aggregationAlgo).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.tap)(() => this.aggregated = true));
        obs = obs.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.map)(this.setChartData.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.tap)(this.enableInteraction.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.catchError)(this.onQueryError.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.share)());
        this.disableInteraction();
        obs.subscribe();
    }
    updateLive() {
        throw new Error("Live update not supproted on array-lines-basicx widget");
    }
    dropPointsOutsideLiveWindow(trace) {
        throw new Error("dropPointsOutsideLiveWindow not supproted on array-lines-basicx widget");
    }
}
ArrayLinesBasicXComponent.ɵfac = /*@__PURE__*/ function () { let ɵArrayLinesBasicXComponent_BaseFactory; return function ArrayLinesBasicXComponent_Factory(t) { return (ɵArrayLinesBasicXComponent_BaseFactory || (ɵArrayLinesBasicXComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetInheritedFactory"](ArrayLinesBasicXComponent)))(t || ArrayLinesBasicXComponent); }; }();
ArrayLinesBasicXComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({ type: ArrayLinesBasicXComponent, selectors: [["wm-widget-array-lines"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵInheritDefinitionFeature"]], decls: 11, vars: 6, consts: [[3, "config", "info", "refresh", "start", "timer"], ["widgetWrapper", ""], [1, "widget-options"], [1, "widget-queries"], [3, "query", 4, "ngIf"], [3, "fillEnabled", "runEnabled", "lsEnabled", "query", 4, "ngIf"], ["inputType", "number", 3, "key", "query", 4, "ngIf"], [1, "widget-content"], [2, "height", "100%", "width", "100%"], ["plot", ""], [3, "query"], [3, "fillEnabled", "runEnabled", "lsEnabled", "query"], ["inputType", "number", 3, "key", "query"]], template: function ArrayLinesBasicXComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "wm-widget", 0, 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("refresh", function ArrayLinesBasicXComponent_Template_wm_widget_refresh_0_listener() { return ctx.onRefreshEvent(); })("start", function ArrayLinesBasicXComponent_Template_wm_widget_start_0_listener() { return ctx.onStartEvent(); })("timer", function ArrayLinesBasicXComponent_Template_wm_widget_timer_0_listener() { return ctx.updateLive(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](4, ArrayLinesBasicXComponent_wm_date_range_form_4_Template, 1, 0, "wm-date-range-form", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](5, ArrayLinesBasicXComponent_wm_fill_run_ls_form_5_Template, 1, 3, "wm-fill-run-ls-form", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](6, ArrayLinesBasicXComponent_wm_fill_run_ls_form_6_Template, 1, 3, "wm-fill-run-ls-form", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](7, ArrayLinesBasicXComponent_wm_range_form_7_Template, 1, 1, "wm-range-form", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](8, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](9, "div", 8, 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("config", ctx.config.wrapper)("info", ctx.info);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.wi.timestampField);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.wi.fillQueriesEnabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.wi.runQueriesEnabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.wi.hasOwnProperty("xField") && ctx.wi["xField"]);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_11__.NgIf, _shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_1__.WidgetComponent, _shared_date_range_form_date_range_form_component__WEBPACK_IMPORTED_MODULE_2__.DateRangeFormComponent, _shared_fill_run_ls_form_fill_run_ls_form_component__WEBPACK_IMPORTED_MODULE_3__.FillRunLsFormComponent, _shared_range_form_range_form_component__WEBPACK_IMPORTED_MODULE_4__.RangeFormComponent], styles: [".widget-content[_ngcontent-%COMP%] {\r\n    overflow: hidden;\r\n    width: 100%;\r\n    height: 100%;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFycmF5LWxpbmVzLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxnQkFBZ0I7SUFDaEIsV0FBVztJQUNYLFlBQVk7QUFDaEIiLCJmaWxlIjoiYXJyYXktbGluZXMuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi53aWRnZXQtY29udGVudCB7XHJcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbn1cclxuIl19 */"] });


/***/ }),

/***/ 67838:
/*!******************************************************************!*\
  !*** ./src/app/widgets/array-field/array-lines-basicx.module.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ArrayLinesBasicXModule": () => (/* binding */ ArrayLinesBasicXModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _array_lines_basicx_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./array-lines-basicx.component */ 44990);
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./data.service */ 41977);
/* harmony import */ var app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! app/shared/shared.module */ 44466);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);





class ArrayLinesBasicXModule {
}
ArrayLinesBasicXModule.entry = _array_lines_basicx_component__WEBPACK_IMPORTED_MODULE_0__.ArrayLinesBasicXComponent;
ArrayLinesBasicXModule.ɵfac = function ArrayLinesBasicXModule_Factory(t) { return new (t || ArrayLinesBasicXModule)(); };
ArrayLinesBasicXModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: ArrayLinesBasicXModule });
ArrayLinesBasicXModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ providers: [_data_service__WEBPACK_IMPORTED_MODULE_1__.DataService], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
        app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](ArrayLinesBasicXModule, { declarations: [_array_lines_basicx_component__WEBPACK_IMPORTED_MODULE_0__.ArrayLinesBasicXComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
        app_shared_shared_module__WEBPACK_IMPORTED_MODULE_2__.SharedModule] }); })();


/***/ })

}]);
//# sourceMappingURL=src_app_widgets_array-field_array-lines-basicx_module_ts.js.map