"use strict";
(self["webpackChunkwebmonitor2"] = self["webpackChunkwebmonitor2"] || []).push([["default-src_app_widgets_numeric-field_numeric-field_component_ts"],{

/***/ 7529:
/*!***************************************************!*\
  !*** ./src/app/shared/query-cache/query-cache.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QueryCache": () => (/* binding */ QueryCache)
/* harmony export */ });
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs/operators */ 89196);

class QueryCache {
    constructor(timeToLive) {
        this.timeToLive = timeToLive;
        this.cache = {};
        if (!Number.isFinite(timeToLive) || timeToLive <= 0) {
            throw new Error('QueryCache timeToLive must be positive number');
        }
    }
    ask(key, queryRequest) {
        if (this.cache[key]) {
            return this.cache[key][0];
        }
        const rSubject = queryRequest.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_0__.shareReplay)());
        const timerID = setTimeout(() => {
            clearTimeout(this.cache[key][1]);
            delete this.cache[key];
        }, this.timeToLive);
        this.cache[key] = [rSubject, timerID];
        return rSubject;
    }
    clear() {
        Object.keys(this.cache).forEach(key => {
            clearTimeout(this.cache[key][1]);
            delete this.cache[key];
        });
    }
}


/***/ }),

/***/ 79081:
/*!*******************************************************!*\
  !*** ./src/app/widgets/numeric-field/data.service.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DataService": () => (/* binding */ DataService),
/* harmony export */   "MAX_QUERY_SIZE": () => (/* binding */ MAX_QUERY_SIZE),
/* harmony export */   "MAX_QUERY_SIZE_FOR_NEWEST": () => (/* binding */ MAX_QUERY_SIZE_FOR_NEWEST)
/* harmony export */ });
/* harmony import */ var app_shared_query_cache_query_cache__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/shared/query-cache/query-cache */ 7529);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var app_core_database_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! app/core/database.service */ 67084);




const MAX_QUERY_SIZE = 10000;
const MAX_QUERY_SIZE_FOR_NEWEST = 200;
class DataService {
    constructor(db) {
        this.db = db;
        this.queryCache = new app_shared_query_cache_query_cache__WEBPACK_IMPORTED_MODULE_0__.QueryCache(1000);
    }
    _query(queries, params, aggregated = false) {
        params.sources.forEach((s, i) => {
            this.db.transformQueryWithNestedPath(queries[i * 2 + 1], s.nestedPath);
        });
        let extractResponse;
        if (aggregated) {
            extractResponse = (response) => this.extractAggregatedResponseFields(response, params);
        }
        else {
            extractResponse = (response) => this.extractResponseFields(response, params);
        }
        return this.db.multiSearch(this.db.stringifyToNDJSON(queries), params.database)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(extractResponse));
    }
    queryMaxValue(database, index, documentType, nestedPath, field) {
        const query = this.makeMaxQuery(index, documentType, field);
        this.db.transformQueryWithNestedPath(query[1], nestedPath);
        const queryStr = this.db.stringifyToNDJSON(query);
        const queryObs = this.db.multiSearch(queryStr, database).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(this.extractMax.bind(this)));
        return this.queryCache.ask(database + index + queryStr, queryObs);
    }
    queryExtremesByTerms(params, terms) {
        let queries = [];
        params.sources.forEach((source, i) => {
            const query = this.makeExtremesQuery(source);
            const term = terms[i];
            query[1]['query']['bool']['filter'].push({ "term": term });
            this.db.transformQueryWithNestedPath(query[1], params.nestedPath);
            queries = queries.concat(query);
        });
        return this.db.multiSearch(this.db.stringifyToNDJSON(queries), params.database)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(this.extractExtremes.bind(this)));
    }
    queryTerms(params, terms) {
        let queries = [];
        params.sources.forEach((source, i) => {
            const query = this.makeSingleSourceQuery(source);
            const term = terms[i];
            query[1]['query']['bool']['filter'].push({ "term": term });
            queries = queries.concat(query);
        });
        return this._query(queries, params, false);
    }
    queryDateRangeAggregated(params, min, max, aggregation = 'avg', buckets = 1800) {
        let queries = [];
        params.sources.forEach(source => {
            queries = queries.concat(this.makeSingleSourceAggregationQuery(source, min, max, aggregation, buckets));
        });
        return this._query(queries, params, true);
    }
    queryNewest(params, size) {
        let queries = [];
        params.sources.forEach(source => {
            const query = this.makeSingleSourceQuery(source);
            query[1]['size'] = size;
            queries = queries.concat(query);
        });
        return this._query(queries, params, false);
    }
    queryRange(params, field, min, max) {
        let queries = [];
        params.sources.forEach(source => {
            const query = this.makeSingleSourceQuery(source);
            const range = {};
            range[field] = { "gte": min, "lte": max };
            query[1]['query']['bool']['filter'].push({ "range": range });
            queries = queries.concat(query);
        });
        return this._query(queries, params, false);
    }
    queryDateRange(params, min, max) {
        let queries = [];
        params.sources.forEach(source => {
            const query = this.makeSingleSourceQuery(source);
            const range = {};
            range[source.timestampField] = { "gte": min, "lte": max };
            query[1]['query']['bool']['filter'].push({ "range": range });
            queries = queries.concat(query);
        });
        return this._query(queries, params, false);
    }
    queryNewestSince(params, perSourceMin) {
        let queries = [];
        params.sources.forEach((source, i) => {
            const query = this.makeSingleSourceQuery(source);
            query[1]['size'] = MAX_QUERY_SIZE_FOR_NEWEST;
            const range = {};
            range[source.timestampField] = {
                "gte": perSourceMin[i]
            };
            query[1]['query']['bool']['filter'].push({ "range": range });
            queries = queries.concat(query);
        });
        return this._query(queries, params, false);
    }
    makeSingleSourceAggregationQuery(source, min, max, aggregation = 'avg', buckets = 1800) {
        const header = {
            index: source.index,
            type: source.documentType
        };
        const interval = Math.ceil(((new Date(max)).getTime() - (new Date(min)).getTime()) / buckets);
        const body = {
            'size': 0,
            'query': { 'bool': { 'filter': [] } },
            'aggs': {
                'points': {
                    'date_histogram': {
                        'field': source.timestampField,
                        'interval': String(interval) + 'ms',
                        'extended_bounds': { 'min': min, 'max': max }
                    },
                    'aggs': {}
                }
            }
        };
        body['query']['bool']['filter'].push({
            'range': { 'timestamp': { 'gte': min, 'lte': max } }
        });
        if (source.extraFields.length > 0) {
            body['aggs']['points']['aggs']['_extra'] = { 'top_hits': { 'size': 1 } };
            body['aggs']['points']['aggs']['_extra']['top_hits']['_source'] = {
                'include': source.extraFields.map(f => f.name)
            };
            const topHitsSort = {};
            topHitsSort[source.timestampField] = { 'order': 'desc' };
            body['aggs']['points']['aggs']['_extra']['top_hits']['sort'] = [topHitsSort];
        }
        source.fields.forEach(f => {
            const agg = {};
            agg[aggregation] = { 'field': f.name };
            body['aggs']['points']['aggs'][f.name] = agg;
        });
        if (source.terms) {
            Object.keys(source.terms).forEach(k => {
                const term = {};
                term[k] = source.terms[k];
                body['query']['bool']['filter'].push({ 'term': term });
            });
        }
        return [header, body];
    }
    makeMaxQuery(index, documentType, field) {
        const header = {
            index: index,
            type: documentType
        };
        const sort = {};
        sort[field] = { order: 'desc' };
        const body = {
            "_source": [field],
            "sort": sort,
            "size": 1
        };
        return [header, body];
    }
    makeExtremesQuery(source) {
        const header = {
            index: source.index,
            type: source.documentType
        };
        const body = {
            "sort": {},
            "size": 0,
            "query": {
                "bool": {
                    "filter": []
                }
            },
            'aggs': {
                'min_ts': {
                    'min': {
                        'field': source.timestampField
                    }
                },
                'max_ts': {
                    'max': {
                        'field': source.timestampField
                    }
                }
            }
        };
        if (source.terms) {
            Object.keys(source.terms).forEach(k => {
                const term = {};
                term[k] = source.terms[k];
                body['query']['bool']['filter'].push({ 'term': term });
            });
        }
        return [header, body];
    }
    makeSingleSourceQuery(source) {
        const header = {
            index: source.index,
            type: source.documentType
        };
        const body = {
            "_source": this.parseQueryFields(source),
            "sort": {},
            "size": MAX_QUERY_SIZE,
            "query": {
                "bool": {
                    "filter": []
                }
            }
        };
        body['sort'][source.timestampField] = "desc";
        if (source.terms) {
            Object.keys(source.terms).forEach(k => {
                const term = {};
                term[k] = source.terms[k];
                body['query']['bool']['filter'].push({ "term": term });
            });
        }
        return [header, body];
    }
    parseQueryFields(source) {
        const fields = [source.timestampField || 'timestamp'];
        source.fields.forEach(f => {
            fields.push(f.name);
            if (f.errorField) {
                fields.push(f.errorField);
            }
        });
        source.extraFields.forEach(f => {
            fields.push(f.name);
        });
        return fields;
    }
    extractResponseFields(response, params) {
        const responseFields = response['responses']
            .map(r => r['hits']['hits'].reverse())
            .map((hits, i) => {
            if (params.sources[i].nestedPath) {
                return hits.map(hit => hit['_source'][params.sources[i].nestedPath]);
            }
            else {
                return hits.map(hit => hit['_source']);
            }
        });
        params.sources.forEach((s, i) => {
            s.extraFields.forEach(f => {
                if (!f.renameTo) {
                    return;
                }
                responseFields[i].forEach(hit => {
                    hit[f.renameTo] = hit[f.name];
                });
            });
        });
        return responseFields;
    }
    extractAggregatedResponseFields(response, params) {
        const result = [];
        params.sources.forEach((source, i) => {
            const buckets = response['responses'][i]['aggregations']['points']['buckets'];
            const sourceResult = [];
            buckets.forEach(bucket => {
                const point = {};
                point[source.timestampField] = bucket['key_as_string'];
                source.fields.forEach(field => {
                    point[field.name] = bucket[field.name]['value'];
                    if (field.errorField) {
                        point[field.errorField] = bucket[field.errorField]['value'];
                    }
                });
                source.extraFields.forEach(field => {
                    const name = field.renameTo || field.name;
                    const hit = bucket['_extra']['hits']['hits'][0];
                    point[name] = hit ? hit['_source'][field.name] : undefined;
                });
                sourceResult.push(point);
            });
            result.push(sourceResult);
        });
        return result;
    }
    extractExtremes(response) {
        const perSource = response['responses']
            .map(r => r['aggregations']);
        const min = perSource.map(e => e['min_ts']);
        const max = perSource.map(e => e['max_ts']);
        const gMin = min.reduce((result, el) => el['value'] < result ? el['value'] : result);
        const gMax = max.reduce((result, el) => el['value'] < result ? el['value'] : result);
        return {
            min: gMin,
            max: gMax,
            perSourceMin: min,
            perSourceMax: max
        };
    }
    extractMax(response) {
        try {
            return { value: response['responses'][0]['hits']['hits'][0]['sort'][0] };
        }
        catch {
            return {};
        }
    }
}
DataService.ɵfac = function DataService_Factory(t) { return new (t || DataService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](app_core_database_service__WEBPACK_IMPORTED_MODULE_1__.DatabaseService)); };
DataService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({ token: DataService, factory: DataService.ɵfac });


/***/ }),

/***/ 82257:
/*!******************************************************************!*\
  !*** ./src/app/widgets/numeric-field/numeric-field.component.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NumericFieldComponent": () => (/* binding */ NumericFieldComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs */ 25474);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs */ 10745);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs */ 20591);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 51353);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs/operators */ 19337);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs/operators */ 53158);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs/operators */ 81203);
/* harmony import */ var app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/shared/chart-utils */ 99593);
/* harmony import */ var app_widgets_base_chart_widget__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! app/widgets/base/chart-widget */ 47397);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var app_core_event_bus_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! app/core/event-bus.service */ 40699);
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./data.service */ 79081);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @clr/angular */ 4151);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/widget/widget.component */ 81522);
/* harmony import */ var _shared_date_range_form_date_range_form_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/date-range-form/date-range-form.component */ 63747);
/* harmony import */ var _shared_fill_run_ls_form_fill_run_ls_form_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/fill-run-ls-form/fill-run-ls-form.component */ 49207);
/* harmony import */ var _shared_range_form_range_form_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../shared/range-form/range-form.component */ 2199);
/* harmony import */ var _shared_quick_date_form_quick_date_form_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../shared/quick-date-form/quick-date-form.component */ 94891);















function NumericFieldComponent_form_3_Template(rf, ctx) { if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "form", 10)(1, "clr-checkbox-container")(2, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](3, "Annotations");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](4, "clr-checkbox-wrapper")(5, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](6, "Enable Annotations");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](7, "input", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("ngModelChange", function NumericFieldComponent_form_3_Template_input_ngModelChange_7_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r9); const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r8.config.widget.fieldChangeSeparators.enabled = $event); })("ngModelChange", function NumericFieldComponent_form_3_Template_input_ngModelChange_7_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r9); const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r10.updateFieldSeparators(true)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()()()();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngModel", ctx_r1.config.widget.fieldChangeSeparators.enabled);
} }
function NumericFieldComponent_div_5_Template(rf, ctx) { if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div")(1, "wm-quick-date-form", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("query", function NumericFieldComponent_div_5_Template_wm_quick_date_form_query_1_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r12); const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r11.queryDateRange($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("options", ctx_r2.wi.quickDateOptions);
} }
function NumericFieldComponent_wm_fill_run_ls_form_7_Template(rf, ctx) { if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "wm-fill-run-ls-form", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("query", function NumericFieldComponent_wm_fill_run_ls_form_7_Template_wm_fill_run_ls_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r14); const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r13.queryFillRun($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("fillEnabled", true)("runEnabled", false)("lsEnabled", false);
} }
function NumericFieldComponent_wm_fill_run_ls_form_8_Template(rf, ctx) { if (rf & 1) {
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "wm-fill-run-ls-form", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("query", function NumericFieldComponent_wm_fill_run_ls_form_8_Template_wm_fill_run_ls_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r16); const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r15.queryFillRun($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("fillEnabled", false)("runEnabled", true)("lsEnabled", false);
} }
function NumericFieldComponent_wm_range_form_9_Template(rf, ctx) { if (rf & 1) {
    const _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "wm-range-form", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("query", function NumericFieldComponent_wm_range_form_9_Template_wm_range_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r19); const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r18.queryRange($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
} if (rf & 2) {
    const rq_r17 = ctx.$implicit;
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("key", rq_r17.fieldname)("label", rq_r17.label)("database", ctx_r5.wi.database)("index", ctx_r5.wi.rangeRefresh.index)("queryDetectors", ctx_r5.config.wrapper.queryDetectors)("queryFits", ctx_r5.config.wrapper.queryFits);
} }
function NumericFieldComponent_div_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](1, "div", 16, 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
} }
function NumericFieldComponent_div_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](1, "div", 18, 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](3, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtext"](4, "Ratios");
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](5, "div", 20, 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
} }
class NumericFieldComponent extends app_widgets_base_chart_widget__WEBPACK_IMPORTED_MODULE_1__.ChartWidget {
    constructor(eventBus, dataService) {
        super(eventBus);
        this.eventBus = eventBus;
        this.dataService = dataService;
        this.flatFields = [];
        this.series = [];
        this.detectors = [];
        this.fits = [];
        this.initialShowHideSeriesDone = false;
        this.info = {};
        this.labelAggregated = undefined;
        this._aggregated = false;
    }
    get aggregated() {
        return this._aggregated;
    }
    set aggregated(newVal) {
        this._aggregated = newVal;
        this.info = Object.assign({}, this.info, { aggregated: newVal });
    }
    ngOnInit() {
        super.ngOnInit({
            'refreshSize': 100,
            'liveWindow': 600000,
            'database': 'default',
            'sources': [],
            'fits': []
        });
        this.wi = this.config['widget'];
        if (!this.wi.hasOwnProperty('quickDateOptions')) {
            this.wi.quickDateOptions = [
                { "unit": "hours", "duration": 2, "text": "Last 2 hours" },
                { "unit": "hours", "duration": 6, "text": "Last 6 hours" }
            ];
        }
        this.queryParams = {
            database: this.wi.database,
            sources: this.wi.sources
        };
        this.wi.sources.forEach(s => {
            s.timestampField = s.timestampField || 'timestamp';
            s.extraFields = s.extraFields || [];
            this.flatFields = this.flatFields.concat(s.fields);
        });
        if (this.wi.hasOwnProperty('aggregationAlgo')) {
            if (this.wi.aggregationAlgo != 'sum' && this.wi.aggregationAlgo != 'avg' &&
                this.wi.aggregationAlgo != 'max' && this.wi.aggregationAlgo != 'min' &&
                this.wi.aggregationAlgo != 'value_count') {
                this.wi.aggregationAlgo = 'avg';
            }
        }
        this.makeSeries();
    }
    ngAfterViewInit() {
        super.ngAfterViewInit();
        this.plot.nativeElement.on('plotly_legendclick', this.onLegendClick.bind(this));
        this.plot.nativeElement.on('plotly_relayout', this.onRelayout.bind(this));
        if (!this.wrapper.started) {
            this.refresh().subscribe();
        }
    }
    queryFromEvent(event) {
        if (event['type'] === 'range_query') {
            this.widgetComponent.log('Received range query', 'info');
            this.queryRange(event['payload']);
        }
        else if (event['type'] === 'time_range_query') {
            this.widgetComponent.log('Received time range query', 'info');
            this.queryDateRange(event['payload']);
        }
        else if (event['type'] === 'fill_run_ls_query') {
            if (this.wi.fillQueriesEnabled || this.wi.runQueriesEnabled) {
                this.widgetComponent.log('Received fill/run query', 'info');
                this.queryFillRun(event['payload']);
            }
        }
    }
    onRefreshEvent() {
        this.widgetComponent.stop();
        this.refresh().subscribe();
    }
    onStartEvent() {
        this.refresh().subscribe(this.setXZoomToLiveWindow.bind(this));
    }
    onQueryError(error) {
        this.widgetComponent.log(String(error), 'danger');
        this.clearChart();
        this.enableInteraction();
        throw (error);
    }
    refresh(size) {
        let obs;
        if (this.wi.rangeRefresh && this.wi.rangeRefresh.enabled) {
            const r = this.wi.rangeRefresh;
            obs = this.dataService.queryMaxValue(this.queryParams.database, r.index, r.documentType, r.nestedPath, r.field).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.mergeMap)(max => {
                if (!max['value']) {
                    return (0,rxjs__WEBPACK_IMPORTED_MODULE_11__.throwError)('Failed to get max for range refresh ' + JSON.stringify(r));
                }
                const range = {
                    key: r.field,
                    min: max['value'] - r.range,
                    max: max['value'],
                    detectors: this.detectors,
                    fits: this.fits
                };
                this.widgetComponent.log('Querying range refresh:' + JSON.stringify(range), 'info', 1000);
                return (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.of)(range);
            }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.map)(this.queryRange.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.tap)(this.enableInteraction.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.catchError)(this.onQueryError.bind(this)));
        }
        else {
            size = size || this.wi.refreshSize;
            obs = this.dataService.queryNewest(this.queryParams, size).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.tap)(() => this.aggregated = false), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.map)(this.setData.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.tap)(this.enableInteraction.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.catchError)(this.onQueryError.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.share)());
        }
        this.disableInteraction();
        return obs;
    }
    setData(newData) {
        this.flatFields = [];
        this.queryParams.sources.forEach((source, i) => {
            const extra = this.makeSourceExtraFields(newData[i], source);
            const text = this.makeSourceText(newData[i]);
            const x = this.makeSourceXValues(newData[i], source);
            source.fields.forEach((field, j) => {
                const series = this.series[i][j];
                series.x = x;
                series.text = text;
                series._extra = extra;
                series.y = this.makeFieldYValues(newData[i], field);
                this.flatFields = this.flatFields.concat(field);
                if (field.errorField) {
                    series.error_y = this.makeFieldErrorBars(newData[i], field);
                }
            });
        });
        this.updateFieldSeparators();
        Plotly.redraw(this.plot.nativeElement, this.chartData);
        this.autorange();
    }
    clearChart() {
        this.queryParams.sources.forEach((source, i) => {
            source.fields.forEach((field, j) => {
                const series = this.series[i][j];
                series.x = [];
                series.y = [];
                series._extra = [];
                series.text = [];
            });
        });
        Plotly.redraw(this.plot.nativeElement, this.chartData);
    }
    queryRange(event) {
        this.widgetComponent.stop();
        this.updateSources(event.detectors, event.fits);
        this.makeSeries();
        const obs = this.dataService.queryRange(this.queryParams, event.key, event.min, event.max).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.tap)(() => this.aggregated = false), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.map)(this.setData.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.tap)(this.enableInteraction.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.catchError)(this.onQueryError.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.share)());
        this.disableInteraction();
        obs.subscribe();
        return obs;
    }
    queryDateRange(range) {
        this.widgetComponent.stop();
        let obs;
        if (range.msecTo - range.msecFrom > this.wi.aggregationThreshold) {
            obs = this.dataService.queryDateRangeAggregated(this.queryParams, this.chartTimestampToTs(range.strFrom), this.chartTimestampToTs(range.strTo), this.wi.aggregationAlgo).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.tap)(() => this.aggregated = true));
        }
        else {
            obs = this.dataService.queryDateRange(this.queryParams, this.chartTimestampToTs(range.strFrom), this.chartTimestampToTs(range.strTo)).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.tap)(() => this.aggregated = false));
        }
        obs = obs.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.map)(this.setData.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.tap)(this.enableInteraction.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.catchError)(this.onQueryError.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_16__.share)());
        this.disableInteraction();
        obs.subscribe();
        return obs;
    }
    queryFillRun(event) {
        this.widgetComponent.stop();
        const terms = [];
        if (event['run']) {
            this.queryParams.sources.forEach(s => {
                const term = {};
                term[s['runField']] = event['run'];
                terms.push(term);
            });
        }
        else if (event['fill']) {
            this.queryParams.sources.forEach(s => {
                const term = {};
                term[s['fillField']] = event['fill'];
                terms.push(term);
            });
        }
        else {
            this.widgetComponent.log('One of [FILL, RUN] must be specified', 'warning');
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.empty)();
        }
        this.widgetComponent.log('Querying timestamp extremes for FILL/RUN', 'info');
        this.disableInteraction();
        this.dataService.queryExtremesByTerms(this.queryParams, terms)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.mergeMap)(extremes => {
            if (!extremes['min']['value'] || !extremes['max']['value']) {
                return (0,rxjs__WEBPACK_IMPORTED_MODULE_11__.throwError)('Failed to get timestamp extremes for FILL/RUN query. ' + JSON.stringify(event));
            }
            const min = extremes['min']['value_as_string'];
            const max = extremes['max']['value_as_string'];
            this.widgetComponent.log('Got timestamp extremes. ' + min + ', ' + max, 'info');
            const range = app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__.makeQueryRangeFromStrings(min, max);
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_12__.of)(range);
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.map)(this.queryDateRange.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.tap)(this.enableInteraction.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.catchError)(this.onQueryError.bind(this)))
            .subscribe();
    }
    updateLive() {
        if (this.series.length < 1 || this.aggregated) {
            this.refresh().subscribe(this.setXZoomToLiveWindow.bind(this));
            return;
        }
        const lastXPerSource = this.getLastXPerSource();
        this.dataService.queryNewestSince(this.queryParams, lastXPerSource)
            .subscribe(resp => {
            this.queryParams.sources.forEach((source, i) => {
                const hits = resp[i].filter(hit => hit[source.timestampField] !== lastXPerSource[i]);
                if (hits.length < 1) {
                    return;
                }
                const x = this.makeSourceXValues(hits, source);
                const extra = this.makeSourceExtraFields(hits, source);
                const text = this.makeSourceText(hits);
                source.fields.forEach((field, j) => {
                    const series = this.series[i][j];
                    series.x = series.x.concat(x);
                    series.y = series.y.concat(this.makeFieldYValues(hits, field));
                    series.text = series.text.concat(text);
                    Object.keys(series['_extra']).forEach(key => {
                        series['_extra'][key] = series['_extra'][key].concat(extra[key]);
                    });
                    if (field.errorField) {
                        series.error_y.array = series.error_y.array.concat(this.makeFieldErrorBars(hits, field).array);
                    }
                    this.dropPointsOutsideLiveWindow(series);
                });
            });
            this.updateFieldSeparators();
            this.setXZoomToLiveWindow();
            Plotly.redraw(this.plot.nativeElement, this.chartData);
        });
    }
    getLastXPerSource() {
        return this.series.map(s => {
            const x = s[0].x;
            return x[x.length - 1];
        });
    }
    dropPointsOutsideLiveWindow(series) {
        const lastX = new Date(series.x[series.x.length - 1]);
        const liveWindow = this.wi.liveWindow;
        let count = 0;
        let dropErrorValues = function () { };
        if (series.hasOwnProperty('error_y')) {
            dropErrorValues = function () { series.error_y.array.shift(); };
        }
        while (lastX.getTime() - (new Date(series.x[0])).getTime() > liveWindow) {
            series.x.shift();
            series.y.shift();
            series.text.shift();
            Object.keys(series['_extra']).forEach(key => {
                series['_extra'][key].shift();
            });
            dropErrorValues();
            count += 1;
        }
    }
    setXZoomToLiveWindow(lastPerSource) {
        if (!lastPerSource) {
            lastPerSource = this.getLastXPerSource();
        }
        lastPerSource = lastPerSource.map(x => (new Date(x)).getTime()).filter(x => Number.isFinite(x));
        const max = Math.max.apply(null, lastPerSource);
        if (!Number.isInteger(max)) {
            return;
        }
        const min = max - this.wi.liveWindow;
        const xaxis = this.plot.nativeElement['layout']['xaxis'];
        const newRange = [
            (new Date(min)).toISOString(),
            (new Date(max)).toISOString()
        ];
        xaxis['range'] = newRange;
        xaxis['autorange'] = false;
        Plotly.relayout(this.plot.nativeElement, { xaxis: xaxis });
    }
    makeSeries() {
        this.chartData.length = 0;
        this.series.length = 0;
        this.queryParams.sources.forEach((s, i) => {
            const seriesOfCurrentSource = [];
            s.fields.forEach((field, j) => {
                const newSeries = {
                    x: [],
                    y: [],
                    _extra: [],
                    text: [],
                    name: field.seriesName || field.name,
                    type: 'scatter',
                    mode: (this.wi.forceMarkers || field.forceMarkers) ? 'lines+markers' : 'auto',
                    line: { width: field['lineWidth'] || 1, color: field['color'] },
                    visible: (field['hidden'] ? 'legendonly' : true)
                };
                if (field['yAxis'] === 2) {
                    newSeries['yaxis'] = 'y2';
                }
                seriesOfCurrentSource.push(newSeries);
                this.chartData.push(newSeries);
            });
            this.series.push(seriesOfCurrentSource);
        });
    }
    onLegendClick(event) {
        this.flatFields[event.expandedIndex]['hidden'] = !this.flatFields[event.expandedIndex]['hidden'];
    }
    onRelayout(event) {
        if (!this.aggregated) {
            return true;
        }
        const range = app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__.makeQueryRangeFromZoomEvent(event);
        if (range) {
            this.disableInteraction();
            this.widgetComponent.log('X axis zoom changed with aggregated data. Requerying', 'info');
            this.queryDateRange(range)
                .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_14__.tap)(this.enableInteraction.bind(this)))
                .subscribe();
        }
        return false;
    }
    updateFieldSeparators(relayout = false) {
        return super.updateFieldSeparators(relayout, this.aggregated);
    }
    makeSourceXValues(sourceData, source) {
        return sourceData.map(hit => this.tsToChartTimestamp(hit[source.timestampField]));
    }
    makeFieldYValues(hits, field) {
        const result = hits.map(hit => hit[field.name]);
        if (result.length > 0) {
            // ES cannot store NaN values as numeric.
            // So, when a flashlist inserts a NaN, the webmonitor receives -300M
            // in it's place.
            // So the following code maps -300M values to null as a temporary fix..
            // (!) This should be removed after XDAQ encodes NaN to null.
            return result.map(value => value == -300000000 ? null : value);
        }
        else {
            return [null];
        }
    }
    makeFieldErrorBars(hits, field) {
        return {
            type: 'data',
            array: hits.map(hit => hit[field.errorField]),
            color: 'black',
            thickness: 1,
            symmetric: true
        };
    }
    makeSourceExtraFields(sourceData, source) {
        const extra = {};
        source.extraFields.forEach(field => {
            if (field.renameTo) {
                extra[field.renameTo] = sourceData.map(hit => hit[field.renameTo]);
            }
            else {
                extra[field.name] = sourceData.map(hit => hit[field.name]);
            }
        });
        return extra;
    }
    makeSourceText(sourceData) {
        const tooltipTextConfig = this.wi.tooltipInfo;
        if (!tooltipTextConfig) {
            return [];
        }
        return sourceData.map(point => app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__.makeTooltipText(point, tooltipTextConfig));
    }
    // Update detector value in source parameters depending on user input
    updateSources(sources, fits) {
        if (!sources.length) {
            return;
        }
        let updatedSources = [];
        if (this.wi.database === 'analysis_store') {
            for (let source of sources) {
                let templateSource = JSON.parse(JSON.stringify(this.wi.sources[0]));
                templateSource.fields[0].seriesName = source;
                templateSource.terms["detector"] = source;
                if (fits.length) {
                    fits.forEach(fit => {
                        templateSource = JSON.parse(JSON.stringify(templateSource));
                        templateSource.fields[0].seriesName = source + '/' + fit;
                        templateSource.terms["fit"] = fit;
                        updatedSources.push(templateSource);
                    });
                }
                else {
                    templateSource.fields[0].seriesName = source;
                    updatedSources.push(templateSource);
                }
            }
        }
        else if (this.wi.database === 'main_daq_monitoring') {
            for (let source of sources) {
                let templateSource = JSON.parse(JSON.stringify(this.wi.sources[0]));
                templateSource.fields[0].seriesName = source;
                templateSource.terms["detectorname"] = source;
                updatedSources.push(templateSource);
            }
        }
        this.queryParams.sources = updatedSources;
    }
}
NumericFieldComponent.ɵfac = function NumericFieldComponent_Factory(t) { return new (t || NumericFieldComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](app_core_event_bus_service__WEBPACK_IMPORTED_MODULE_2__.EventBusService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_data_service__WEBPACK_IMPORTED_MODULE_3__.DataService)); };
NumericFieldComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineComponent"]({ type: NumericFieldComponent, selectors: [["wm-numeric-field-widget"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵInheritDefinitionFeature"]], decls: 12, vars: 9, consts: [[3, "config", "info", "refresh", "start", "timer"], ["widgetWrapper", ""], [1, "widget-options"], ["clrForm", "", 4, "ngIf"], [1, "widget-queries"], [4, "ngIf"], [3, "query"], [3, "fillEnabled", "runEnabled", "lsEnabled", "query", 4, "ngIf"], ["inputType", "number", 3, "key", "label", "database", "index", "queryDetectors", "queryFits", "query", 4, "ngFor", "ngForOf"], ["class", "widget-content", 4, "ngIf"], ["clrForm", ""], ["type", "checkbox", "clrCheckbox", "", "name", "separatorsCheckbox", 3, "ngModel", "ngModelChange"], [3, "options", "query"], [3, "fillEnabled", "runEnabled", "lsEnabled", "query"], ["inputType", "number", 3, "key", "label", "database", "index", "queryDetectors", "queryFits", "query"], [1, "widget-content"], [2, "height", "100%", "width", "100%"], ["plot", ""], [2, "height", "55%", "width", "100%"], [1, "h6", "content-separator"], [2, "flex", "1 1 auto", "width", "100%"], ["ratioPlot", ""]], template: function NumericFieldComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "wm-widget", 0, 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("refresh", function NumericFieldComponent_Template_wm_widget_refresh_0_listener() { return ctx.onRefreshEvent(); })("start", function NumericFieldComponent_Template_wm_widget_start_0_listener() { return ctx.onStartEvent(); })("timer", function NumericFieldComponent_Template_wm_widget_timer_0_listener() { return ctx.updateLive(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](3, NumericFieldComponent_form_3_Template, 8, 1, "form", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](5, NumericFieldComponent_div_5_Template, 2, 1, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](6, "wm-date-range-form", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("query", function NumericFieldComponent_Template_wm_date_range_form_query_6_listener($event) { return ctx.queryDateRange($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](7, NumericFieldComponent_wm_fill_run_ls_form_7_Template, 1, 3, "wm-fill-run-ls-form", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](8, NumericFieldComponent_wm_fill_run_ls_form_8_Template, 1, 3, "wm-fill-run-ls-form", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](9, NumericFieldComponent_wm_range_form_9_Template, 1, 6, "wm-range-form", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](10, NumericFieldComponent_div_10_Template, 3, 0, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](11, NumericFieldComponent_div_11_Template, 7, 0, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("config", ctx.config.wrapper)("info", ctx.info);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.config.widget.fieldChangeSeparators);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.wi.quickDateOptions);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.config.widget.fillQueriesEnabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.config.widget.runQueriesEnabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngForOf", ctx.wi.rangeQueries);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", !ctx.wi["ratios"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.wi["ratios"]);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_18__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_18__.NgIf, _clr_angular__WEBPACK_IMPORTED_MODULE_19__.ClrLabel, _clr_angular__WEBPACK_IMPORTED_MODULE_19__.ClrForm, _clr_angular__WEBPACK_IMPORTED_MODULE_19__.ClrCheckbox, _clr_angular__WEBPACK_IMPORTED_MODULE_19__.ClrCheckboxContainer, _clr_angular__WEBPACK_IMPORTED_MODULE_19__.ClrCheckboxWrapper, _angular_forms__WEBPACK_IMPORTED_MODULE_20__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_20__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_20__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_20__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_20__.NgModel, _angular_forms__WEBPACK_IMPORTED_MODULE_20__.NgForm, _shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_4__.WidgetComponent, _shared_date_range_form_date_range_form_component__WEBPACK_IMPORTED_MODULE_5__.DateRangeFormComponent, _shared_fill_run_ls_form_fill_run_ls_form_component__WEBPACK_IMPORTED_MODULE_6__.FillRunLsFormComponent, _shared_range_form_range_form_component__WEBPACK_IMPORTED_MODULE_7__.RangeFormComponent, _shared_quick_date_form_quick_date_form_component__WEBPACK_IMPORTED_MODULE_8__.QuickDateFormComponent], styles: [".widget-content[_ngcontent-%COMP%] {\r\n    width: 100%;\r\n    height: 100%;\r\n    overflow: hidden;\r\n    display: flex;\r\n    flex-flow: column;\r\n}\r\n\r\n.content-separator[_ngcontent-%COMP%] {\r\n    font-weight: bold;\r\n    text-align: center;\r\n    border-top: 1px silver solid;\r\n}\r\n\r\n.widget-queries[_ngcontent-%COMP%]    > *[_ngcontent-%COMP%] {\r\n    display: block;\r\n}\r\n\r\n.widget-queries[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]:hover {\r\n    background-color: #D9E4EA;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm51bWVyaWMtZmllbGQuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLFdBQVc7SUFDWCxZQUFZO0lBQ1osZ0JBQWdCO0lBQ2hCLGFBQWE7SUFDYixpQkFBaUI7QUFDckI7O0FBRUE7SUFDSSxpQkFBaUI7SUFDakIsa0JBQWtCO0lBQ2xCLDRCQUE0QjtBQUNoQzs7QUFFQTtJQUNJLGNBQWM7QUFDbEI7O0FBRUE7SUFDSSx5QkFBeUI7QUFDN0IiLCJmaWxlIjoibnVtZXJpYy1maWVsZC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLndpZGdldC1jb250ZW50IHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWZsb3c6IGNvbHVtbjtcclxufVxyXG5cclxuLmNvbnRlbnQtc2VwYXJhdG9yIHtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgYm9yZGVyLXRvcDogMXB4IHNpbHZlciBzb2xpZDtcclxufVxyXG5cclxuLndpZGdldC1xdWVyaWVzID4gKiB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxufVxyXG5cclxuLndpZGdldC1xdWVyaWVzPio6aG92ZXIge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0Q5RTRFQTtcclxufVxyXG4iXX0= */"] });


/***/ })

}]);
//# sourceMappingURL=default-src_app_widgets_numeric-field_numeric-field_component_ts.js.map