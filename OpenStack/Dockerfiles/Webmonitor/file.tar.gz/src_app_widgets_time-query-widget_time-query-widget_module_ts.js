"use strict";
(self["webpackChunkwebmonitor2"] = self["webpackChunkwebmonitor2"] || []).push([["src_app_widgets_time-query-widget_time-query-widget_module_ts"],{

/***/ 70127:
/*!**************************************************************************!*\
  !*** ./src/app/widgets/time-query-widget/time-query-widget.component.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TimeQueryWidgetComponent": () => (/* binding */ TimeQueryWidgetComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var app_core_event_bus_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/core/event-bus.service */ 40699);
/* harmony import */ var _shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../shared/widget/widget.component */ 81522);
/* harmony import */ var _shared_date_range_form_date_range_form_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../shared/date-range-form/date-range-form.component */ 63747);




class TimeQueryWidgetComponent {
    constructor(eventBus) {
        this.eventBus = eventBus;
    }
    ngOnInit() {
        this.config = this.config || {};
        if (!this.config.hasOwnProperty('widget')) {
            this.config['widget'] = {};
        }
    }
    query(event) {
        const ebEvent = { type: 'time_range_query', payload: event };
        this.eventBus.emit(this.config['widget']['channel'], ebEvent);
        console.log(event);
    }
}
TimeQueryWidgetComponent.ɵfac = function TimeQueryWidgetComponent_Factory(t) { return new (t || TimeQueryWidgetComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](app_core_event_bus_service__WEBPACK_IMPORTED_MODULE_0__.EventBusService)); };
TimeQueryWidgetComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({ type: TimeQueryWidgetComponent, selectors: [["wm-time-query-widget"]], inputs: { config: "config" }, decls: 3, vars: 2, consts: [[3, "config", "info"], [1, "widget-content"], [3, "query"]], template: function TimeQueryWidgetComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "wm-widget", 0)(1, "div", 1)(2, "wm-date-range-form", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("query", function TimeQueryWidgetComponent_Template_wm_date_range_form_query_2_listener($event) { return ctx.query($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("config", ctx.config ? ctx.config.wrapper : undefined)("info", ctx.info);
    } }, dependencies: [_shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_1__.WidgetComponent, _shared_date_range_form_date_range_form_component__WEBPACK_IMPORTED_MODULE_2__.DateRangeFormComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0aW1lLXF1ZXJ5LXdpZGdldC5jb21wb25lbnQuY3NzIn0= */"] });


/***/ }),

/***/ 11750:
/*!***********************************************************************!*\
  !*** ./src/app/widgets/time-query-widget/time-query-widget.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TimeQueryWidgetModule": () => (/* binding */ TimeQueryWidgetModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/shared/shared.module */ 44466);
/* harmony import */ var _time_query_widget_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./time-query-widget.component */ 70127);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);




class TimeQueryWidgetModule {
}
TimeQueryWidgetModule.entry = _time_query_widget_component__WEBPACK_IMPORTED_MODULE_1__.TimeQueryWidgetComponent;
TimeQueryWidgetModule.ɵfac = function TimeQueryWidgetModule_Factory(t) { return new (t || TimeQueryWidgetModule)(); };
TimeQueryWidgetModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: TimeQueryWidgetModule });
TimeQueryWidgetModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
        app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](TimeQueryWidgetModule, { declarations: [_time_query_widget_component__WEBPACK_IMPORTED_MODULE_1__.TimeQueryWidgetComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
        app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule] }); })();


/***/ })

}]);
//# sourceMappingURL=src_app_widgets_time-query-widget_time-query-widget_module_ts.js.map