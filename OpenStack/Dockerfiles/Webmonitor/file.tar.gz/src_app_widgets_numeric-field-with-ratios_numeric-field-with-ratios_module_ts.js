"use strict";
(self["webpackChunkwebmonitor2"] = self["webpackChunkwebmonitor2"] || []).push([["src_app_widgets_numeric-field-with-ratios_numeric-field-with-ratios_module_ts"],{

/***/ 46223:
/*!******************************************************************************************!*\
  !*** ./src/app/widgets/numeric-field-with-ratios/numeric-field-with-ratios.component.ts ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NumericFieldWithRatiosComponent": () => (/* binding */ NumericFieldWithRatiosComponent)
/* harmony export */ });
/* harmony import */ var app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/shared/chart-utils */ 99593);
/* harmony import */ var app_widgets_numeric_field_numeric_field_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! app/widgets/numeric-field/numeric-field.component */ 82257);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @clr/angular */ 4151);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../shared/widget/widget.component */ 81522);
/* harmony import */ var _shared_date_range_form_date_range_form_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/date-range-form/date-range-form.component */ 63747);
/* harmony import */ var _shared_fill_run_ls_form_fill_run_ls_form_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/fill-run-ls-form/fill-run-ls-form.component */ 49207);
/* harmony import */ var _shared_range_form_range_form_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/range-form/range-form.component */ 2199);
/* harmony import */ var _shared_quick_date_form_quick_date_form_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/quick-date-form/quick-date-form.component */ 94891);












const _c0 = ["ratioPlot"];
function NumericFieldWithRatiosComponent_form_3_Template(rf, ctx) { if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "form", 10)(1, "clr-checkbox-container")(2, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](3, "Annotations");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](4, "clr-checkbox-wrapper")(5, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](6, "Enable Annotations");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](7, "input", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("ngModelChange", function NumericFieldWithRatiosComponent_form_3_Template_input_ngModelChange_7_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r9); const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵresetView"](ctx_r8.config.widget.fieldChangeSeparators.enabled = $event); })("ngModelChange", function NumericFieldWithRatiosComponent_form_3_Template_input_ngModelChange_7_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r9); const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵresetView"](ctx_r10.updateFieldSeparators(true)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()()()();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngModel", ctx_r1.config.widget.fieldChangeSeparators.enabled);
} }
function NumericFieldWithRatiosComponent_div_5_Template(rf, ctx) { if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "div")(1, "wm-quick-date-form", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("query", function NumericFieldWithRatiosComponent_div_5_Template_wm_quick_date_form_query_1_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r12); const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵresetView"](ctx_r11.queryDateRange($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]()();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("options", ctx_r2.wi.quickDateOptions);
} }
function NumericFieldWithRatiosComponent_wm_fill_run_ls_form_7_Template(rf, ctx) { if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "wm-fill-run-ls-form", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("query", function NumericFieldWithRatiosComponent_wm_fill_run_ls_form_7_Template_wm_fill_run_ls_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r14); const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵresetView"](ctx_r13.queryFillRun($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("fillEnabled", true)("runEnabled", false)("lsEnabled", false);
} }
function NumericFieldWithRatiosComponent_wm_fill_run_ls_form_8_Template(rf, ctx) { if (rf & 1) {
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "wm-fill-run-ls-form", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("query", function NumericFieldWithRatiosComponent_wm_fill_run_ls_form_8_Template_wm_fill_run_ls_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r16); const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵresetView"](ctx_r15.queryFillRun($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("fillEnabled", false)("runEnabled", true)("lsEnabled", false);
} }
function NumericFieldWithRatiosComponent_wm_range_form_9_Template(rf, ctx) { if (rf & 1) {
    const _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "wm-range-form", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("query", function NumericFieldWithRatiosComponent_wm_range_form_9_Template_wm_range_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵrestoreView"](_r19); const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵresetView"](ctx_r18.queryRange($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
} if (rf & 2) {
    const rq_r17 = ctx.$implicit;
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("key", rq_r17.fieldname)("label", rq_r17.label)("database", ctx_r5.wi.database)("index", ctx_r5.wi.rangeRefresh.index)("queryDetectors", ctx_r5.config.wrapper.queryDetectors)("queryFits", ctx_r5.config.wrapper.queryFits);
} }
function NumericFieldWithRatiosComponent_div_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](1, "div", 16, 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
} }
function NumericFieldWithRatiosComponent_div_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "div", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](1, "div", 18, 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](3, "div", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtext"](4, "Ratios");
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelement"](5, "div", 20, 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
} }
class NumericFieldWithRatiosComponent extends app_widgets_numeric_field_numeric_field_component__WEBPACK_IMPORTED_MODULE_1__.NumericFieldComponent {
    constructor() {
        super(...arguments);
        this.ratioChartConfig = app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__.getDefaultConfig();
        this.ratioChartLayout = {};
        this.ratioChartData = [];
    }
    static makeRatio(numerator, denominator) {
        let iN = numerator.x.length - 1;
        let iD = denominator.x.length - 1;
        const ratio = { x: [], y: [] };
        while (iN >= 2 && iD >= 2) {
            if (numerator.x[iN] < denominator.x[iD - 1]) {
                --iD;
                continue;
            }
            if (numerator.x[iN - 1] > denominator.x[iD]) {
                --iN;
                continue;
            }
            const ts = numerator.x[iN] > denominator.x[iD] ? numerator.x[iN] : denominator.x[iD];
            ratio.x.unshift(ts);
            ratio.y.unshift(numerator.y[iN] / denominator.y[iD]);
            --iN;
            --iD;
        }
        return ratio;
    }
    ngOnInit() {
        super.ngOnInit();
        const wi = this.config['widget'];
        wi['yAxisTitle'] = 'Ratio';
        this.ratioChartLayout = app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__.configureDefaultLayout(wi);
        //ChartUtils.disableNavigation2d(this.ratioChartLayout, this.ratioChartConfig);
        const xaxis = this.ratioChartLayout['xaxis'] = this.ratioChartLayout['xaxis'] || {};
        xaxis['fixedrange'] = false;
        xaxis['autorange'] = false;
        if (wi['ratioYRangeZoom']) {
            this.ratioChartLayout['yaxis']['fixedrange'] = false;
            this.ratioChartLayout['yaxis']['range'] = wi['ratioYRangeZoom'];
        }
    }
    ngAfterViewInit() {
        Plotly.newPlot(this.ratioPlot.nativeElement, this.ratioChartData, this.ratioChartLayout, this.ratioChartConfig);
        super.ngAfterViewInit();
    }
    setData(newData) {
        super.setData(newData);
        this.updateRatioPlot();
    }
    updateLive() {
        super.updateLive();
        this.updateRatioPlot();
    }
    updateRatioPlot() {
        this.ratioChartData.length = 0;
        this.config['widget']['ratios'].forEach(r => {
            const d = r['denominator'];
            const n = r['numerator'];
            const denominator = this.series[d['source']][d['field']];
            const numerator = this.series[n['source']][n['field']];
            const ratio = NumericFieldWithRatiosComponent.makeRatio(numerator, denominator);
            ratio['name'] = r['name'] || numerator.name + '/' + denominator.name;
            this.ratioChartData.push(ratio);
        });
        Plotly.redraw(this.ratioPlot.nativeElement, this.ratioChartData);
    }
    onRelayout(event) {
        const propagate = super.onRelayout(event);
        const xaxis = this.ratioChartLayout['xaxis'];
        xaxis['range'] = this.chartLayout['xaxis']['range'];
        const yaxis = this.ratioChartLayout['yaxis'];
        // yaxis['autorange'] = true; Enable this if you want the y axis to automatically scale after changing the x axis zoom.
        Plotly.relayout(this.ratioPlot.nativeElement, { xaxis: xaxis, yaxis: yaxis });
        return propagate;
    }
}
NumericFieldWithRatiosComponent.ɵfac = /*@__PURE__*/ function () { let ɵNumericFieldWithRatiosComponent_BaseFactory; return function NumericFieldWithRatiosComponent_Factory(t) { return (ɵNumericFieldWithRatiosComponent_BaseFactory || (ɵNumericFieldWithRatiosComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵgetInheritedFactory"](NumericFieldWithRatiosComponent)))(t || NumericFieldWithRatiosComponent); }; }();
NumericFieldWithRatiosComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineComponent"]({ type: NumericFieldWithRatiosComponent, selectors: [["wm-numeric-field-with-ratios-widget"]], viewQuery: function NumericFieldWithRatiosComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵviewQuery"](_c0, 5);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵloadQuery"]()) && (ctx.ratioPlot = _t.first);
    } }, features: [_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵInheritDefinitionFeature"]], decls: 12, vars: 9, consts: [[3, "config", "info", "refresh", "start", "timer"], ["widgetWrapper", ""], [1, "widget-options"], ["clrForm", "", 4, "ngIf"], [1, "widget-queries"], [4, "ngIf"], [3, "query"], [3, "fillEnabled", "runEnabled", "lsEnabled", "query", 4, "ngIf"], ["inputType", "number", 3, "key", "label", "database", "index", "queryDetectors", "queryFits", "query", 4, "ngFor", "ngForOf"], ["class", "widget-content", 4, "ngIf"], ["clrForm", ""], ["type", "checkbox", "clrCheckbox", "", "name", "separatorsCheckbox", 3, "ngModel", "ngModelChange"], [3, "options", "query"], [3, "fillEnabled", "runEnabled", "lsEnabled", "query"], ["inputType", "number", 3, "key", "label", "database", "index", "queryDetectors", "queryFits", "query"], [1, "widget-content"], [2, "height", "100%", "width", "100%"], ["plot", ""], [2, "height", "55%", "width", "100%"], [1, "h6", "content-separator"], [2, "flex", "1 1 auto", "width", "100%"], ["ratioPlot", ""]], template: function NumericFieldWithRatiosComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](0, "wm-widget", 0, 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("refresh", function NumericFieldWithRatiosComponent_Template_wm_widget_refresh_0_listener() { return ctx.onRefreshEvent(); })("start", function NumericFieldWithRatiosComponent_Template_wm_widget_start_0_listener() { return ctx.onStartEvent(); })("timer", function NumericFieldWithRatiosComponent_Template_wm_widget_timer_0_listener() { return ctx.updateLive(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](3, NumericFieldWithRatiosComponent_form_3_Template, 8, 1, "form", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](4, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](5, NumericFieldWithRatiosComponent_div_5_Template, 2, 1, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementStart"](6, "wm-date-range-form", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵlistener"]("query", function NumericFieldWithRatiosComponent_Template_wm_date_range_form_query_6_listener($event) { return ctx.queryDateRange($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](7, NumericFieldWithRatiosComponent_wm_fill_run_ls_form_7_Template, 1, 3, "wm-fill-run-ls-form", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](8, NumericFieldWithRatiosComponent_wm_fill_run_ls_form_8_Template, 1, 3, "wm-fill-run-ls-form", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](9, NumericFieldWithRatiosComponent_wm_range_form_9_Template, 1, 6, "wm-range-form", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](10, NumericFieldWithRatiosComponent_div_10_Template, 3, 0, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵtemplate"](11, NumericFieldWithRatiosComponent_div_11_Template, 7, 0, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("config", ctx.config.wrapper)("info", ctx.info);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.config.widget.fieldChangeSeparators);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.wi.quickDateOptions);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.config.widget.fillQueriesEnabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.config.widget.runQueriesEnabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngForOf", ctx.wi.rangeQueries);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", !ctx.wi["ratios"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵproperty"]("ngIf", ctx.wi["ratios"]);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_8__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_8__.NgIf, _clr_angular__WEBPACK_IMPORTED_MODULE_9__.ClrLabel, _clr_angular__WEBPACK_IMPORTED_MODULE_9__.ClrForm, _clr_angular__WEBPACK_IMPORTED_MODULE_9__.ClrCheckbox, _clr_angular__WEBPACK_IMPORTED_MODULE_9__.ClrCheckboxContainer, _clr_angular__WEBPACK_IMPORTED_MODULE_9__.ClrCheckboxWrapper, _angular_forms__WEBPACK_IMPORTED_MODULE_10__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.NgModel, _angular_forms__WEBPACK_IMPORTED_MODULE_10__.NgForm, _shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_2__.WidgetComponent, _shared_date_range_form_date_range_form_component__WEBPACK_IMPORTED_MODULE_3__.DateRangeFormComponent, _shared_fill_run_ls_form_fill_run_ls_form_component__WEBPACK_IMPORTED_MODULE_4__.FillRunLsFormComponent, _shared_range_form_range_form_component__WEBPACK_IMPORTED_MODULE_5__.RangeFormComponent, _shared_quick_date_form_quick_date_form_component__WEBPACK_IMPORTED_MODULE_6__.QuickDateFormComponent], styles: [".widget-content[_ngcontent-%COMP%] {\r\n    width: 100%;\r\n    height: 100%;\r\n    overflow: hidden;\r\n    display: flex;\r\n    flex-flow: column;\r\n}\r\n\r\n.content-separator[_ngcontent-%COMP%] {\r\n    font-weight: bold;\r\n    text-align: center;\r\n    border-top: 1px silver solid;\r\n}\r\n\r\n.widget-queries[_ngcontent-%COMP%]    > *[_ngcontent-%COMP%] {\r\n    display: block;\r\n}\r\n\r\n.widget-queries[_ngcontent-%COMP%] > *[_ngcontent-%COMP%]:hover {\r\n    background-color: #D9E4EA;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm51bWVyaWMtZmllbGQuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLFdBQVc7SUFDWCxZQUFZO0lBQ1osZ0JBQWdCO0lBQ2hCLGFBQWE7SUFDYixpQkFBaUI7QUFDckI7O0FBRUE7SUFDSSxpQkFBaUI7SUFDakIsa0JBQWtCO0lBQ2xCLDRCQUE0QjtBQUNoQzs7QUFFQTtJQUNJLGNBQWM7QUFDbEI7O0FBRUE7SUFDSSx5QkFBeUI7QUFDN0IiLCJmaWxlIjoibnVtZXJpYy1maWVsZC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLndpZGdldC1jb250ZW50IHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWZsb3c6IGNvbHVtbjtcclxufVxyXG5cclxuLmNvbnRlbnQtc2VwYXJhdG9yIHtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgYm9yZGVyLXRvcDogMXB4IHNpbHZlciBzb2xpZDtcclxufVxyXG5cclxuLndpZGdldC1xdWVyaWVzID4gKiB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxufVxyXG5cclxuLndpZGdldC1xdWVyaWVzPio6aG92ZXIge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0Q5RTRFQTtcclxufVxyXG4iXX0= */"] });


/***/ }),

/***/ 14119:
/*!***************************************************************************************!*\
  !*** ./src/app/widgets/numeric-field-with-ratios/numeric-field-with-ratios.module.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NumericFieldWithRatiosModule": () => (/* binding */ NumericFieldWithRatiosModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/shared/shared.module */ 44466);
/* harmony import */ var _numeric_field_with_ratios_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./numeric-field-with-ratios.component */ 46223);
/* harmony import */ var _numeric_field_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../numeric-field/data.service */ 79081);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);





class NumericFieldWithRatiosModule {
}
NumericFieldWithRatiosModule.entry = _numeric_field_with_ratios_component__WEBPACK_IMPORTED_MODULE_1__.NumericFieldWithRatiosComponent;
NumericFieldWithRatiosModule.ɵfac = function NumericFieldWithRatiosModule_Factory(t) { return new (t || NumericFieldWithRatiosModule)(); };
NumericFieldWithRatiosModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: NumericFieldWithRatiosModule });
NumericFieldWithRatiosModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ providers: [_numeric_field_data_service__WEBPACK_IMPORTED_MODULE_2__.DataService], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
        app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](NumericFieldWithRatiosModule, { declarations: [_numeric_field_with_ratios_component__WEBPACK_IMPORTED_MODULE_1__.NumericFieldWithRatiosComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
        app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule] }); })();


/***/ })

}]);
//# sourceMappingURL=src_app_widgets_numeric-field-with-ratios_numeric-field-with-ratios_module_ts.js.map