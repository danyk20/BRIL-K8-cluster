"use strict";
(self["webpackChunkwebmonitor2"] = self["webpackChunkwebmonitor2"] || []).push([["src_app_widgets_dynamic-form-test_dynamic-form-test_module_ts"],{

/***/ 89441:
/*!**************************************************************************!*\
  !*** ./src/app/widgets/dynamic-form-test/dynamic-form-test.component.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DynamicFormTestComponent": () => (/* binding */ DynamicFormTestComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _shared_dynamic_form_dynamic_form_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../shared/dynamic-form/dynamic-form.component */ 36959);
/* harmony import */ var _shared_quick_date_form_quick_date_form_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../shared/quick-date-form/quick-date-form.component */ 94891);



class DynamicFormTestComponent {
    constructor() {
        this.quickDateFormOptions = [{
                unit: 'minutes',
                duration: 11,
                text: 'last 11 minutes'
            }, {
                unit: 'days',
                duration: 2,
                text: 'last 2 days'
            }];
        this.fields = [{
                "key": "ch",
                "type": "number",
                "templateOptions": {
                    "label": "Channels", "min": 0, "step": 0.1
                }
            }, {
                "key": "a",
                "type": "delimited-numbers",
                "templateOptions": { "label": "asdf", "delimiter": ":" }
            }];
        this.model = {};
    }
    onModelChange(event) {
        console.log('FORM MODEL CHANGE', event);
    }
    onQuickDateQuery(event) {
        console.log(event);
    }
}
DynamicFormTestComponent.ɵfac = function DynamicFormTestComponent_Factory(t) { return new (t || DynamicFormTestComponent)(); };
DynamicFormTestComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: DynamicFormTestComponent, selectors: [["wm-dynamic-fomr-test-widget"]], decls: 2, vars: 3, consts: [[3, "formFields", "model", "modelChange"], [3, "options", "query"]], template: function DynamicFormTestComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "wm-dynamic-form", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("modelChange", function DynamicFormTestComponent_Template_wm_dynamic_form_modelChange_0_listener($event) { return ctx.model = $event; })("modelChange", function DynamicFormTestComponent_Template_wm_dynamic_form_modelChange_0_listener($event) { return ctx.onModelChange($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "wm-quick-date-form", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("query", function DynamicFormTestComponent_Template_wm_quick_date_form_query_1_listener($event) { return ctx.onQuickDateQuery($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("formFields", ctx.fields)("model", ctx.model);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("options", ctx.quickDateFormOptions);
    } }, dependencies: [_shared_dynamic_form_dynamic_form_component__WEBPACK_IMPORTED_MODULE_0__.DynamicFormComponent, _shared_quick_date_form_quick_date_form_component__WEBPACK_IMPORTED_MODULE_1__.QuickDateFormComponent], encapsulation: 2 });


/***/ }),

/***/ 69890:
/*!***********************************************************************!*\
  !*** ./src/app/widgets/dynamic-form-test/dynamic-form-test.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DynamicFormTestModule": () => (/* binding */ DynamicFormTestModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/shared/shared.module */ 44466);
/* harmony import */ var _dynamic_form_test_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dynamic-form-test.component */ 89441);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);




class DynamicFormTestModule {
}
DynamicFormTestModule.entry = _dynamic_form_test_component__WEBPACK_IMPORTED_MODULE_1__.DynamicFormTestComponent;
DynamicFormTestModule.ɵfac = function DynamicFormTestModule_Factory(t) { return new (t || DynamicFormTestModule)(); };
DynamicFormTestModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: DynamicFormTestModule });
DynamicFormTestModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
        app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](DynamicFormTestModule, { declarations: [_dynamic_form_test_component__WEBPACK_IMPORTED_MODULE_1__.DynamicFormTestComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
        app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule] }); })();


/***/ })

}]);
//# sourceMappingURL=src_app_widgets_dynamic-form-test_dynamic-form-test_module_ts.js.map