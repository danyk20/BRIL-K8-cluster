"use strict";
(self["webpackChunkwebmonitor2"] = self["webpackChunkwebmonitor2"] || []).push([["default-src_app_widgets_array-field_array-lines_component_ts"],{

/***/ 14363:
/*!**************************************************************!*\
  !*** ./src/app/widgets/array-field/array-lines.component.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ArrayLinesComponent": () => (/* binding */ ArrayLinesComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! rxjs */ 20591);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! rxjs */ 25474);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! rxjs */ 10745);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 19337);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs/operators */ 53158);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs/operators */ 81203);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! rxjs/operators */ 51353);
/* harmony import */ var app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/shared/chart-utils */ 99593);
/* harmony import */ var app_widgets_base_chart_widget__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! app/widgets/base/chart-widget */ 47397);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var app_core_database_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! app/core/database.service */ 67084);
/* harmony import */ var app_core_event_bus_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! app/core/event-bus.service */ 40699);
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./data.service */ 41977);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../shared/widget/widget.component */ 81522);
/* harmony import */ var _shared_date_range_form_date_range_form_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../shared/date-range-form/date-range-form.component */ 63747);
/* harmony import */ var _shared_fill_run_ls_form_fill_run_ls_form_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../shared/fill-run-ls-form/fill-run-ls-form.component */ 49207);
/* harmony import */ var _shared_range_form_range_form_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../shared/range-form/range-form.component */ 2199);













function ArrayLinesComponent_wm_date_range_form_4_Template(rf, ctx) { if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "wm-date-range-form", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("query", function ArrayLinesComponent_wm_date_range_form_4_Template_wm_date_range_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r7); const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r6.queryRange($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
} }
function ArrayLinesComponent_wm_fill_run_ls_form_5_Template(rf, ctx) { if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "wm-fill-run-ls-form", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("query", function ArrayLinesComponent_wm_fill_run_ls_form_5_Template_wm_fill_run_ls_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r9); const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r8.queryFillRun($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("fillEnabled", true)("runEnabled", false)("lsEnabled", false);
} }
function ArrayLinesComponent_wm_fill_run_ls_form_6_Template(rf, ctx) { if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "wm-fill-run-ls-form", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("query", function ArrayLinesComponent_wm_fill_run_ls_form_6_Template_wm_fill_run_ls_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r11); const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r10.queryFillRun($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("fillEnabled", false)("runEnabled", true)("lsEnabled", false);
} }
function ArrayLinesComponent_wm_range_form_7_Template(rf, ctx) { if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "wm-range-form", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("query", function ArrayLinesComponent_wm_range_form_7_Template_wm_range_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r13); const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r12.queryFromEvent($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("key", ctx_r4.wi.xField);
} }
class ArrayLinesComponent extends app_widgets_base_chart_widget__WEBPACK_IMPORTED_MODULE_1__.ChartWidget {
    constructor(db, eventBus, dataService) {
        super(eventBus);
        this.db = db;
        this.eventBus = eventBus;
        this.dataService = dataService;
        this.reflow = () => undefined;
        this._aggregated = false;
        this.info = {};
    }
    set aggregated(newVal) {
        this._aggregated = newVal;
        this.info = Object.assign({}, this.info, { aggregated: newVal });
    }
    get aggregated() { return this._aggregated; }
    ;
    setupWidget() {
        this.wi = super.setupWidget({
            'liveWindow': 600000,
            'refreshSize': 100,
            'series': [],
            'timestampField': 'timestamp'
        });
        this.queryParams = {
            database: this.wi.database,
            index: this.wi.index,
            documentType: this.wi.documentType,
            timestampField: this.wi.timestampField,
            field: this.wi.field,
            series: this.wi.series,
            nestedPath: this.wi.nestedPath,
            terms: this.wi.terms,
            fillField: this.wi.fillField,
            runField: this.wi.runField,
            errorField: this.wi.errorField,
            aggregationAlgo: this.wi.aggregationAlgo,
            extraFields: this.wi.extraFields || [],
            histogramAggregatedQuery: this.wi.histogramAggregatedQuery,
            aggregationQueryParams: this.wi.aggregationQueryParams || [],
        };
        if (this.wi.errorField) {
            this.queryParams.extraFields.push(this.wi.errorField);
        }
        if (this.wi.hasOwnProperty('aggregationAlgo')) {
            if (this.wi.aggregationAlgo != 'sum' && this.wi.aggregationAlgo != 'avg' &&
                this.wi.aggregationAlgo != 'max' && this.wi.aggregationAlgo != 'min' &&
                this.wi.aggregationAlgo != 'value_count' && this.wi.aggregationAlgo != 'extended_stats') {
                this.wi.aggregationAlgo = 'avg';
            }
        }
        return this.wi;
    }
    ngAfterViewInit() {
        this.makeSeries();
        super.ngAfterViewInit();
        this.plot.nativeElement.on('plotly_relayout', this.onRelayout.bind(this));
        if (!this.wrapper.started) {
            this.refresh();
        }
    }
    queryFromEvent(event) {
        if (event['type'] === 'time_range_query') {
            this.widgetComponent.log('Received time range query', 'info');
            this.queryRange(event['payload']);
        }
        else if (event['type'] === 'fill_run_ls_query') {
            if (this.wi.fillQueriesEnabled || this.wi.runQueriesEnabled) {
                this.widgetComponent.log('Received FILL/RUN query', 'info');
                this.queryFillRun(event['payload']);
            }
        }
    }
    onRefreshEvent() {
        this.widgetComponent.stop();
        this.refresh();
    }
    onStartEvent() {
        this.updateLive();
    }
    onQueryError(error) {
        this.widgetComponent.log(String(error), 'danger');
        this.setChartData([]);
        throw (error);
    }
    refresh(size) {
        size = Number.isInteger(size) ? size : this.wi.refreshSize || 50;
        this.disableInteraction();
        const obs = this.dataService.queryNewest(this.queryParams, size).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.tap)(() => this.aggregated = false), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.tap)(this.setChartData.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.tap)(this.enableInteraction.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.catchError)(this.onQueryError.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.share)());
        obs.subscribe();
        return obs;
    }
    setChartData(hits) {
        const extra = {};
        this.queryParams.extraFields.forEach(f => {
            extra[f] = hits.map(hit => hit[f]);
        });
        const x = this._parseXValues(hits);
        this.wi.series.forEach((s, i) => {
            this.chartData[i].y = hits.map(hit => hit[this.wi.field][s]);
            this.chartData[i].x = x;
            this.chartData[i].text = this.makeTooltipTexts(hits);
            this.chartData[i]._extra = extra;
            if (this.wi.errorField) {
                this.chartData[i].error_y = this.makeErrorBars(hits, s);
            }
        });
        this.updateFieldSeparators();
        app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__.setAutorange(this.chartLayout);
        Plotly.redraw(this.plot.nativeElement);
    }
    _parseXValues(hits) {
        return hits.map(hit => this.tsToChartTimestamp(hit[this.queryParams.timestampField]));
    }
    makeErrorBars(hits, series) {
        return {
            type: 'data',
            array: hits.map(hit => hit[this.wi.errorField][series]),
            color: 'black',
            thickness: 1,
            symmetric: true
        };
    }
    queryRange(range) {
        this.widgetComponent.stop();
        let obs;
        if (range.msecTo - range.msecFrom > this.wi.aggregationThreshold) {
            obs = this.dataService.queryRangeAggregated(this.queryParams, range['strFrom'], range['strTo'], this.wi.aggregationAlgo).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.tap)(() => this.aggregated = true));
        }
        else {
            obs = this.dataService.queryRange(this.queryParams, range['strFrom'], range['strTo']).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.tap)(() => this.aggregated = false));
        }
        obs = obs.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.map)(this.setChartData.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.tap)(this.enableInteraction.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.catchError)(this.onQueryError.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.share)());
        this.disableInteraction();
        obs.subscribe();
        return obs;
    }
    queryFillRun(event) {
        this.widgetComponent.stop();
        const term = {};
        if (event['run']) {
            term[this.queryParams['runField']] = event['run'];
        }
        else if (event['fill']) {
            term[this.queryParams['fillField']] = event['fill'];
        }
        else {
            this.widgetComponent.log('One of [FILL, RUN] must be specified', 'warning');
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_14__.empty)();
        }
        this.widgetComponent.log('Querying timestamp extremes for FILL/RUN', 'info');
        this.disableInteraction();
        this.dataService.queryExtremesByTerm(this.queryParams, term)
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_15__.mergeMap)(extremes => {
            console.log(extremes);
            if (!extremes['min']['value'] || !extremes['max']['value']) {
                return (0,rxjs__WEBPACK_IMPORTED_MODULE_16__.throwError)('Failed to get timestamp extremes for FILL/RUN query. ' + JSON.stringify(event));
            }
            const min = extremes['min']['value_as_string'];
            const max = extremes['max']['value_as_string'];
            this.widgetComponent.log('Got timestamp extremes. ' + min + ', ' + max, 'info');
            const range = app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__.makeQueryRangeFromStrings(min, max);
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_17__.of)(range);
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_13__.map)(this.queryRange.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.tap)(this.enableInteraction.bind(this)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.catchError)(this.onQueryError.bind(this)))
            .subscribe();
    }
    updateLive() {
        if (this.aggregated || this.chartData.length < 1 || this.chartData[0].x.length < 1) {
            this.refresh().subscribe(this.setXZoomToLiveWindow.bind(this));
            return;
        }
        const x = this.chartData[0].x;
        const lastX = x[x.length - 1];
        this.dataService.queryNewestSince(this.queryParams, lastX)
            .subscribe(hits => {
            const extra = this.chartData[0]['_extra'];
            this.queryParams['extraFields'].forEach(f => {
                extra[f] = extra[f].concat(hits.map(hit => hit[f]));
            });
            this.wi.series.forEach((s, i) => {
                const trace = this.chartData[i];
                trace.y = trace.y.concat(hits.map(hit => hit[this.wi.field][s]));
                trace.x = trace.x.concat(this._parseXValues(hits));
                trace.text = trace.text.concat(this.makeTooltipTexts(hits));
                trace._extra = extra;
                if (this.wi.errorField) {
                    trace.error_y = trace.error_y.concat(this.makeErrorBars(hits, s).array);
                }
                this.dropPointsOutsideLiveWindow(trace);
            });
            this.updateFieldSeparators();
            this.setXZoomToLiveWindow();
            Plotly.redraw(this.plot.nativeElement, this.chartData);
        });
    }
    makeTooltipTexts(hits) {
        const tooltipTextConfig = this.wi.tooltipInfo;
        if (!tooltipTextConfig) {
            return [];
        }
        return hits.map(point => app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__.makeTooltipText(point, tooltipTextConfig));
    }
    dropPointsOutsideLiveWindow(trace) {
        const lastX = this.tsToMilliseconds(trace.x[trace.x.length - 1]);
        const liveWindow = this.wi.liveWindow;
        var dropErrorY = function (trace) { };
        if (this.wi.errorField) {
            dropErrorY = function (trace) {
                trace.error_y.array.shift();
            };
        }
        while (lastX - this.tsToMilliseconds(trace.x[0]) > liveWindow) {
            trace.x.shift();
            trace.y.shift();
            trace.text.shift();
            this.queryParams['extraFields'].forEach(f => {
                trace._extra[f].shift();
            });
            dropErrorY(trace);
        }
    }
    setXZoomToLiveWindow() {
        if (this.chartData.length < 1) {
            return;
        }
        const trace = this.chartData[0];
        const max = this.tsToMilliseconds(trace.x[trace.x.length - 1]);
        const min = max - this.wi.liveWindow;
        const mod = app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__.setXRange(this.plot.nativeElement['layout'], (new Date(min)).toISOString(), (new Date(max)).toISOString());
        Plotly.relayout(this.plot.nativeElement, mod);
    }
    makeSeries() {
        this.chartData.length = 0;
        const names = this.wi.legendNames || [];
        this.wi.series.forEach((s, i) => {
            const newSeries = {
                x: [],
                y: [],
                text: [],
                name: names[i] || this.wi.field + '.' + s,
                type: 'scatter',
                line: { width: 1 },
            };
            this.chartData.push(newSeries);
        });
    }
    onRelayout(event) {
        if (!this.aggregated) {
            return 1;
        }
        const range = app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__.makeQueryRangeFromZoomEvent(event);
        if (range) {
            this.disableInteraction();
            this.queryRange(range)
                .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.tap)(this.enableInteraction.bind(this)))
                .subscribe();
        }
    }
    updateFieldSeparators(relayout = false) {
        return super.updateFieldSeparators(relayout, this.aggregated);
    }
}
ArrayLinesComponent.ɵfac = function ArrayLinesComponent_Factory(t) { return new (t || ArrayLinesComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](app_core_database_service__WEBPACK_IMPORTED_MODULE_2__.DatabaseService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](app_core_event_bus_service__WEBPACK_IMPORTED_MODULE_3__.EventBusService), _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdirectiveInject"](_data_service__WEBPACK_IMPORTED_MODULE_4__.DataService)); };
ArrayLinesComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineComponent"]({ type: ArrayLinesComponent, selectors: [["wm-widget-array-lines"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵInheritDefinitionFeature"]], decls: 11, vars: 6, consts: [[3, "config", "info", "refresh", "start", "timer"], ["widgetWrapper", ""], [1, "widget-options"], [1, "widget-queries"], [3, "query", 4, "ngIf"], [3, "fillEnabled", "runEnabled", "lsEnabled", "query", 4, "ngIf"], ["inputType", "number", 3, "key", "query", 4, "ngIf"], [1, "widget-content"], [2, "height", "100%", "width", "100%"], ["plot", ""], [3, "query"], [3, "fillEnabled", "runEnabled", "lsEnabled", "query"], ["inputType", "number", 3, "key", "query"]], template: function ArrayLinesComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](0, "wm-widget", 0, 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵlistener"]("refresh", function ArrayLinesComponent_Template_wm_widget_refresh_0_listener() { return ctx.onRefreshEvent(); })("start", function ArrayLinesComponent_Template_wm_widget_start_0_listener() { return ctx.onStartEvent(); })("timer", function ArrayLinesComponent_Template_wm_widget_timer_0_listener() { return ctx.updateLive(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](4, ArrayLinesComponent_wm_date_range_form_4_Template, 1, 0, "wm-date-range-form", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](5, ArrayLinesComponent_wm_fill_run_ls_form_5_Template, 1, 3, "wm-fill-run-ls-form", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](6, ArrayLinesComponent_wm_fill_run_ls_form_6_Template, 1, 3, "wm-fill-run-ls-form", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵtemplate"](7, ArrayLinesComponent_wm_range_form_7_Template, 1, 1, "wm-range-form", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementStart"](8, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelement"](9, "div", 8, 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵelementEnd"]()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("config", ctx.config.wrapper)("info", ctx.info);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.wi.timestampField);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.wi.fillQueriesEnabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.wi.runQueriesEnabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵproperty"]("ngIf", ctx.wi.hasOwnProperty("xField") && ctx.wi["xField"]);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_18__.NgIf, _shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_5__.WidgetComponent, _shared_date_range_form_date_range_form_component__WEBPACK_IMPORTED_MODULE_6__.DateRangeFormComponent, _shared_fill_run_ls_form_fill_run_ls_form_component__WEBPACK_IMPORTED_MODULE_7__.FillRunLsFormComponent, _shared_range_form_range_form_component__WEBPACK_IMPORTED_MODULE_8__.RangeFormComponent], styles: [".widget-content[_ngcontent-%COMP%] {\r\n    overflow: hidden;\r\n    width: 100%;\r\n    height: 100%;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFycmF5LWxpbmVzLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxnQkFBZ0I7SUFDaEIsV0FBVztJQUNYLFlBQVk7QUFDaEIiLCJmaWxlIjoiYXJyYXktbGluZXMuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi53aWRnZXQtY29udGVudCB7XHJcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbn1cclxuIl19 */"] });


/***/ })

}]);
//# sourceMappingURL=default-src_app_widgets_array-field_array-lines_component_ts.js.map