"use strict";
(self["webpackChunkwebmonitor2"] = self["webpackChunkwebmonitor2"] || []).push([["src_app_widgets_pileup_pileup_module_ts"],{

/***/ 46480:
/*!*********************************!*\
  !*** ./src/app/shared/stats.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "mean": () => (/* binding */ mean),
/* harmony export */   "median": () => (/* binding */ median),
/* harmony export */   "root_mean_square": () => (/* binding */ root_mean_square),
/* harmony export */   "standardDeviation": () => (/* binding */ standardDeviation),
/* harmony export */   "variance": () => (/* binding */ variance)
/* harmony export */ });
function mean(values) {
    return values.reduce(function (s, x) { return s + x; }, 0) / values.length;
}
function variance(values) {
    const m = mean(values);
    return mean(values.map(function (x) {
        return Math.pow(x - m, 2);
    }));
}
function standardDeviation(values) {
    return Math.sqrt(variance(values));
}
function root_mean_square(values) {
    if (!values.length) {
        return NaN;
    }
    const sum_of_squares = values.reduce(function (s, x) { return (s + x * x); }, 0);
    return Math.sqrt(sum_of_squares / values.length);
}
function median(values) {
    if (!values.length) {
        return NaN;
    }
    const numbers = values.slice().sort((a, b) => a - b);
    const middle = Math.floor(numbers.length / 2);
    const isEven = numbers.length % 2 === 0;
    return isEven ? (numbers[middle] + numbers[middle - 1]) / 2 : numbers[middle];
}


/***/ }),

/***/ 97387:
/*!****************************************************!*\
  !*** ./src/app/widgets/pileup/pileup.component.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PileupComponent": () => (/* binding */ PileupComponent)
/* harmony export */ });
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 71989);
/* harmony import */ var app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/shared/chart-utils */ 99593);
/* harmony import */ var app_shared_stats__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! app/shared/stats */ 46480);
/* harmony import */ var _array_snapshot_array_snapshot_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../array-snapshot/array-snapshot.component */ 987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @clr/angular */ 4151);
/* harmony import */ var _shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../shared/widget/widget.component */ 81522);
/* harmony import */ var _shared_fill_run_ls_form_fill_run_ls_form_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../shared/fill-run-ls-form/fill-run-ls-form.component */ 49207);









function PileupComponent_wm_fill_run_ls_form_4_Template(rf, ctx) { if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "wm-fill-run-ls-form", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("query", function PileupComponent_wm_fill_run_ls_form_4_Template_wm_fill_run_ls_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r5); const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r4.queryRunLs($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("fillEnabled", false)("runEnabled", true)("lsEnabled", true);
} }
function PileupComponent_clr_alert_6_Template(rf, ctx) { if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "clr-alert", 10)(1, "div", 11)(2, "span", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3, " This chart relies on WebGL technology, which is not supported or turned off in this browser. Would you like to try using fallback methods? ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](4, "div", 13)(5, "button", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function PileupComponent_clr_alert_6_Template_button_click_5_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r7); const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r6.tryWebGLFallback()); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](6, " Try fallback ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("clrAlertType", "alert-danger")("clrAlertClosable", false);
} }
class PileupComponent extends _array_snapshot_array_snapshot_component__WEBPACK_IMPORTED_MODULE_2__.ArraySnapshotComponent {
    constructor() {
        super(...arguments);
        this.lastData = null;
    }
    ngOnInit() {
        super.ngOnInit();
        this.widget.xAxisTitle = this.widget.xAxisTitle || 'Pileup';
        this.widget.yAxisTitle = this.widget.yAxisTitle || 'Frequency (interactions)';
        this.widget.histogramStep = this.widget.histogramStep || PileupComponent.HISTOGRAM_STEP_DEFAULT;
        this.widget.minbias = this.widget.minbias || PileupComponent.MINBIAS_DEFAULT;
        this.widget.statisticsFilter = this.widget.statisticsFilter || PileupComponent.STATISTICS_FILTER_DEFAULT;
        this.wrapper.infoEnabled = true;
        if (this.queryParams.fields.length !== 1) {
            const msg = 'Pileup chart must have a single field configured';
            console.error(msg, this.widget);
            throw (msg);
        }
        this.setupPileupOptions();
    }
    setData(newData) {
        this.lastData = newData;
        if (!newData[0]) {
            this.widgetComponent.log('Cannot draw chart: no data.', 'danger', 3500);
            return;
        }
        this.chartData.length = 0;
        this.series.length = 0;
        const field = this.queryParams.fields[0];
        this.pileups = newData[0][field.name].map(value => value * this.widget.minbias / 11245.0);
        const y = [];
        this.pileups.forEach(pu => {
            const bin = Math.floor(pu / this.widget.histogramStep);
            if (y[bin]) {
                y[bin] += 1;
            }
            else {
                y[bin] = 1;
            }
        });
        const x = y.map((val, i) => i * this.widget.histogramStep);
        const newSeries = {
            x: x,
            y: y,
            name: field.seriesName,
            type: 'bar',
            mode: 'markers',
            marker: { size: 5 }
        };
        this.chartData.push(newSeries);
        this.series.push(newSeries);
        this.updateAnnotation(newData);
        app_shared_chart_utils__WEBPACK_IMPORTED_MODULE_0__.setAutorange(this.chartLayout);
        Plotly.redraw(this.plot.nativeElement, this.chartData, this.chartLayout);
        this.updateInfo(newData);
    }
    updateInfo(newData) {
        super.updateInfo(newData);
        const stats = this.calculateStatistics();
        Object.assign(this.info, {
            'MinBiasXSec.': this.widget.minbias,
            'Bin size': this.widget.histogramStep,
            'Stats filter': '>=' + this.widget.statisticsFilter,
            'nBX': stats.filteredBX,
            'Mean': stats.mean.toFixed(6),
            'Std.deviation': stats.stdDeviation.toFixed(6)
        });
    }
    calculateStatistics() {
        const filtered = this.pileups.filter(v => v >= this.widget.statisticsFilter);
        const filteredBX = filtered.length;
        const mean = app_shared_stats__WEBPACK_IMPORTED_MODULE_1__.mean(filtered);
        const stdDev = app_shared_stats__WEBPACK_IMPORTED_MODULE_1__.standardDeviation(filtered);
        return {
            filteredBX: filtered.length,
            mean: app_shared_stats__WEBPACK_IMPORTED_MODULE_1__.mean(filtered),
            stdDeviation: app_shared_stats__WEBPACK_IMPORTED_MODULE_1__.standardDeviation(filtered)
        };
    }
    setupPileupOptions() {
        const pileupOptions = [{
                key: 'histogramStep', type: 'number', templateOptions: { label: 'Histogram step' }
            }, {
                key: 'minbias', type: 'number', templateOptions: { label: 'Minbias' }
            }, {
                key: 'statisticsFilter', type: 'number', templateOptions: { label: 'Statistics filter', min: 0, step: 0.1 }
            }];
        if (this.widgetComponent.extraOptions && this.widgetComponent.extraOptions.length) {
            this.widgetComponent.extraOptions = this.widgetComponent.extraOptions.concat(pileupOptions);
        }
        else {
            this.widgetComponent.extraOptions = pileupOptions;
        }
        this.widgetComponent.extraOptionsModel = Object.assign({}, this.widgetComponent.extraOptionsModel, {
            'histogramStep': this.widget.histogramStep,
            'minbias': this.widget.minbias,
            'statisticsFilter': this.widget.statisticsFilter
        });
        this.widgetComponent.extraOptionsModelChange.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.debounceTime)(1000)).subscribe(model => {
            this.widget.histogramStep = model['histogramStep'];
            this.widget.minbias = model['minbias'];
            this.widget.statisticsFilter = model['statisticsFilter'];
            this.setData(this.lastData);
        });
    }
}
PileupComponent.HISTOGRAM_STEP_DEFAULT = 2;
PileupComponent.MINBIAS_DEFAULT = 80000;
PileupComponent.STATISTICS_FILTER_DEFAULT = 1.0;
PileupComponent.ɵfac = /*@__PURE__*/ function () { let ɵPileupComponent_BaseFactory; return function PileupComponent_Factory(t) { return (ɵPileupComponent_BaseFactory || (ɵPileupComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetInheritedFactory"](PileupComponent)))(t || PileupComponent); }; }();
PileupComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({ type: PileupComponent, selectors: [["wm-pileup-widget"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵInheritDefinitionFeature"]], decls: 9, vars: 4, consts: [[3, "config", "info", "refresh", "start", "timer"], ["widgetWrapper", ""], [1, "widget-options"], [1, "widget-queries"], [3, "fillEnabled", "runEnabled", "lsEnabled", "query", 4, "ngIf"], [1, "widget-content"], [3, "clrAlertType", "clrAlertClosable", 4, "ngIf"], [2, "height", "100%", "width", "100%"], ["plot", ""], [3, "fillEnabled", "runEnabled", "lsEnabled", "query"], [3, "clrAlertType", "clrAlertClosable"], ["clr-alert-item", "", 1, "alert-item"], [1, "alert-text"], [1, "alert-actions"], [1, "btn", "alert-action", 3, "click"]], template: function PileupComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "wm-widget", 0, 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("refresh", function PileupComponent_Template_wm_widget_refresh_0_listener() { return ctx.onRefreshEvent(); })("start", function PileupComponent_Template_wm_widget_start_0_listener() { return ctx.onStartEvent(); })("timer", function PileupComponent_Template_wm_widget_timer_0_listener() { return ctx.updateLive(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](2, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](4, PileupComponent_wm_fill_run_ls_form_4_Template, 1, 3, "wm-fill-run-ls-form", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](5, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](6, PileupComponent_clr_alert_6_Template, 7, 2, "clr-alert", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](7, "div", 7, 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("config", ctx.config.wrapper)("info", ctx.info);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.config.widget.runLsQueriesEnabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.needWebGLFallback);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _clr_angular__WEBPACK_IMPORTED_MODULE_8__.ClrAlert, _clr_angular__WEBPACK_IMPORTED_MODULE_8__.ClrAlertText, _shared_widget_widget_component__WEBPACK_IMPORTED_MODULE_3__.WidgetComponent, _shared_fill_run_ls_form_fill_run_ls_form_component__WEBPACK_IMPORTED_MODULE_4__.FillRunLsFormComponent], styles: [".widget-content[_ngcontent-%COMP%] {\r\n    width: 100%;\r\n    height: 100%;\r\n    overflow: hidden;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFycmF5LXNuYXBzaG90LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxXQUFXO0lBQ1gsWUFBWTtJQUNaLGdCQUFnQjtBQUNwQiIsImZpbGUiOiJhcnJheS1zbmFwc2hvdC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLndpZGdldC1jb250ZW50IHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxufVxyXG4iXX0= */"] });


/***/ }),

/***/ 19008:
/*!*************************************************!*\
  !*** ./src/app/widgets/pileup/pileup.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PileupModule": () => (/* binding */ PileupModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/shared/shared.module */ 44466);
/* harmony import */ var _array_snapshot_data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../array-snapshot/data.service */ 66036);
/* harmony import */ var _pileup_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pileup.component */ 97387);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);





class PileupModule {
}
PileupModule.entry = _pileup_component__WEBPACK_IMPORTED_MODULE_2__.PileupComponent;
PileupModule.ɵfac = function PileupModule_Factory(t) { return new (t || PileupModule)(); };
PileupModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: PileupModule });
PileupModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ providers: [_array_snapshot_data_service__WEBPACK_IMPORTED_MODULE_1__.DataService], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
        app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](PileupModule, { declarations: [_pileup_component__WEBPACK_IMPORTED_MODULE_2__.PileupComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
        app_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule] }); })();


/***/ })

}]);
//# sourceMappingURL=src_app_widgets_pileup_pileup_module_ts.js.map