"use strict";
(self["webpackChunkwebmonitor2"] = self["webpackChunkwebmonitor2"] || []).push([["main"],{

/***/ 51890:
/*!*************************************************************!*\
  !*** ./src/app/app-location/app-location-link.directive.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppLocationLink": () => (/* binding */ AppLocationLink)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _app_location_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app-location.service */ 23269);



class AppLocationLink {
    constructor(el, locationService) {
        this.el = el;
        this.locationService = locationService;
    }
    ngAfterViewInit() {
        this.el.nativeElement['href'] = this.url;
    }
    onClick(event) {
        event.stopPropagation();
        event.preventDefault();
        this.locationService.go(this.url);
    }
}
AppLocationLink.ɵfac = function AppLocationLink_Factory(t) { return new (t || AppLocationLink)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_app_location_service__WEBPACK_IMPORTED_MODULE_0__.AppLocationService)); };
AppLocationLink.ɵdir = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineDirective"]({ type: AppLocationLink, selectors: [["", "locationLink", ""]], hostBindings: function AppLocationLink_HostBindings(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function AppLocationLink_click_HostBindingHandler($event) { return ctx.onClick($event); });
    } }, inputs: { url: ["locationLink", "url"] } });


/***/ }),

/***/ 19260:
/*!*****************************************************!*\
  !*** ./src/app/app-location/app-location.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppLocationModule": () => (/* binding */ AppLocationModule)
/* harmony export */ });
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../shared/shared.module */ 44466);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _app_location_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app-location.service */ 23269);
/* harmony import */ var _app_location_link_directive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app-location-link.directive */ 51890);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);





class AppLocationModule {
}
AppLocationModule.ɵfac = function AppLocationModule_Factory(t) { return new (t || AppLocationModule)(); };
AppLocationModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: AppLocationModule });
AppLocationModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ providers: [
        [_angular_common__WEBPACK_IMPORTED_MODULE_4__.Location, { provide: _angular_common__WEBPACK_IMPORTED_MODULE_4__.LocationStrategy, useClass: _angular_common__WEBPACK_IMPORTED_MODULE_4__.PathLocationStrategy }],
        _app_location_service__WEBPACK_IMPORTED_MODULE_1__.AppLocationService,
    ], imports: [_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](AppLocationModule, { declarations: [_app_location_link_directive__WEBPACK_IMPORTED_MODULE_2__.AppLocationLink], imports: [_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule], exports: [_app_location_link_directive__WEBPACK_IMPORTED_MODULE_2__.AppLocationLink] }); })();


/***/ }),

/***/ 23269:
/*!******************************************************!*\
  !*** ./src/app/app-location/app-location.service.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppLocationService": () => (/* binding */ AppLocationService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 94666);



class AppLocationService {
    constructor(location) {
        this.location = location;
        this.location$ = new rxjs__WEBPACK_IMPORTED_MODULE_0__.Subject();
        this.lastLocationPath = this.location.path();
        this.locationSubscription = this.location.subscribe(popState => { this.onLocationChange(popState.url); });
    }
    ngOnDestroy() {
        this.locationSubscription.unsubscribe();
    }
    go(path) {
        if (path === this.lastLocationPath) {
            return;
        }
        this.location.go(path);
        this.lastLocationPath = path;
        this.onLocationChange(path);
    }
    getPath() {
        return this.location.path();
    }
    onLocationChange(path) {
        this.location$.next(path);
    }
}
AppLocationService.ɵfac = function AppLocationService_Factory(t) { return new (t || AppLocationService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_common__WEBPACK_IMPORTED_MODULE_2__.Location)); };
AppLocationService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: AppLocationService, factory: AppLocationService.ɵfac });


/***/ }),

/***/ 42175:
/*!***************************************!*\
  !*** ./src/app/app-location/index.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppLocationLink": () => (/* reexport safe */ _app_location_link_directive__WEBPACK_IMPORTED_MODULE_2__.AppLocationLink),
/* harmony export */   "AppLocationModule": () => (/* reexport safe */ _app_location_module__WEBPACK_IMPORTED_MODULE_0__.AppLocationModule),
/* harmony export */   "AppLocationService": () => (/* reexport safe */ _app_location_service__WEBPACK_IMPORTED_MODULE_1__.AppLocationService)
/* harmony export */ });
/* harmony import */ var _app_location_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app-location.module */ 19260);
/* harmony import */ var _app_location_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app-location.service */ 23269);
/* harmony import */ var _app_location_link_directive__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app-location-link.directive */ 51890);





/***/ }),

/***/ 55041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var _preset_routes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./preset-routes */ 33238);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./config */ 39698);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var app_core_sandbox_preset_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! app/core/sandbox-preset.service */ 44739);
/* harmony import */ var _core_event_bus_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./core/event-bus.service */ 40699);
/* harmony import */ var _app_location__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app-location */ 42175);
/* harmony import */ var _preset_resolve_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./preset-resolve.service */ 15912);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _core_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./core/dashboard/dashboard.component */ 50256);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @clr/angular */ 4151);
/* harmony import */ var _settings_settings_modal_settings_modal_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./settings/settings-modal/settings-modal.component */ 38169);
/* harmony import */ var _app_location_app_location_link_directive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app-location/app-location-link.directive */ 51890);
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./home/home.component */ 45067);













function AppComponent_clr_dropdown_menu_13_ng_container_1_a_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "a", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
} if (rf & 2) {
    const p_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("locationLink", p_r5.path);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", p_r5.title, " ");
} }
function AppComponent_clr_dropdown_menu_13_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](1, AppComponent_clr_dropdown_menu_13_ng_container_1_a_1_Template, 2, 2, "a", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const p_r5 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", p_r5.title);
} }
function AppComponent_clr_dropdown_menu_13_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "clr-dropdown-menu");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](1, AppComponent_clr_dropdown_menu_13_ng_container_1_Template, 2, 1, "ng-container", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](2, "div", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](3, "a", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](4, " -sandbox- ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx_r0.presetRoutes);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("locationLink", ctx_r0.sandboxPath);
} }
function AppComponent_app_home_36_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](0, "app-home");
} }
class AppComponent {
    constructor(sandboxPreset, eventBus, locationService, presetResolver) {
        this.sandboxPreset = sandboxPreset;
        this.eventBus = eventBus;
        this.locationService = locationService;
        this.presetResolver = presetResolver;
        this.sandboxPath = _preset_routes__WEBPACK_IMPORTED_MODULE_0__.SANDBOX_PATH;
        this.presetRoutes = _preset_routes__WEBPACK_IMPORTED_MODULE_0__.ROUTES;
        this.hideDashboard = false;
        this.onLocationChange(this.locationService.getPath());
        this.currentLocationSubs = this.locationService.location$.subscribe(this.onLocationChange.bind(this));
        this.sandboxConfigSubs = this.sandboxPreset.config$.subscribe(this.onSandboxPresetChange.bind(this));
        this.sandboxPreset.setConfig(_config__WEBPACK_IMPORTED_MODULE_1__.initialSandboxPreset);
    }
    ngOnDestroy() {
        this.currentLocationSubs.unsubscribe();
        this.sandboxConfigSubs.unsubscribe();
    }
    onLocationChange(path) {
        if (path === '') {
            this.hideDashboard = true;
            return;
        }
        this.hideDashboard = false;
        if (path === _preset_routes__WEBPACK_IMPORTED_MODULE_0__.SANDBOX_PATH) {
            this.presetConfig = this.sandboxPreset.getConfig();
            return;
        }
        const route = this.presetRoutes.find(el => el.path === path);
        if (!route) {
            this.presetConfig = null;
            return;
        }
        this.presetResolver.resolve(route.config_url).subscribe(val => {
            this.presetConfig = val;
        }, err => {
            this.presetConfig = null;
        });
    }
    onSandboxPresetChange(newConfig) {
        if (this.locationService.getPath() === _preset_routes__WEBPACK_IMPORTED_MODULE_0__.SANDBOX_PATH) {
            this.presetConfig = this.sandboxPreset.getConfig();
        }
    }
    play() {
        const event = { type: 'global_startstop', payload: 'start' };
        this.eventBus.emit(0, event);
    }
    stop() {
        const event = { type: 'global_startstop', payload: 'stop' };
        this.eventBus.emit(0, event);
    }
}
AppComponent.ɵfac = function AppComponent_Factory(t) { return new (t || AppComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](app_core_sandbox_preset_service__WEBPACK_IMPORTED_MODULE_2__.SandboxPresetService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_core_event_bus_service__WEBPACK_IMPORTED_MODULE_3__.EventBusService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_app_location__WEBPACK_IMPORTED_MODULE_4__.AppLocationService), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_preset_resolve_service__WEBPACK_IMPORTED_MODULE_5__.PresetResolveService)); };
AppComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineComponent"]({ type: AppComponent, selectors: [["webmonitor-app"]], decls: 41, vars: 6, consts: [[1, "main-container"], [1, "header", "header-6"], [1, "branding"], ["href", "/", 1, "nav-link"], ["shape", "bar-chart", 1, "is-solid", "is-inverse"], [1, "title"], [1, "header-nav"], [1, "header-actions"], ["clrDropdownTrigger", "", 1, "nav-text"], ["shape", "caret down"], [4, "clrIfOpen"], [1, "nav-text", "text-info"], ["href", "http://srv-s2d16-22-01.cms/webmonitor-backup", 1, "nav-link", "nav-text"], [1, "nav-link", "nav-icon", "tooltip", "tooltip-bottom-left", "tooltip-xs", 3, "click"], ["shape", "play", 1, "is-solid"], [1, "tooltip-content"], ["shape", "stop", 1, "is-solid"], ["shape", "grid-view"], ["shape", "cog"], [1, "content-container"], [1, "content-area"], [4, "ngIf"], [3, "hidden", "config"], ["dashboard", ""], [3, "dashboard"], ["settings", ""], [4, "ngFor", "ngForOf"], [1, "dropdown-divider"], ["clrDropdownItem", "", 3, "locationLink"], ["clrDropdownItem", "", 3, "locationLink", 4, "ngIf"]], template: function AppComponent_Template(rf, ctx) { if (rf & 1) {
        const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 0)(1, "header", 1)(2, "div", 2)(3, "a", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](4, "clr-icon", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](5, "span", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](6, "webmonitor");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](7, "div", 6)(8, "div", 7)(9, "clr-dropdown")(10, "button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](11, " Presets ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](12, "clr-icon", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](13, AppComponent_clr_dropdown_menu_13_Template, 5, 2, "clr-dropdown-menu", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](14, "div", 11)(15, "a", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](16, " Backup: srv-s2d16-22-01.cms/webmonitor-backup ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](17, "div", 7)(18, "a", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function AppComponent_Template_a_click_18_listener() { return ctx.play(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](19, "clr-icon", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](20, "span", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](21, " Start ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](22, "a", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function AppComponent_Template_a_click_22_listener() { return ctx.stop(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](23, "clr-icon", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](24, "span", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](25, " Stop ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](26, "a", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function AppComponent_Template_a_click_26_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r8); const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵreference"](38); return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](_r2.layoutMode = !_r2.layoutMode); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](27, "clr-icon", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](28, "span", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](29, " Layout mode ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](30, "a", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function AppComponent_Template_a_click_30_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵrestoreView"](_r8); const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵreference"](40); return _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵresetView"](_r3.open()); });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](31, "clr-icon", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](32, "span", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](33, " Settings ");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](34, "div", 19)(35, "div", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](36, AppComponent_app_home_36_Template, 1, 0, "app-home", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](37, "app-dashboard", 22, 23)(39, "app-settings-modal", 24, 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
    } if (rf & 2) {
        const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵreference"](38);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](27);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵclassProp"]("is-solid", _r2.layoutMode);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", ctx.hideDashboard);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("hidden", ctx.hideDashboard)("config", ctx.presetConfig);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("dashboard", _r2);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_11__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_11__.NgIf, _core_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_6__.DashboardComponent, _clr_angular__WEBPACK_IMPORTED_MODULE_12__.ClrIconCustomTag, _clr_angular__WEBPACK_IMPORTED_MODULE_12__.ClrIfOpen, _clr_angular__WEBPACK_IMPORTED_MODULE_12__.ClrDropdown, _clr_angular__WEBPACK_IMPORTED_MODULE_12__.ClrDropdownMenu, _clr_angular__WEBPACK_IMPORTED_MODULE_12__.ClrDropdownTrigger, _clr_angular__WEBPACK_IMPORTED_MODULE_12__.ClrDropdownItem, _settings_settings_modal_settings_modal_component__WEBPACK_IMPORTED_MODULE_7__.SettingsModalComponent, _app_location_app_location_link_directive__WEBPACK_IMPORTED_MODULE_8__.AppLocationLink, _home_home_component__WEBPACK_IMPORTED_MODULE_9__.HomeComponent], styles: ["header[_ngcontent-%COMP%] {\r\n    z-index: 5;\r\n}\r\n\r\n.nav-link[_ngcontent-%COMP%] {\r\n    cursor: pointer;\r\n}\r\n\r\n.main-container[_ngcontent-%COMP%]   .content-container[_ngcontent-%COMP%]   .content-area[_ngcontent-%COMP%] {\r\n    padding: 0.4rem;\r\n}\r\n\r\n.dropdown-menu[_ngcontent-%COMP%] {\r\n    max-height: calc(10 * 2rem);\r\n    overflow-y: scroll;\r\n}\r\n\r\n.dropdown-item[_ngcontent-%COMP%] {\r\n    min-height: 2rem;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksVUFBVTtBQUNkOztBQUVBO0lBQ0ksZUFBZTtBQUNuQjs7QUFFQTtJQUNJLGVBQWU7QUFDbkI7O0FBRUE7SUFDSSwyQkFBMkI7SUFDM0Isa0JBQWtCO0FBQ3RCOztBQUVBO0lBQ0ksZ0JBQWdCO0FBQ3BCIiwiZmlsZSI6ImFwcC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaGVhZGVyIHtcclxuICAgIHotaW5kZXg6IDU7XHJcbn1cclxuXHJcbi5uYXYtbGluayB7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5tYWluLWNvbnRhaW5lciAuY29udGVudC1jb250YWluZXIgLmNvbnRlbnQtYXJlYSB7XHJcbiAgICBwYWRkaW5nOiAwLjRyZW07XHJcbn1cclxuXHJcbi5kcm9wZG93bi1tZW51IHtcclxuICAgIG1heC1oZWlnaHQ6IGNhbGMoMTAgKiAycmVtKTtcclxuICAgIG92ZXJmbG93LXk6IHNjcm9sbDtcclxufVxyXG5cclxuLmRyb3Bkb3duLWl0ZW0ge1xyXG4gICAgbWluLWhlaWdodDogMnJlbTtcclxufVxyXG4iXX0= */"] });


/***/ }),

/***/ 36747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/platform-browser */ 34497);
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/platform-browser/animations */ 37146);
/* harmony import */ var _core_core_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./core/core.module */ 40294);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./shared/shared.module */ 44466);
/* harmony import */ var _settings_settings_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./settings/settings.module */ 27075);
/* harmony import */ var _app_location__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app-location */ 42175);
/* harmony import */ var _widgets_widgets_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./widgets/widgets.module */ 50546);
/* harmony import */ var _preset_resolve_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./preset-resolve.service */ 15912);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app.component */ 55041);
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./home/home.component */ 45067);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @clr/angular */ 4151);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 22560);













class AppModule {
}
AppModule.ɵfac = function AppModule_Factory(t) { return new (t || AppModule)(); };
AppModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineNgModule"]({ type: AppModule, bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_6__.AppComponent] });
AppModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineInjector"]({ providers: [
        _preset_resolve_service__WEBPACK_IMPORTED_MODULE_5__.PresetResolveService
    ], imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_9__.BrowserModule,
        _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_10__.BrowserAnimationsModule,
        _core_core_module__WEBPACK_IMPORTED_MODULE_0__.CoreModule.forRoot(),
        _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule,
        _settings_settings_module__WEBPACK_IMPORTED_MODULE_2__.SettingsModule,
        _widgets_widgets_module__WEBPACK_IMPORTED_MODULE_4__.WidgetsModule,
        _app_location__WEBPACK_IMPORTED_MODULE_3__.AppLocationModule,
        _clr_angular__WEBPACK_IMPORTED_MODULE_11__.ClarityModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵsetNgModuleScope"](AppModule, { declarations: [_app_component__WEBPACK_IMPORTED_MODULE_6__.AppComponent,
        _home_home_component__WEBPACK_IMPORTED_MODULE_7__.HomeComponent], imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_9__.BrowserModule,
        _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_10__.BrowserAnimationsModule, _core_core_module__WEBPACK_IMPORTED_MODULE_0__.CoreModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule,
        _settings_settings_module__WEBPACK_IMPORTED_MODULE_2__.SettingsModule,
        _widgets_widgets_module__WEBPACK_IMPORTED_MODULE_4__.WidgetsModule,
        _app_location__WEBPACK_IMPORTED_MODULE_3__.AppLocationModule,
        _clr_angular__WEBPACK_IMPORTED_MODULE_11__.ClarityModule] }); })();


/***/ }),

/***/ 39698:
/*!***************************!*\
  !*** ./src/app/config.ts ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DATA_SOURCES": () => (/* binding */ DATA_SOURCES),
/* harmony export */   "environment": () => (/* reexport safe */ app_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment),
/* harmony export */   "initialSandboxPreset": () => (/* binding */ initialSandboxPreset)
/* harmony export */ });
/* harmony import */ var app_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/../environments/environment */ 92340);

const DATA_SOURCES = {
    'DEFAULT': {
        'endpoint': 'http://srv-s2d16-22-01.cms:9200'
    },
    'main_daq_monitoring': {
        'endpoint': 'http://srv-s2d16-22-01.cms:9200'
    },
    'analysis_store': {
        'endpoint': 'http://srv-s2d16-25-01.cms:9200'
    }
};
const initialSandboxPreset = {
    widgets: [{
            type: 'static-label',
            config: {
                container: {
                    width: 100
                },
                widget: {
                    pretext: undefined,
                    maintext: 'SANDBOX',
                    posttext: 'Sandbox is for importing custom dashboard presets. Go to "Settings" -> "Preset import"'
                }
            }
        }]
};


/***/ }),

/***/ 40294:
/*!*************************************!*\
  !*** ./src/app/core/core.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CoreModule": () => (/* binding */ CoreModule)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @clr/angular */ 4151);
/* harmony import */ var ng2_dragula__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ng2-dragula */ 48370);
/* harmony import */ var ngx_popperjs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ngx-popperjs */ 44038);
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../shared/shared.module */ 44466);
/* harmony import */ var _dynamic_widget_dynamic_widget_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dynamic-widget/dynamic-widget.service */ 32935);
/* harmony import */ var _database_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./database.service */ 67084);
/* harmony import */ var _timers_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./timers.service */ 75805);
/* harmony import */ var _event_bus_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./event-bus.service */ 40699);
/* harmony import */ var _sandbox_preset_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./sandbox-preset.service */ 44739);
/* harmony import */ var _dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./dashboard/dashboard.component */ 50256);
/* harmony import */ var _dynamic_widget_dynamic_widget_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./dynamic-widget/dynamic-widget.component */ 30124);
/* harmony import */ var _dashboard_dashboard_container_resize_form_dashboard_container_resize_form_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./dashboard/dashboard-container-resize-form/dashboard-container-resize-form.component */ 41648);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 22560);


















class CoreModule {
    constructor(parentModule) {
        if (parentModule) {
            throw new Error('Tried loading CoreModule more than once.');
        }
    }
    static forRoot() {
        return {
            ngModule: CoreModule,
            providers: []
        };
    }
}
CoreModule.ɵfac = function CoreModule_Factory(t) { return new (t || CoreModule)(_angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵinject"](CoreModule, 12)); };
CoreModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineNgModule"]({ type: CoreModule });
CoreModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineInjector"]({ providers: [
        _dynamic_widget_dynamic_widget_service__WEBPACK_IMPORTED_MODULE_1__.DynamicWidgetService,
        _database_service__WEBPACK_IMPORTED_MODULE_2__.DatabaseService,
        _timers_service__WEBPACK_IMPORTED_MODULE_3__.TimersService,
        _event_bus_service__WEBPACK_IMPORTED_MODULE_4__.EventBusService,
        _sandbox_preset_service__WEBPACK_IMPORTED_MODULE_5__.SandboxPresetService
    ], imports: [_angular_common_http__WEBPACK_IMPORTED_MODULE_10__.HttpClientModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormsModule,
        _clr_angular__WEBPACK_IMPORTED_MODULE_12__.ClarityModule,
        ng2_dragula__WEBPACK_IMPORTED_MODULE_13__.DragulaModule.forRoot(),
        _shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule,
        ngx_popperjs__WEBPACK_IMPORTED_MODULE_14__.NgxPopperjsModule.forRoot({
            disableAnimation: true,
            disableDefaultStyling: true,
            positionFixed: true,
            hideOnClickOutside: true
        })] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵsetNgModuleScope"](CoreModule, { declarations: [_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_6__.DashboardComponent,
        _dynamic_widget_dynamic_widget_component__WEBPACK_IMPORTED_MODULE_7__.DynamicWidgetComponent,
        _dashboard_dashboard_container_resize_form_dashboard_container_resize_form_component__WEBPACK_IMPORTED_MODULE_8__.DashboardContainerResizeFormComponent], imports: [_angular_common_http__WEBPACK_IMPORTED_MODULE_10__.HttpClientModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_11__.FormsModule,
        _clr_angular__WEBPACK_IMPORTED_MODULE_12__.ClarityModule, ng2_dragula__WEBPACK_IMPORTED_MODULE_13__.DragulaModule, _shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule, ngx_popperjs__WEBPACK_IMPORTED_MODULE_14__.NgxPopperjsModule], exports: [_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_6__.DashboardComponent] }); })();


/***/ }),

/***/ 41648:
/*!*************************************************************************************************************!*\
  !*** ./src/app/core/dashboard/dashboard-container-resize-form/dashboard-container-resize-form.component.ts ***!
  \*************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DashboardContainerResizeFormComponent": () => (/* binding */ DashboardContainerResizeFormComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 71989);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 68951);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @clr/angular */ 4151);






class DashboardContainerResizeFormComponent {
    constructor() {
        this.ngDestroy$ = new rxjs__WEBPACK_IMPORTED_MODULE_0__.Subject();
        this.resize$ = new rxjs__WEBPACK_IMPORTED_MODULE_0__.Subject();
        this.dimensionsChange = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    }
    ngOnInit() {
        this.resize$
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.debounceTime)(1000))
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.takeUntil)(this.ngDestroy$))
            .subscribe(event => {
            if (event.direction === 'height') {
                this.dimensionsChange.emit({
                    width: this.width,
                    height: event.value
                });
            }
            else if (event.direction === 'width') {
                this.dimensionsChange.emit({
                    width: event.value,
                    height: this.height
                });
            }
        });
    }
    ngOnDestroy() {
        this.ngDestroy$.next();
        this.ngDestroy$.complete();
    }
}
DashboardContainerResizeFormComponent.ɵfac = function DashboardContainerResizeFormComponent_Factory(t) { return new (t || DashboardContainerResizeFormComponent)(); };
DashboardContainerResizeFormComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: DashboardContainerResizeFormComponent, selectors: [["dashboard-container-resize-form"]], inputs: { width: "width", height: "height" }, outputs: { dimensionsChange: "dimensionsChange" }, decls: 13, vars: 2, consts: [[1, "compact", "resize-form"], ["type", "number", "name", "inputWidgetWidth", 3, "ngModel", "ngModelChange"], ["type", "number", "name", "inputWidgetHeight", 3, "ngModel", "ngModelChange"]], template: function DashboardContainerResizeFormComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "form", 0)(1, "h4");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2, "Resize");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "div")(4, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](5, "Width (%):");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](6, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "input", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function DashboardContainerResizeFormComponent_Template_input_ngModelChange_7_listener($event) { return ctx.resize$.next({ value: $event, direction: "width" }); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "div")(9, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](10, "Height (px):");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](11, "br");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "input", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function DashboardContainerResizeFormComponent_Template_input_ngModelChange_12_listener($event) { return ctx.resize$.next({ value: $event, direction: "height" }); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.width);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.height);
    } }, dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgModel, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgForm, _clr_angular__WEBPACK_IMPORTED_MODULE_5__.ClrLabel], styles: [".resize-form[_ngcontent-%COMP%] {\r\n    position: relative;\r\n    margin: 6px auto auto auto;\r\n    width: 160px;\r\n    height: 160px;\r\n    padding: 12px;\r\n    color: black;\r\n    background-color: white;\r\n    box-shadow: 0px 6px 12px -3px #000000A0;\r\n}\r\n\r\nform[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\r\n    max-width: 100%\r\n}\r\n\r\nh4[_ngcontent-%COMP%] {\r\n    margin-top: 0px;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRhc2hib2FyZC1jb250YWluZXItcmVzaXplLWZvcm0uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLGtCQUFrQjtJQUNsQiwwQkFBMEI7SUFDMUIsWUFBWTtJQUNaLGFBQWE7SUFDYixhQUFhO0lBQ2IsWUFBWTtJQUNaLHVCQUF1QjtJQUN2Qix1Q0FBdUM7QUFDM0M7O0FBRUE7SUFDSTtBQUNKOztBQUVBO0lBQ0ksZUFBZTtBQUNuQiIsImZpbGUiOiJkYXNoYm9hcmQtY29udGFpbmVyLXJlc2l6ZS1mb3JtLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucmVzaXplLWZvcm0ge1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgbWFyZ2luOiA2cHggYXV0byBhdXRvIGF1dG87XHJcbiAgICB3aWR0aDogMTYwcHg7XHJcbiAgICBoZWlnaHQ6IDE2MHB4O1xyXG4gICAgcGFkZGluZzogMTJweDtcclxuICAgIGNvbG9yOiBibGFjaztcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDZweCAxMnB4IC0zcHggIzAwMDAwMEEwO1xyXG59XHJcblxyXG5mb3JtIGlucHV0IHtcclxuICAgIG1heC13aWR0aDogMTAwJVxyXG59XHJcblxyXG5oNCB7XHJcbiAgICBtYXJnaW4tdG9wOiAwcHg7XHJcbn1cclxuIl19 */"] });


/***/ }),

/***/ 50256:
/*!*******************************************************!*\
  !*** ./src/app/core/dashboard/dashboard.component.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DashboardComponent": () => (/* binding */ DashboardComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 23280);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 71989);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _timers_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../timers.service */ 75805);
/* harmony import */ var app_core_event_bus_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! app/core/event-bus.service */ 40699);
/* harmony import */ var ng2_dragula__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ng2-dragula */ 48370);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @clr/angular */ 4151);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var ngx_popperjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-popperjs */ 44038);
/* harmony import */ var _dynamic_widget_dynamic_widget_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../dynamic-widget/dynamic-widget.component */ 30124);
/* harmony import */ var _dashboard_container_resize_form_dashboard_container_resize_form_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./dashboard-container-resize-form/dashboard-container-resize-form.component */ 41648);











function DashboardComponent_clr_alert_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "clr-alert", 3)(1, "div", 4)(2, "span", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, " No dashboard preset configuration ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("clrAlertClosable", false)("clrAlertType", "alert-danger");
} }
function DashboardComponent_div_2_div_1_Template(rf, ctx) { if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 11)(1, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](2, "clr-icon", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "clr-icon", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("popperOnShown", function DashboardComponent_div_2_div_1_Template_clr_icon_popperOnShown_3_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r6); const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2); return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r5.onResizeFormShow($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
} if (rf & 2) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵreference"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("popper", _r4)("popperPlacement", "right-start")("popperTrigger", "click")("popperHideOnScroll", true)("popperHideOnMouseLeave", true);
} }
function DashboardComponent_div_2_Template(rf, ctx) { if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, DashboardComponent_div_2_div_1_Template, 4, 5, "div", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](2, "wm-dynamic-widget", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](3, "popper-content", null, 9)(5, "dashboard-container-resize-form", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("dimensionsChange", function DashboardComponent_div_2_Template_dashboard_container_resize_form_dimensionsChange_5_listener($event) { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r8); const widget_r2 = restoredCtx.$implicit; const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r7.resizeContainer($event, widget_r2)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
} if (rf & 2) {
    const widget_r2 = ctx.$implicit;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵstyleProp"]("height", widget_r2.config.container.height ? widget_r2.config.container.height + "px" : "")("width", widget_r2.config.container.width + "%");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx_r1.layoutMode);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("type", widget_r2.type)("config", widget_r2.config);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("width", widget_r2.config.container.width)("height", widget_r2.config.container.height);
} }
class DashboardComponent {
    constructor(timers, eventBus, dragulaService) {
        this.timers = timers;
        this.eventBus = eventBus;
        this.dragulaService = dragulaService;
        this.DRAGULA_WIDGETS_GROUP = 'WIDGETS';
        this.resizeForms = new Set();
        this._layoutMode = false;
        this.$onWindowResize = (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.fromEvent)(window, 'resize')
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.debounceTime)(1000))
            .subscribe(() => {
            this.eventBus.emit(0, { type: 'global_reflow', payload: null });
        });
    }
    set config(newConfig) {
        this._config = newConfig;
        this.configChanged();
    }
    get config() {
        return this._config;
    }
    set layoutMode(newMode) {
        this._layoutMode = newMode;
        // Redundant code that did not work with newer TS
        // this.resizeForms.forEach(f => {
        //     f.hide();
        // })
    }
    get layoutMode() {
        return this._layoutMode;
    }
    onEscKeyDown(event) {
        this.layoutMode = false;
    }
    ngOnInit() {
        this.dragulaService.createGroup(this.DRAGULA_WIDGETS_GROUP, {
            invalid: function (el, handle) {
                if (handle.id === 'widget-rearrange-handle') {
                    return false;
                }
                return true;
            }
        });
    }
    configChanged() {
        this.timers.removeAll();
        this.widgets = [];
        if (!this._config) {
            return;
        }
        if (this._config['timers']) {
            for (let interval of this._config['timers']) {
                this.timers.create(interval);
            }
        }
        if (!this._config['widgets']) {
            return;
        }
        for (let widget of this._config['widgets']) {
            this.fixContainerDimensions(widget);
            if (!widget.config.hasOwnProperty('widget')) {
                widget.config['widget'] = {};
            }
            this.widgets.push(widget);
        }
    }
    ngAfterViewInit() { }
    ngOnDestroy() {
        this.$onWindowResize.unsubscribe();
    }
    fixContainerDimensions(widget) {
        const defaultContainer = {
            width: 50,
            height: 360
        };
        if (!this.hasProperty(widget, 'config')) {
            widget['config'] = {};
        }
        if (!this.hasProperty(widget['config'], 'container')) {
            widget['config']['container'] = {};
        }
        widget['config']['container'] = Object.assign(defaultContainer, widget['config']['container']);
        const cont = widget['config']['container'];
        cont['width'] = typeof cont['width'] === 'number' ? cont['width'] : 50;
        cont['height'] = typeof cont['height'] === 'number' ? cont['height'] : NaN;
        cont['width'] = (cont['width'] < 5) ? 5 : cont['width'];
        cont['width'] = cont['width'] > 100 ? 100 : cont['width'];
        cont['height'] = cont['height'] < 40 ? 40 : cont['height'];
    }
    resizeContainer(dimensions, widget) {
        widget['config']['container']['height'] = dimensions.height;
        widget['config']['container']['width'] = dimensions.width;
        this.fixContainerDimensions(widget);
        this.eventBus.emit(0, { type: 'global_reflow', payload: null });
    }
    onResizeFormShow(event) {
        event['popperContent']['popperViewRef']['nativeElement'].style.zIndex = 4;
        this.resizeForms.add(event['popperContent']);
    }
    exportConfig() {
        return {
            timers: this.timers.getTimers().map(t => t.interval),
            widgets: this.widgets
        };
    }
    hasProperty(object, property) {
        return ((typeof object === 'object')
            && (object !== null)
            && object.hasOwnProperty(property));
    }
}
DashboardComponent.ɵfac = function DashboardComponent_Factory(t) { return new (t || DashboardComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_timers_service__WEBPACK_IMPORTED_MODULE_0__.TimersService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](app_core_event_bus_service__WEBPACK_IMPORTED_MODULE_1__.EventBusService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](ng2_dragula__WEBPACK_IMPORTED_MODULE_7__.DragulaService)); };
DashboardComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({ type: DashboardComponent, selectors: [["app-dashboard"]], hostBindings: function DashboardComponent_HostBindings(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("keydown.esc", function DashboardComponent_keydown_esc_HostBindingHandler($event) { return ctx.onEscKeyDown($event); }, false, _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresolveWindow"]);
    } }, inputs: { config: "config" }, decls: 3, vars: 4, consts: [[1, "dashboard-widget-container", 3, "dragula", "dragulaModel", "dragulaModelChange"], [3, "clrAlertClosable", "clrAlertType", 4, "ngIf"], ["class", "dashboard-widget", 3, "height", "width", 4, "ngFor", "ngForOf"], [3, "clrAlertClosable", "clrAlertType"], ["clr-alert-item", "", 1, "alert-item"], [1, "alert-text"], [1, "dashboard-widget"], ["class", "layout-mode-curtain", 4, "ngIf"], [3, "type", "config"], ["resizeForm", ""], [3, "width", "height", "dimensionsChange"], [1, "layout-mode-curtain"], [1, "layout-mode-buttons"], ["id", "widget-rearrange-handle", "shape", "target", "size", "36"], ["shape", "resize", "size", "36", 3, "popper", "popperPlacement", "popperTrigger", "popperHideOnScroll", "popperHideOnMouseLeave", "popperOnShown"]], template: function DashboardComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("dragulaModelChange", function DashboardComponent_Template_div_dragulaModelChange_0_listener($event) { return ctx.widgets = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, DashboardComponent_clr_alert_1_Template, 4, 2, "clr-alert", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](2, DashboardComponent_div_2_Template, 6, 9, "div", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("dragula", ctx.DRAGULA_WIDGETS_GROUP)("dragulaModel", ctx.widgets);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !ctx.config);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx.widgets);
    } }, dependencies: [_clr_angular__WEBPACK_IMPORTED_MODULE_8__.ClrAlert, _clr_angular__WEBPACK_IMPORTED_MODULE_8__.ClrAlertText, _clr_angular__WEBPACK_IMPORTED_MODULE_8__.ClrIconCustomTag, ng2_dragula__WEBPACK_IMPORTED_MODULE_7__.DragulaDirective, _angular_common__WEBPACK_IMPORTED_MODULE_9__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_9__.NgIf, ngx_popperjs__WEBPACK_IMPORTED_MODULE_10__.NgxPopperjsContentComponent, ngx_popperjs__WEBPACK_IMPORTED_MODULE_10__.NgxPopperjsDirective, _dynamic_widget_dynamic_widget_component__WEBPACK_IMPORTED_MODULE_2__.DynamicWidgetComponent, _dashboard_container_resize_form_dashboard_container_resize_form_component__WEBPACK_IMPORTED_MODULE_3__.DashboardContainerResizeFormComponent], styles: [".dashboard-widget[_ngcontent-%COMP%] {\r\n    position: relative;\r\n    flex-basis: initial;\r\n    flex-grow: 0;\r\n    flex-shrink: 0;\r\n    overflow: hidden;\r\n    min-width: 100px;\r\n    padding: 1px;\r\n}\r\n\r\n.dashboard-widget-container[_ngcontent-%COMP%] {\r\n    display: flex;\r\n    flex-wrap: wrap;\r\n    padding-bottom: 50vh;\r\n}\r\n\r\n.layout-mode-curtain[_ngcontent-%COMP%] {\r\n    position: absolute;\r\n    background-color: #00000060;\r\n    border: 4px dashed red;\r\n    height: 100%;\r\n    width: 100%;\r\n    z-index: 20;\r\n}\r\n\r\n.layout-mode-buttons[_ngcontent-%COMP%] {\r\n    position: absolute;\r\n    z-index: 21;\r\n    color: red;\r\n    text-align: center;\r\n}\r\n\r\n#widget-rearrange-handle[_ngcontent-%COMP%] {\r\n    cursor: grab;\r\n}\r\n\r\npopper-content[_ngcontent-%COMP%] {\r\n    position: absolute;\r\n    z-index: 22;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRhc2hib2FyZC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksa0JBQWtCO0lBQ2xCLG1CQUFtQjtJQUNuQixZQUFZO0lBQ1osY0FBYztJQUNkLGdCQUFnQjtJQUNoQixnQkFBZ0I7SUFDaEIsWUFBWTtBQUNoQjs7QUFFQTtJQUNJLGFBQWE7SUFDYixlQUFlO0lBQ2Ysb0JBQW9CO0FBQ3hCOztBQUVBO0lBQ0ksa0JBQWtCO0lBQ2xCLDJCQUEyQjtJQUMzQixzQkFBc0I7SUFDdEIsWUFBWTtJQUNaLFdBQVc7SUFDWCxXQUFXO0FBQ2Y7O0FBRUE7SUFDSSxrQkFBa0I7SUFDbEIsV0FBVztJQUNYLFVBQVU7SUFDVixrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxZQUFZO0FBQ2hCOztBQUVBO0lBQ0ksa0JBQWtCO0lBQ2xCLFdBQVc7QUFDZiIsImZpbGUiOiJkYXNoYm9hcmQuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5kYXNoYm9hcmQtd2lkZ2V0IHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGZsZXgtYmFzaXM6IGluaXRpYWw7XHJcbiAgICBmbGV4LWdyb3c6IDA7XHJcbiAgICBmbGV4LXNocmluazogMDtcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICBtaW4td2lkdGg6IDEwMHB4O1xyXG4gICAgcGFkZGluZzogMXB4O1xyXG59XHJcblxyXG4uZGFzaGJvYXJkLXdpZGdldC1jb250YWluZXIge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtd3JhcDogd3JhcDtcclxuICAgIHBhZGRpbmctYm90dG9tOiA1MHZoO1xyXG59XHJcblxyXG4ubGF5b3V0LW1vZGUtY3VydGFpbiB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDAwMDAwNjA7XHJcbiAgICBib3JkZXI6IDRweCBkYXNoZWQgcmVkO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICB6LWluZGV4OiAyMDtcclxufVxyXG5cclxuLmxheW91dC1tb2RlLWJ1dHRvbnMge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgei1pbmRleDogMjE7XHJcbiAgICBjb2xvcjogcmVkO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4jd2lkZ2V0LXJlYXJyYW5nZS1oYW5kbGUge1xyXG4gICAgY3Vyc29yOiBncmFiO1xyXG59XHJcblxyXG5wb3BwZXItY29udGVudCB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB6LWluZGV4OiAyMjtcclxufVxyXG4iXX0= */"] });


/***/ }),

/***/ 67084:
/*!******************************************!*\
  !*** ./src/app/core/database.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DatabaseService": () => (/* binding */ DatabaseService)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var app_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/config */ 39698);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 25474);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);





class DatabaseService {
    constructor(http) {
        this.http = http;
        this.defaultDB = app_config__WEBPACK_IMPORTED_MODULE_0__.DATA_SOURCES.DEFAULT.endpoint;
    }
    parseDatabase(selector) {
        if (selector.startsWith('http')) {
            return selector;
        }
        if (app_config__WEBPACK_IMPORTED_MODULE_0__.DATA_SOURCES.hasOwnProperty(selector)) {
            return app_config__WEBPACK_IMPORTED_MODULE_0__.DATA_SOURCES[selector]['endpoint'];
        }
        if (selector.toLowerCase() === 'default') {
            return this.defaultDB;
        }
        return null;
    }
    query(url, body = {}, db = this.defaultDB) {
        const dbUrl = this.parseDatabase(db);
        if (!dbUrl) {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.throwError)(new Error('Wrong DB: ' + db));
        }
        return this.http.post(dbUrl + '/' + url, body);
    }
    queryNDJson(url, body = '', db = this.defaultDB) {
        const headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpHeaders({ 'Content-Type': 'application/x-ndjson' });
        const dbUrl = this.parseDatabase(db);
        if (!dbUrl) {
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.throwError)(new Error('Wrong DB: ' + db));
        }
        return this.http.post(dbUrl + '/' + url, body, { headers: headers });
    }
    multiSearch(body, db = this.defaultDB) {
        return this.queryNDJson('_msearch', body, db);
    }
    stringifyToNDJSON(values) {
        let result = '';
        values.forEach(v => {
            result += JSON.stringify(v) + '\n';
        });
        return result;
    }
    transformQueryWithNestedPath(query, nestedPath) {
        if (!nestedPath) {
            return query;
        }
        if (query.hasOwnProperty('aggs') || query.hasOwnProperty('aggregations')) {
            throw ('Automatic nested path transform not supported for aggregations');
        }
        if (query.hasOwnProperty('_source')) {
            query['_source'] = query['_source'].map(v => nestedPath + '.' + v);
        }
        if (query.hasOwnProperty('sort')) {
            const transformSortLevel = (singleSortLevel) => {
                const transformed = {};
                Object.keys(singleSortLevel).forEach(k => {
                    if (typeof singleSortLevel[k] === 'string') {
                        singleSortLevel[k] = {
                            'nested_path': nestedPath,
                            'order': singleSortLevel[k]
                        };
                    }
                    else {
                        singleSortLevel[k]['nested_path'] = nestedPath;
                    }
                    transformed[nestedPath + '.' + k] = singleSortLevel[k];
                });
                return transformed;
            };
            if (Array.isArray(query['sort'])) {
                query['sort'] = query['sort'].map(transformSortLevel);
            }
            else {
                query['sort'] = transformSortLevel(query['sort']);
            }
        }
        if (query.hasOwnProperty('query')) {
            const q = query['query'];
            const filters = q['bool']['filter'];
            const newFilters = filters.map(f => {
                const filterName = Object.keys(f)[0];
                const fieldName = Object.keys(f[filterName])[0];
                const newFilter = {};
                newFilter[filterName] = {};
                newFilter[filterName][nestedPath + '.' + fieldName] = f[filterName][fieldName];
                return newFilter;
            });
            q['bool']['filter'] = newFilters;
            query['query'] = { nested: { path: nestedPath, query: q } };
        }
        return query;
    }
}
DatabaseService.ɵfac = function DatabaseService_Factory(t) { return new (t || DatabaseService)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_2__.HttpClient)); };
DatabaseService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({ token: DatabaseService, factory: DatabaseService.ɵfac });


/***/ }),

/***/ 30124:
/*!*****************************************************************!*\
  !*** ./src/app/core/dynamic-widget/dynamic-widget.component.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DynamicWidgetComponent": () => (/* binding */ DynamicWidgetComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _dynamic_widget_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dynamic-widget.service */ 32935);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 94666);




const _c0 = ["content"];
function DynamicWidgetComponent_ng_template_0_Template(rf, ctx) { }
function DynamicWidgetComponent_div_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "div", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", ctx_r2.message, "\n");
} }
class DynamicWidgetComponent {
    constructor(dynamicWidgets) {
        this.dynamicWidgets = dynamicWidgets;
        this.loaded = false;
        this.message = '';
    }
    ngOnInit() {
        this.load();
    }
    load() {
        this.dynamicWidgets.loadWidget(this.widgetType, this.content, this.config)
            .then(loaded => this.loaded = loaded, err => {
            this.message = err;
            this.content.remove();
        });
    }
}
DynamicWidgetComponent.ɵfac = function DynamicWidgetComponent_Factory(t) { return new (t || DynamicWidgetComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_dynamic_widget_service__WEBPACK_IMPORTED_MODULE_0__.DynamicWidgetService)); };
DynamicWidgetComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: DynamicWidgetComponent, selectors: [["wm-dynamic-widget"]], viewQuery: function DynamicWidgetComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵviewQuery"](_c0, 7, _angular_core__WEBPACK_IMPORTED_MODULE_1__.ViewContainerRef);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵloadQuery"]()) && (ctx.content = _t.first);
    } }, inputs: { widgetType: ["type", "widgetType"], config: "config" }, decls: 3, vars: 1, consts: [["content", ""], ["id", "message", 4, "ngIf"], ["id", "message"], [1, "loading"]], template: function DynamicWidgetComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](0, DynamicWidgetComponent_ng_template_0_Template, 0, 0, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, DynamicWidgetComponent_div_2_Template, 3, 1, "div", 1);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", !ctx.loaded);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgIf], styles: ["#message[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n}\r\n\r\n.loading[_ngcontent-%COMP%] {\r\n    position: relative;\r\n    min-height: 100px;\r\n}\r\n\r\n.loading[_ngcontent-%COMP%]:after {\r\n    content: 'Loading...';\r\n    position: absolute;\r\n    top: 50%;\r\n    left: 50%;\r\n    transform: translate(-50%, -50%);\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImR5bmFtaWMtd2lkZ2V0LmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxrQkFBa0I7QUFDdEI7O0FBRUE7SUFDSSxrQkFBa0I7SUFDbEIsaUJBQWlCO0FBQ3JCOztBQUVBO0lBQ0kscUJBQXFCO0lBQ3JCLGtCQUFrQjtJQUNsQixRQUFRO0lBQ1IsU0FBUztJQUNULGdDQUFnQztBQUNwQyIsImZpbGUiOiJkeW5hbWljLXdpZGdldC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiI21lc3NhZ2Uge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4ubG9hZGluZyB7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBtaW4taGVpZ2h0OiAxMDBweDtcclxufVxyXG5cclxuLmxvYWRpbmc6YWZ0ZXIge1xyXG4gICAgY29udGVudDogJ0xvYWRpbmcuLi4nO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiA1MCU7XHJcbiAgICBsZWZ0OiA1MCU7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcclxufVxyXG4iXX0= */"] });


/***/ }),

/***/ 32935:
/*!***************************************************************!*\
  !*** ./src/app/core/dynamic-widget/dynamic-widget.service.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DynamicWidgetService": () => (/* binding */ DynamicWidgetService)
/* harmony export */ });
/* harmony import */ var C_Users_kariofillis_webmonitor_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 71670);
/* harmony import */ var app_widgets_widget_module_selector__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! app/widgets/widget-module-selector */ 36214);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);




class DynamicWidgetService {
  constructor(compiler, injector) {
    this.compiler = compiler;
    this.injector = injector; // Contains the already registered modules

    this.registeredModules = {}; // Get the widgets that are supported for quickly checking availability

    this.availableWidgets = Object.keys(app_widgets_widget_module_selector__WEBPACK_IMPORTED_MODULE_1__.widgetModuleSelector);
  } // Registers a module, saving its NgModuleRef and entryComponent in order to
  // avoid multiple compilations of the same module.


  registerModule(widget, mod, comp) {
    if (this.getModule(widget)) {
      throw new Error('Module already registered ' + widget);
    }

    this.registeredModules[widget] = {
      "ref": mod,
      "entry": comp
    };
  } // Returns the module or undefined if the module is not yet registered


  getModule(widget) {
    return this.registeredModules[widget];
  } // Return a loaded module based on string input


  selectWidget(widget) {
    return (0,C_Users_kariofillis_webmonitor_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      switch (widget) {
        case 'static-label':
          return yield __webpack_require__.e(/*! import() */ "src_app_widgets_static-label-widget_static-label-widget_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! app/widgets/static-label-widget/static-label-widget.module */ 46416)).then(m => m.StaticLabelWidgetModule);

        case 'label':
          return yield __webpack_require__.e(/*! import() */ "src_app_widgets_label-widget_label-widget_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! app/widgets/label-widget/label-widget.module */ 4359)).then(m => m.LabelWidgetModule);

        case 'time-query':
          return yield __webpack_require__.e(/*! import() */ "src_app_widgets_time-query-widget_time-query-widget_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! app/widgets/time-query-widget/time-query-widget.module */ 11750)).then(m => m.TimeQueryWidgetModule);

        case 'range-query':
          return yield __webpack_require__.e(/*! import() */ "src_app_widgets_range-query_range-query_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! app/widgets/range-query/range-query.module */ 26645)).then(m => m.RangeQueryModule);

        case 'fill-run-ls-query':
          return yield __webpack_require__.e(/*! import() */ "src_app_widgets_fill-run-ls-query-widget_fill-run-ls-query-widget_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! app/widgets/fill-run-ls-query-widget/fill-run-ls-query-widget.module */ 73059)).then(m => m.FillRunLsQueryWidgetModule);

        case 'event-bus-tester':
          return yield __webpack_require__.e(/*! import() */ "src_app_widgets_event-bus-test-widget_event-bus-test-widget_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! app/widgets/event-bus-test-widget/event-bus-test-widget.module */ 4794)).then(m => m.EventBusTestWidgetModule);

        case 'numeric-field':
          return yield Promise.all(/*! import() */[__webpack_require__.e("default-src_app_widgets_base_chart-widget_ts"), __webpack_require__.e("default-src_app_widgets_numeric-field_numeric-field_component_ts"), __webpack_require__.e("src_app_widgets_numeric-field_numeric-field_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! app/widgets/numeric-field/numeric-field.module */ 6778)).then(m => m.NumericFieldModule);

        case 'array-snapshot':
          return yield Promise.all(/*! import() */[__webpack_require__.e("default-src_app_widgets_base_chart-widget_ts"), __webpack_require__.e("default-src_app_widgets_array-snapshot_array-snapshot_component_ts"), __webpack_require__.e("src_app_widgets_array-snapshot_array-snapshot_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! app/widgets/array-snapshot/array-snapshot.module */ 27029)).then(m => m.ArraySnapshotModule);

        case 'array-lines':
          return yield Promise.all(/*! import() */[__webpack_require__.e("default-src_app_widgets_base_chart-widget_ts"), __webpack_require__.e("default-src_app_widgets_array-field_data_service_ts"), __webpack_require__.e("default-src_app_widgets_array-field_array-lines_component_ts"), __webpack_require__.e("src_app_widgets_array-field_array-lines_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! app/widgets/array-field/array-lines.module */ 35814)).then(m => m.ArrayLinesModule);

        case 'array-lines-basicx':
          return yield Promise.all(/*! import() */[__webpack_require__.e("default-src_app_widgets_base_chart-widget_ts"), __webpack_require__.e("default-src_app_widgets_array-field_data_service_ts"), __webpack_require__.e("default-src_app_widgets_array-field_array-lines_component_ts"), __webpack_require__.e("src_app_widgets_array-field_array-lines-basicx_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! app/widgets/array-field/array-lines-basicx.module */ 67838)).then(m => m.ArrayLinesBasicXModule);

        case 'array-heatmap':
          return yield Promise.all(/*! import() */[__webpack_require__.e("default-src_app_widgets_base_chart-widget_ts"), __webpack_require__.e("default-src_app_widgets_array-field_data_service_ts"), __webpack_require__.e("src_app_widgets_array-field_array-heatmap_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! app/widgets/array-field/array-heatmap.module */ 72585)).then(m => m.ArrayHeatmapModule);

        case 'numeric-field-with-ratios':
          return yield Promise.all(/*! import() */[__webpack_require__.e("default-src_app_widgets_base_chart-widget_ts"), __webpack_require__.e("default-src_app_widgets_numeric-field_numeric-field_component_ts"), __webpack_require__.e("src_app_widgets_numeric-field-with-ratios_numeric-field-with-ratios_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! app/widgets/numeric-field-with-ratios/numeric-field-with-ratios.module */ 14119)).then(m => m.NumericFieldWithRatiosModule);

        case 'pileup':
          return yield Promise.all(/*! import() */[__webpack_require__.e("default-src_app_widgets_base_chart-widget_ts"), __webpack_require__.e("default-src_app_widgets_array-snapshot_array-snapshot_component_ts"), __webpack_require__.e("src_app_widgets_pileup_pileup_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! app/widgets/pileup/pileup.module */ 19008)).then(m => m.PileupModule);

        case 'images':
          return yield __webpack_require__.e(/*! import() */ "src_app_widgets_binary-images_binary-images_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! app/widgets/binary-images/binary-images.module */ 85892)).then(m => m.BinaryImagesModule);

        case 'dynamic-form-test':
          return yield __webpack_require__.e(/*! import() */ "src_app_widgets_dynamic-form-test_dynamic-form-test_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! app/widgets/dynamic-form-test/dynamic-form-test.module */ 69890)).then(m => m.DynamicFormTestModule);

        case 'numeric-field-split':
          return yield Promise.all(/*! import() */[__webpack_require__.e("default-src_app_widgets_base_chart-widget_ts"), __webpack_require__.e("default-src_app_widgets_numeric-field_numeric-field_component_ts"), __webpack_require__.e("src_app_widgets_numeric-field-split_numeric-field-split_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! app/widgets/numeric-field-split/numeric-field-split.module */ 2300)).then(m => m.NumericFieldSplitModule);

        case 'vdm-bx':
          return yield Promise.all(/*! import() */[__webpack_require__.e("default-src_app_widgets_base_chart-widget_ts"), __webpack_require__.e("default-src_app_widgets_array-snapshot_array-snapshot_component_ts"), __webpack_require__.e("src_app_widgets_vdm-bx_vdm-bx_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! app/widgets/vdm-bx/vdm-bx.module */ 25598)).then(m => m.VDMBXModule);

        case 'string-plus-date-query':
          return yield __webpack_require__.e(/*! import() */ "src_app_widgets_string-plus-date-query_string-plus-date-query_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! app/widgets/string-plus-date-query/string-plus-date-query.module */ 3248)).then(m => m.StringPlusDateQueryModule);

        default:
          console.error("You need to add a switch case for the new widget you implemented: " + widget);
          return Promise.reject("You need to add a switch case for the new widget you implemented: " + widget);
      }
    })();
  } // Compiles module if it is not already registered and instantiates components


  loadWidget(widget, container, config) {
    if (!this.availableWidgets.includes(widget)) {
      console.error('No such widget declared: ', widget);
      return Promise.reject('No such widget: ' + widget);
    } else {
      return this.selectWidget(widget).then(moduleCode => {
        let moduleObject = this.getModule(widget);

        if (!moduleObject) {
          // if the module is not registered
          let moduleFactory = this.compiler.compileModuleSync(moduleCode);
          let ngModuleRef = moduleFactory.create(container.injector);
          let entryComponent = moduleFactory.moduleType["entry"];
          this.registerModule(widget, ngModuleRef, entryComponent);
          let componentFactory = ngModuleRef.componentFactoryResolver.resolveComponentFactory(entryComponent);
          let componentRef = container.createComponent(componentFactory);
          componentRef.instance['config'] = config;
          componentRef.changeDetectorRef.detectChanges();
          componentRef.onDestroy(() => {
            componentRef.changeDetectorRef.detach();
          });
        } else {
          // if the module is already registered
          let ngModuleRef = moduleObject.ref;
          let entryComponent = moduleObject.entry;
          let componentFactory = ngModuleRef.componentFactoryResolver.resolveComponentFactory(entryComponent);
          let componentRef = container.createComponent(componentFactory);
          componentRef.instance['config'] = config;
          componentRef.changeDetectorRef.detectChanges();
          componentRef.onDestroy(() => {
            componentRef.changeDetectorRef.detach();
          });
        }

        return true;
      });
    }
  }

}

DynamicWidgetService.ɵfac = function DynamicWidgetService_Factory(t) {
  return new (t || DynamicWidgetService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_core__WEBPACK_IMPORTED_MODULE_2__.Compiler), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injector));
};

DynamicWidgetService.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
  token: DynamicWidgetService,
  factory: DynamicWidgetService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ 40699:
/*!*******************************************!*\
  !*** ./src/app/core/event-bus.service.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Event": () => (/* binding */ Event),
/* harmony export */   "EventBusService": () => (/* binding */ EventBusService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ 60116);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);



class Event {
    constructor(type, payload) {
        this.type = type;
        this.payload = payload;
    }
}
class ChanneledEvent {
    constructor(channel, event) {
        this.channel = channel;
        this.event = event;
    }
}
class EventBusService {
    constructor() {
        this.events$ = new rxjs__WEBPACK_IMPORTED_MODULE_0__.Subject();
    }
    getEvents(channel, _filter) {
        let filtered = this.events$
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.filter)(x => x.channel === channel));
        if (_filter) {
            filtered = filtered.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.filter)(x => x.event.type === _filter));
        }
        return filtered.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(x => x.event));
    }
    emit(channel, event) {
        if (!Number.isInteger(channel)) {
            return;
        }
        this.events$.next({ channel: channel, event: event });
    }
    reset() {
        this.events$.complete();
        this.events$ = new rxjs__WEBPACK_IMPORTED_MODULE_0__.Subject();
    }
}
EventBusService.ɵfac = function EventBusService_Factory(t) { return new (t || EventBusService)(); };
EventBusService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({ token: EventBusService, factory: EventBusService.ɵfac });


/***/ }),

/***/ 44739:
/*!************************************************!*\
  !*** ./src/app/core/sandbox-preset.service.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SandboxPresetService": () => (/* binding */ SandboxPresetService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 76317);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);


class SandboxPresetService {
    constructor() {
        this.config$ = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject({});
        this.configStr = '{}';
    }
    getConfig() {
        return JSON.parse(this.configStr);
    }
    setConfig(newConfig) {
        this.configStr = JSON.stringify(newConfig);
        this.config$.next(this.getConfig());
    }
}
SandboxPresetService.ɵfac = function SandboxPresetService_Factory(t) { return new (t || SandboxPresetService)(); };
SandboxPresetService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: SandboxPresetService, factory: SandboxPresetService.ɵfac });


/***/ }),

/***/ 75805:
/*!****************************************!*\
  !*** ./src/app/core/timers.service.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TimersService": () => (/* binding */ TimersService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 28653);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 76317);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 81203);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);



class SubjectTimer {
    constructor(seconds) {
        this.interval = seconds = Number(seconds);
        this.intervalSubject$ = new rxjs__WEBPACK_IMPORTED_MODULE_0__.Subject();
        const interval$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.interval)(seconds * 1000);
        this.subscription = interval$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.share)()).subscribe(this.intervalSubject$);
    }
    subscribe(onNext, onError, onComplete) {
        return this.intervalSubject$.subscribe(onNext, onError, onComplete);
    }
    getObserverCount() {
        return this.intervalSubject$.observers.length;
    }
    cleanup() {
        this.intervalSubject$.complete();
        this.subscription.unsubscribe();
    }
}
class TimersService {
    constructor() {
        this.timers = [];
        this.timers$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__.BehaviorSubject([]);
    }
    getTimers() {
        return this.timers.slice(); // shallow copy
    }
    create(seconds) {
        const timer = new SubjectTimer(seconds);
        this.timers.push(timer);
        this.timers$.next(this.getTimers());
        return timer;
    }
    remove(timer) {
        const index = this.timers.indexOf(timer);
        if (index >= 0) {
            this.timers.splice(index, 1)[0].cleanup();
        }
        this.timers$.next(this.getTimers());
    }
    removeAll() {
        while (this.timers.length > 0) {
            this.timers.splice(0, 1)[0].cleanup();
        }
        this.timers$.next(this.getTimers());
    }
}
TimersService.ɵfac = function TimersService_Factory(t) { return new (t || TimersService)(); };
TimersService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjectable"]({ token: TimersService, factory: TimersService.ɵfac });


/***/ }),

/***/ 45067:
/*!****************************************!*\
  !*** ./src/app/home/home.component.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeComponent": () => (/* binding */ HomeComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);

class HomeComponent {
    constructor() { }
    ngOnInit() {
    }
}
HomeComponent.ɵfac = function HomeComponent_Factory(t) { return new (t || HomeComponent)(); };
HomeComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: HomeComponent, selectors: [["app-home"]], decls: 4, vars: 0, template: function HomeComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "h1");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1, "BRIL DAQ monitoring application");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3, "Select preset");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } }, styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJob21lLmNvbXBvbmVudC5jc3MifQ== */"] });


/***/ }),

/***/ 15912:
/*!*******************************************!*\
  !*** ./src/app/preset-resolve.service.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PresetResolveService": () => (/* binding */ PresetResolveService)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 58987);


class PresetResolveService {
    constructor(http) {
        this.http = http;
    }
    resolve(path) {
        return this.http.get(path);
    }
}
PresetResolveService.ɵfac = function PresetResolveService_Factory(t) { return new (t || PresetResolveService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient)); };
PresetResolveService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: PresetResolveService, factory: PresetResolveService.ɵfac });


/***/ }),

/***/ 33238:
/*!**********************************!*\
  !*** ./src/app/preset-routes.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PresetRoute": () => (/* binding */ PresetRoute),
/* harmony export */   "ROUTES": () => (/* binding */ ROUTES),
/* harmony export */   "SANDBOX_PATH": () => (/* binding */ SANDBOX_PATH)
/* harmony export */ });
const SANDBOX_PATH = '/--sandbox';
class PresetRoute {
}
const ROUTES = [{
        title: 'Summary',
        path: '/summary',
        config_url: 'assets/presets/summary.json'
    }, {
        title: 'Luminosity',
        path: '/lumi',
        config_url: 'assets/presets/lumi.json'
    }, {
        title: 'Per bunch luminosity',
        path: '/bxlumi',
        config_url: 'assets/presets/bxlumi.json'
    }, {
        title: 'Pileup',
        path: '/pileup',
        config_url: 'assets/presets/pileup.json'
    }, {
        title: 'BPTX',
        path: '/bptx',
        config_url: 'assets/presets/bptx.json'
    }, {
        title: 'BCML',
        path: '/bcml',
        config_url: 'assets/presets/bcml.json'
    }, {
        title: 'BCML Prototype',
        path: '/bcml_prototype',
        config_url: 'assets/presets/bcml_prototype.json'
    }, {
        path: '/bcml90',
        config_url: 'assets/presets/bcml.json'
    }, {
        title: 'BCM1FUTCA',
        path: '/bcm1futca',
        config_url: 'assets/presets/bcm1futca.json'
    }, {
        title: 'BCM1FUTCA RATES',
        path: '/bcm1futca_rates',
        config_url: 'assets/presets/bcm1futca_rates.json'
    }, {
        title: 'BCM1F VME',
        path: '/bcm1fvme',
        config_url: 'assets/presets/bcm1fvme.json'
    }, {
        title: 'BCM1F VME Rates',
        path: '/bcm1frhu',
        config_url: 'assets/presets/bcm1frhu.json'
    }, {
        title: 'BCM1F VME ADC',
        path: '/bcm1fadc',
        config_url: 'assets/presets/bcm1fadc.json'
    }, {
        title: 'Background',
        path: '/background',
        config_url: 'assets/presets/background.json'
    }, {
        title: 'HF',
        path: '/hf',
        config_url: 'assets/presets/hf.json'
    }, {
        title: 'PLT',
        path: '/plt',
        config_url: 'assets/presets/plt.json'
    }, {
        title: 'PLT offline',
        path: '/plt-offline',
        config_url: 'assets/presets/plt_offline.json'
    }, {
        title: 'PLTSLINK',
        path: '/pltslink',
        config_url: 'assets/presets/pltslink.json'
    }, {
        title: 'VDM online',
        path: '/vdm-online',
        config_url: 'assets/presets/vdm-online.json'
    }, {
        title: 'VDM offline',
        path: '/vdm-offline',
        config_url: 'assets/presets/vdm-offline.json'
    }, {
        title: 'VDM offline PLT',
        path: '/vdm-offline-plt',
        config_url: 'assets/presets/vdm-offline-plt.json'
    }, {
        title: 'VDM offline BCM1FUTCA',
        path: '/vdm-offline-bcm1futca',
        config_url: 'assets/presets/vdm-offline-bcm1futca.json'
    }, {
        title: 'REMUS',
        path: '/remus',
        config_url: 'assets/presets/remus.json'
    }, {
        path: '/bril-hosts',
        config_url: 'assets/presets/bril-hosts.json'
    }, {
        path: '/test',
        config_url: 'assets/presets/test.json'
    }];


/***/ }),

/***/ 38169:
/*!*********************************************************************!*\
  !*** ./src/app/settings/settings-modal/settings-modal.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SettingsModalComponent": () => (/* binding */ SettingsModalComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _settings_timers_timers_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../settings/timers/timers.component */ 31863);
/* harmony import */ var _settings_preset_export_preset_export_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../settings/preset-export/preset-export.component */ 57488);
/* harmony import */ var _settings_preset_import_preset_import_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../settings/preset-import/preset-import.component */ 14180);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @clr/angular */ 4151);







const _c0 = ["modal"];
const _c1 = ["settingsOutlet"];
function SettingsModalComponent_ng_template_7_Template(rf, ctx) { }
function SettingsModalComponent_a_10_Template(rf, ctx) { if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "a", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function SettingsModalComponent_a_10_Template_a_click_0_listener() { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r6); const s_r4 = restoredCtx.$implicit; const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r5.selectView(s_r4)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
} if (rf & 2) {
    const s_r4 = ctx.$implicit;
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassProp"]("active", s_r4 === ctx_r3.activeSetting);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", s_r4.label, " ");
} }
const settingsViews = [{
        label: 'Timers',
        component: _settings_timers_timers_component__WEBPACK_IMPORTED_MODULE_0__.TimersComponent
    }, {
        label: 'Preset export',
        component: _settings_preset_export_preset_export_component__WEBPACK_IMPORTED_MODULE_1__.PresetExportComponent
    }, {
        label: 'Preset import',
        component: _settings_preset_import_preset_import_component__WEBPACK_IMPORTED_MODULE_2__.PresetImportComponent
    }];
class SettingsModalComponent {
    constructor(resolver) {
        this.resolver = resolver;
        this.settings = settingsViews;
        this.activeSetting = null;
    }
    ngOnInit() {
    }
    open() {
        this.modal.open();
    }
    selectView(view) {
        this.showComponent(view.component);
        this.activeSetting = view;
    }
    showComponent(cmp) {
        this.container.clear();
        const factory = this.resolver.resolveComponentFactory(cmp);
        this.componentRef = this.container.createComponent(factory);
        this.componentRef.instance['dashboard'] = this.dashboard;
    }
    ngOnDestroy() {
        this.componentRef.destroy();
    }
}
SettingsModalComponent.ɵfac = function SettingsModalComponent_Factory(t) { return new (t || SettingsModalComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_3__.ComponentFactoryResolver)); };
SettingsModalComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({ type: SettingsModalComponent, selectors: [["app-settings-modal"]], viewQuery: function SettingsModalComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵviewQuery"](_c0, 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵviewQuery"](_c1, 7, _angular_core__WEBPACK_IMPORTED_MODULE_3__.ViewContainerRef);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.modal = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.container = _t.first);
    } }, inputs: { dashboard: "dashboard" }, decls: 11, vars: 2, consts: [[3, "clrModalSize"], ["modal", ""], [1, "modal-title"], [1, "modal-body", "main-container"], [1, "content-container"], [1, "content-area"], ["settingsOutlet", ""], ["clrVerticalNavLink", "", 3, "active", "click", 4, "ngFor", "ngForOf"], ["clrVerticalNavLink", "", 3, "click"]], template: function SettingsModalComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "clr-modal", 0, 1)(2, "h3", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3, "Settings");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "div", 3)(5, "div", 4)(6, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](7, SettingsModalComponent_ng_template_7_Template, 0, 0, "ng-template", null, 6, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "clr-vertical-nav");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](10, SettingsModalComponent_a_10_Template, 2, 3, "a", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("clrModalSize", "xl");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", ctx.settings);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgForOf, _clr_angular__WEBPACK_IMPORTED_MODULE_5__.ClrModal, _clr_angular__WEBPACK_IMPORTED_MODULE_5__.ClrModalBody, _clr_angular__WEBPACK_IMPORTED_MODULE_5__.ClrVerticalNav, _clr_angular__WEBPACK_IMPORTED_MODULE_5__.ClrVerticalNavLink], styles: ["a[_ngcontent-%COMP%] {\r\n    cursor: pointer;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNldHRpbmdzLW1vZGFsLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxlQUFlO0FBQ25CIiwiZmlsZSI6InNldHRpbmdzLW1vZGFsLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyJhIHtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG4iXX0= */"] });


/***/ }),

/***/ 27075:
/*!*********************************************!*\
  !*** ./src/app/settings/settings.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SettingsModule": () => (/* binding */ SettingsModule)
/* harmony export */ });
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../shared/shared.module */ 44466);
/* harmony import */ var _settings_modal_settings_modal_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./settings-modal/settings-modal.component */ 38169);
/* harmony import */ var _settings_timers_timers_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./settings/timers/timers.component */ 31863);
/* harmony import */ var _settings_preset_export_preset_export_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./settings/preset-export/preset-export.component */ 57488);
/* harmony import */ var _settings_preset_import_preset_import_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./settings/preset-import/preset-import.component */ 14180);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);






class SettingsModule {
}
SettingsModule.ɵfac = function SettingsModule_Factory(t) { return new (t || SettingsModule)(); };
SettingsModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineNgModule"]({ type: SettingsModule });
SettingsModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjector"]({ imports: [_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsetNgModuleScope"](SettingsModule, { declarations: [_settings_modal_settings_modal_component__WEBPACK_IMPORTED_MODULE_1__.SettingsModalComponent,
        _settings_timers_timers_component__WEBPACK_IMPORTED_MODULE_2__.TimersComponent,
        _settings_preset_export_preset_export_component__WEBPACK_IMPORTED_MODULE_3__.PresetExportComponent,
        _settings_preset_import_preset_import_component__WEBPACK_IMPORTED_MODULE_4__.PresetImportComponent], imports: [_shared_shared_module__WEBPACK_IMPORTED_MODULE_0__.SharedModule], exports: [_settings_modal_settings_modal_component__WEBPACK_IMPORTED_MODULE_1__.SettingsModalComponent] }); })();


/***/ }),

/***/ 57488:
/*!****************************************************************************!*\
  !*** ./src/app/settings/settings/preset-export/preset-export.component.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PresetExportComponent": () => (/* binding */ PresetExportComponent)
/* harmony export */ });
/* harmony import */ var jsoneditor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jsoneditor */ 39140);
/* harmony import */ var jsoneditor__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jsoneditor__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);



const _c0 = ["editorContainer"];
class PresetExportComponent {
    constructor() {
    }
    ngOnInit() {
    }
    ngAfterViewInit() {
        console.log(this.editorContainer);
        const options = {
            onEditable: () => false,
            modes: ['text', 'code', 'view']
        };
        this.editor = new jsoneditor__WEBPACK_IMPORTED_MODULE_0__(this.editorContainer.nativeElement, options);
    }
    exportDashboard() {
        if (this.dashboard) {
            this.editor.set(this.dashboard.exportConfig());
        }
        else {
            this.editor.set({});
        }
    }
}
PresetExportComponent.ɵfac = function PresetExportComponent_Factory(t) { return new (t || PresetExportComponent)(); };
PresetExportComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: PresetExportComponent, selectors: [["app-preset-export"]], viewQuery: function PresetExportComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵviewQuery"](_c0, 7);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵloadQuery"]()) && (ctx.editorContainer = _t.first);
    } }, inputs: { dashboard: "dashboard" }, decls: 6, vars: 0, consts: [[1, "form"], [1, "form-block"], [1, "btn", "btn-primary", "btn-block", 3, "click"], [2, "height", "500px"], ["editorContainer", ""]], template: function PresetExportComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "section", 1)(2, "button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function PresetExportComponent_Template_button_click_2_listener() { return ctx.exportDashboard(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3, " Export current dashboard ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](4, "div", 3, 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    } }, styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcmVzZXQtZXhwb3J0LmNvbXBvbmVudC5jc3MifQ== */"] });


/***/ }),

/***/ 17928:
/*!****************************************************************************!*\
  !*** ./src/app/settings/settings/preset-import/dashboard-preset-schema.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SCHEMA": () => (/* binding */ SCHEMA)
/* harmony export */ });
/* harmony import */ var app_widgets_widget_module_selector__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/widgets/widget-module-selector */ 36214);

const SCHEMA = {
    definitions: {
        widget: {
            type: 'object',
            properties: {
                type: {
                    type: 'string',
                    enum: Object.keys(app_widgets_widget_module_selector__WEBPACK_IMPORTED_MODULE_0__.widgetModuleSelector)
                },
                config: { '$ref': '#/definitions/widget_config' }
            },
            required: ['type', 'config'],
            additionalProperties: false
        },
        widget_config: {
            type: 'object',
            properties: {
                container: { type: 'object' },
                wrapper: { type: 'object' },
                widget: { type: 'object' }
            },
            additionalProperties: false
        }
    },
    type: 'object',
    properties: {
        timers: {
            type: 'array',
            items: { type: 'number' },
            description: 'Array of intervals in seconds'
        },
        widgets: {
            type: 'array',
            minItems: 1,
            items: { '$ref': '#/definitions/widget' }
        }
    },
    required: ['widgets'],
    additionalProperties: false
};


/***/ }),

/***/ 14180:
/*!****************************************************************************!*\
  !*** ./src/app/settings/settings/preset-import/preset-import.component.ts ***!
  \****************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PresetImportComponent": () => (/* binding */ PresetImportComponent)
/* harmony export */ });
/* harmony import */ var jsoneditor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jsoneditor */ 39140);
/* harmony import */ var jsoneditor__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jsoneditor__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _dashboard_preset_schema__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dashboard-preset-schema */ 17928);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var app_core_sandbox_preset_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! app/core/sandbox-preset.service */ 44739);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @clr/angular */ 4151);







const _c0 = ["editorContainer"];
function PresetImportComponent_clr_alert_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "clr-alert", 6)(1, "div", 7)(2, "span", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("clrAlertType", ctx_r1.alertType)("clrAlertClosable", false);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" ", ctx_r1.alertMessage, " ");
} }
class PresetImportComponent {
    constructor(sandboxPreset) {
        this.sandboxPreset = sandboxPreset;
        this.showAlert = false;
        this.alertType = 'alert-danger';
    }
    ngOnInit() {
    }
    ngAfterViewInit() {
        console.log(this.editorContainer);
        const options = {
            modes: ['code', 'tree', 'text'],
            schema: _dashboard_preset_schema__WEBPACK_IMPORTED_MODULE_1__.SCHEMA
        };
        this.editor = new jsoneditor__WEBPACK_IMPORTED_MODULE_0__(this.editorContainer.nativeElement, options);
    }
    importConfig() {
        try {
            const config = this.editor.get();
            this.sandboxPreset.setConfig(config);
            this.alertMessage = 'Successfully imported';
            this.alertType = 'alert-success';
            this.showAlert = true;
        }
        catch (e) {
            this.alertMessage = e;
            this.alertType = 'alert-danger';
            this.showAlert = true;
        }
    }
}
PresetImportComponent.ɵfac = function PresetImportComponent_Factory(t) { return new (t || PresetImportComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](app_core_sandbox_preset_service__WEBPACK_IMPORTED_MODULE_2__.SandboxPresetService)); };
PresetImportComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({ type: PresetImportComponent, selectors: [["app-preset-import"]], viewQuery: function PresetImportComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵviewQuery"](_c0, 7);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵloadQuery"]()) && (ctx.editorContainer = _t.first);
    } }, decls: 7, vars: 1, consts: [[1, "form"], [1, "form-block"], [2, "height", "500px"], ["editorContainer", ""], [1, "btn", "btn-primary", "btn-block", 3, "click"], [3, "clrAlertType", "clrAlertClosable", 4, "ngIf"], [3, "clrAlertType", "clrAlertClosable"], ["clr-alert-item", "", 1, "alert-item"], [1, "alert-text"]], template: function PresetImportComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 0)(1, "section", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "div", 2, 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "button", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function PresetImportComponent_Template_button_click_4_listener() { return ctx.importConfig(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](5, " Import as sandbox preset ");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](6, PresetImportComponent_clr_alert_6_Template, 4, 3, "clr-alert", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.showAlert);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgIf, _clr_angular__WEBPACK_IMPORTED_MODULE_5__.ClrAlert, _clr_angular__WEBPACK_IMPORTED_MODULE_5__.ClrAlertText], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcmVzZXQtaW1wb3J0LmNvbXBvbmVudC5jc3MifQ== */"] });


/***/ }),

/***/ 31863:
/*!**************************************************************!*\
  !*** ./src/app/settings/settings/timers/timers.component.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TimersComponent": () => (/* binding */ TimersComponent)
/* harmony export */ });
/* harmony import */ var app_core_timers_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/core/timers.service */ 75805);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @clr/angular */ 4151);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 2508);





function TimersComponent_clr_dg_row_20_Template(rf, ctx) { if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "clr-dg-row", 7)(1, "clr-dg-action-overflow")(2, "button", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function TimersComponent_clr_dg_row_20_Template_button_click_2_listener() { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r4); const timer_r1 = restoredCtx.$implicit; const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx_r3.remove(timer_r1)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3, "Remove");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "clr-dg-cell");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "clr-dg-cell");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "clr-dg-cell");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
} if (rf & 2) {
    const timer_r1 = ctx.$implicit;
    const i_r2 = ctx.index;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("clrDgItem", timer_r1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](i_r2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](timer_r1.interval);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate"](timer_r1.observerCount);
} }
class TimersComponent {
    constructor(timersService) {
        this.timersService = timersService;
        this.intervalInput = 8;
        this.timers = [];
    }
    ngOnInit() {
        this.timerUpdateSubs = this.timersService.timers$.subscribe(timers => {
            this.updateTimers(timers);
        });
    }
    ngOnDestroy() {
        this.timerUpdateSubs.unsubscribe();
    }
    updateTimers(timers) {
        if (!timers) {
            timers = this.timersService.getTimers();
        }
        this.timers = timers.map(timer => {
            return {
                interval: timer.interval.toFixed(1),
                observerCount: timer.getObserverCount(),
                timer: timer
            };
        });
    }
    remove(timer) {
        this.timersService.remove(timer.timer);
    }
    removeAll() {
        this.timersService.removeAll();
    }
    create(interval) {
        if (interval < 0.5) {
            return;
        }
        this.timersService.create(interval);
    }
}
TimersComponent.ɵfac = function TimersComponent_Factory(t) { return new (t || TimersComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](app_core_timers_service__WEBPACK_IMPORTED_MODULE_0__.TimersService)); };
TimersComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: TimersComponent, selectors: [["ng-component"]], decls: 25, vars: 2, consts: [[1, "form"], ["clrForm", "", 1, "form-block"], ["clrInput", "", "type", "number", "min", "0.5", "step", "0.1", 3, "ngModel", "ngModelChange"], [1, "btn", "btn-primary", 3, "click"], [3, "clrDgItem", 4, "clrDgItems", "clrDgItemsOf"], [1, "btn", 3, "click"], [1, "btn", "btn-danger", 3, "click"], [3, "clrDgItem"], [1, "action-item", 3, "click"]], template: function TimersComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "section", 1)(2, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3, "Create new timer (in seconds)");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "clr-input-container")(5, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](6, "Interval");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "input", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function TimersComponent_Template_input_ngModelChange_7_listener($event) { return ctx.intervalInput = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function TimersComponent_Template_button_click_8_listener() { return ctx.create(ctx.intervalInput); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, " Create ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "section", 1)(11, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](12, "Existing timers (seconds)");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "clr-datagrid")(14, "clr-dg-column");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](15, "Id");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](16, "clr-dg-column");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](17, "Interval");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](18, "clr-dg-column");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](19, "Subscribers");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](20, TimersComponent_clr_dg_row_20_Template, 10, 4, "clr-dg-row", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](21, "button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function TimersComponent_Template_button_click_21_listener() { return ctx.updateTimers(undefined); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](22, " Refresh ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](23, "button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function TimersComponent_Template_button_click_23_listener() { return ctx.removeAll(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](24, " Remove all ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.intervalInput);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("clrDgItemsOf", ctx.timers);
    } }, dependencies: [_clr_angular__WEBPACK_IMPORTED_MODULE_2__.ClrDatagrid, _clr_angular__WEBPACK_IMPORTED_MODULE_2__.ClrDatagridActionOverflow, _clr_angular__WEBPACK_IMPORTED_MODULE_2__.ClrDatagridColumn, _clr_angular__WEBPACK_IMPORTED_MODULE_2__.ClrDatagridItems, _clr_angular__WEBPACK_IMPORTED_MODULE_2__.ClrDatagridRow, _clr_angular__WEBPACK_IMPORTED_MODULE_2__.ClrDatagridCell, _clr_angular__WEBPACK_IMPORTED_MODULE_2__["ÇlrDatagridMainRenderer"], _clr_angular__WEBPACK_IMPORTED_MODULE_2__["ÇlrDatagridHeaderRenderer"], _clr_angular__WEBPACK_IMPORTED_MODULE_2__["ÇlrDatagridRowRenderer"], _clr_angular__WEBPACK_IMPORTED_MODULE_2__["ÇlrDatagridCellRenderer"], _clr_angular__WEBPACK_IMPORTED_MODULE_2__["ÇlrDatagridWillyWonka"], _clr_angular__WEBPACK_IMPORTED_MODULE_2__["ÇlrActionableOompaLoompa"], _clr_angular__WEBPACK_IMPORTED_MODULE_2__["ÇlrExpandableOompaLoompa"], _clr_angular__WEBPACK_IMPORTED_MODULE_2__.ClrLabel, _clr_angular__WEBPACK_IMPORTED_MODULE_2__.ClrForm, _clr_angular__WEBPACK_IMPORTED_MODULE_2__.ClrInput, _clr_angular__WEBPACK_IMPORTED_MODULE_2__.ClrInputContainer, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.MinValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgModel], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0aW1lcnMuY29tcG9uZW50LmNzcyJ9 */"] });


/***/ }),

/***/ 63747:
/*!*********************************************************************!*\
  !*** ./src/app/shared/date-range-form/date-range-form.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DateRangeFormComponent": () => (/* binding */ DateRangeFormComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var app_shared_timestamp_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/shared/timestamp-utils */ 38391);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @clr/angular */ 4151);
/* harmony import */ var _shtian_ng_pick_datetime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @shtian/ng-pick-datetime */ 30532);






class DateRangeFormComponent {
    constructor() {
        this.dateBegin = new Date();
        this.dateEnd = new Date();
        this.onQuery = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
        this.utc = false;
        this.timeRange = [this.dateBegin, this.dateEnd];
    }
    ngOnInit() {
    }
    query() {
        let makeTSSec, makeTSMSec;
        if (this.utc) {
            makeTSSec = app_shared_timestamp_utils__WEBPACK_IMPORTED_MODULE_0__.makeUTCTimestampSec;
            makeTSMSec = app_shared_timestamp_utils__WEBPACK_IMPORTED_MODULE_0__.makeUTCTimestampMSec;
        }
        else {
            makeTSSec = app_shared_timestamp_utils__WEBPACK_IMPORTED_MODULE_0__.makeTimestampSec;
            makeTSMSec = app_shared_timestamp_utils__WEBPACK_IMPORTED_MODULE_0__.makeTimestampMSec;
        }
        this.onQuery.emit({
            'key': this.key,
            'from': this.timeRange[0],
            'to': this.timeRange[1],
            'tsFrom': makeTSSec(this.timeRange[0]),
            'tsTo': makeTSSec(this.timeRange[1]),
            'msecFrom': makeTSMSec(this.timeRange[0]),
            'msecTo': makeTSMSec(this.timeRange[1]),
            'strFrom': app_shared_timestamp_utils__WEBPACK_IMPORTED_MODULE_0__.makeISOWithoutMilliseconds(this.timeRange[0], this.utc),
            'strTo': app_shared_timestamp_utils__WEBPACK_IMPORTED_MODULE_0__.makeISOWithoutMilliseconds(this.timeRange[1], this.utc),
            'utc': this.utc
        });
    }
}
DateRangeFormComponent.ɵfac = function DateRangeFormComponent_Factory(t) { return new (t || DateRangeFormComponent)(); };
DateRangeFormComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: DateRangeFormComponent, selectors: [["wm-date-range-form"]], inputs: { key: "key", dateBegin: "dateBegin", dateEnd: "dateEnd" }, outputs: { onQuery: "query" }, decls: 19, vars: 9, consts: [["clrForm", "", 1, "inline-form"], ["type", "text", "clrInput", "", 3, "owlDateTimeTrigger", "owlDateTime", "ngModel", "selectMode", "ngModelChange"], ["dtBegin", ""], ["dtEnd", ""], ["type", "checkbox", "clrCheckbox", "", 3, "ngModel", "ngModelChange"], [1, "btn", "btn-primary", 3, "click"]], template: function DateRangeFormComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "clr-input-container")(2, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3, "From:");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "input", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function DateRangeFormComponent_Template_input_ngModelChange_4_listener($event) { return ctx.timeRange = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](5, "owl-date-time", null, 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "clr-input-container")(8, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "To:");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "input", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function DateRangeFormComponent_Template_input_ngModelChange_10_listener($event) { return ctx.timeRange = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](11, "owl-date-time", null, 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "clr-checkbox-wrapper")(14, "input", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function DateRangeFormComponent_Template_input_ngModelChange_14_listener($event) { return ctx.utc = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](16, "UTC");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function DateRangeFormComponent_Template_button_click_17_listener() { return ctx.query(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](18, " Query ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    } if (rf & 2) {
        const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](6);
        const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("owlDateTimeTrigger", _r0)("owlDateTime", _r0)("ngModel", ctx.timeRange)("selectMode", "rangeFrom");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("owlDateTimeTrigger", _r1)("owlDateTime", _r1)("ngModel", ctx.timeRange)("selectMode", "rangeTo");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.utc);
    } }, dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgModel, _clr_angular__WEBPACK_IMPORTED_MODULE_3__.ClrLabel, _clr_angular__WEBPACK_IMPORTED_MODULE_3__.ClrForm, _clr_angular__WEBPACK_IMPORTED_MODULE_3__.ClrCheckbox, _clr_angular__WEBPACK_IMPORTED_MODULE_3__.ClrCheckboxWrapper, _clr_angular__WEBPACK_IMPORTED_MODULE_3__.ClrInput, _clr_angular__WEBPACK_IMPORTED_MODULE_3__.ClrInputContainer, _shtian_ng_pick_datetime__WEBPACK_IMPORTED_MODULE_4__.OwlDateTimeTriggerDirective, _shtian_ng_pick_datetime__WEBPACK_IMPORTED_MODULE_4__.OwlDateTimeInputDirective, _shtian_ng_pick_datetime__WEBPACK_IMPORTED_MODULE_4__.OwlDateTimeComponent], styles: [".inline-form[_ngcontent-%COMP%]    > clr-input-container[_ngcontent-%COMP%] {\r\n    padding-top: 0px;\r\n}\r\n\r\n.inline-form[_ngcontent-%COMP%]    > clr-checkbox-wrapper[_ngcontent-%COMP%]    > label[_ngcontent-%COMP%] {\r\n    padding-right: 1em;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRhdGUtcmFuZ2UtZm9ybS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksZ0JBQWdCO0FBQ3BCOztBQUVBO0lBQ0ksa0JBQWtCO0FBQ3RCIiwiZmlsZSI6ImRhdGUtcmFuZ2UtZm9ybS5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmlubGluZS1mb3JtID4gY2xyLWlucHV0LWNvbnRhaW5lciB7XHJcbiAgICBwYWRkaW5nLXRvcDogMHB4O1xyXG59XHJcblxyXG4uaW5saW5lLWZvcm0gPiBjbHItY2hlY2tib3gtd3JhcHBlciA+IGxhYmVsIHtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDFlbTtcclxufVxyXG4iXX0= */"] });


/***/ }),

/***/ 5263:
/*!*******************************************************************!*\
  !*** ./src/app/shared/delimited-form/delimited-form.component.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DelimitedFormComponent": () => (/* binding */ DelimitedFormComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @clr/angular */ 4151);




class DelimitedFormComponent {
    constructor() {
        this.delimiter = ',';
        this.onQuery = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
        this.inputModel = '';
    }
    ngOnInit() {
        this.placeholder = (this.label || this.key) +
            '. \"' + this.delimiter + '\" delimited';
    }
    query() {
        if (typeof this.inputModel == 'undefined' || this.inputModel === '') {
            return;
        }
        const split = this.inputModel.split(this.delimiter);
        let values = [];
        if (this.inputType == 'string') {
            values = split.map(v => String(v));
        }
        else if (this.inputType == 'number') {
            values = split.map(v => Number(v));
        }
        this.onQuery.emit({
            'key': this.key,
            'value': values
        });
    }
}
DelimitedFormComponent.ɵfac = function DelimitedFormComponent_Factory(t) { return new (t || DelimitedFormComponent)(); };
DelimitedFormComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: DelimitedFormComponent, selectors: [["wm-delimited-form"]], inputs: { key: "key", label: "label", delimiter: "delimiter", inputType: "inputType" }, outputs: { onQuery: "query" }, decls: 7, vars: 3, consts: [["clrForm", "", 1, "inline-form"], ["clrInput", "", "type", "text", 3, "ngModel", "placeholder", "ngModelChange"], [1, "btn", "btn-primary", 3, "click"]], template: function DelimitedFormComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0)(1, "clr-input-container")(2, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "input", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function DelimitedFormComponent_Template_input_ngModelChange_4_listener($event) { return ctx.inputModel = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](5, "button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function DelimitedFormComponent_Template_button_click_5_listener() { return ctx.query(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](6, " Query ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", ctx.label || ctx.key, ":");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.inputModel)("placeholder", ctx.placeholder);
    } }, dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_1__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.NgModel, _clr_angular__WEBPACK_IMPORTED_MODULE_2__.ClrLabel, _clr_angular__WEBPACK_IMPORTED_MODULE_2__.ClrForm, _clr_angular__WEBPACK_IMPORTED_MODULE_2__.ClrInput, _clr_angular__WEBPACK_IMPORTED_MODULE_2__.ClrInputContainer], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkZWxpbWl0ZWQtZm9ybS5jb21wb25lbnQuY3NzIn0= */"] });


/***/ }),

/***/ 61402:
/*!******************************************************!*\
  !*** ./src/app/shared/detector-form/data.service.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetectorFormService": () => (/* binding */ DetectorFormService)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var app_core_database_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/core/database.service */ 67084);


class DetectorFormService {
    constructor(db) {
        this.db = db;
    }
    queryDetectorNames(index, database) {
        const query = this.makeDetectorNameQuery(index);
        const queryJSON = this.db.stringifyToNDJSON(query);
        return this.db.queryNDJson('_msearch', queryJSON, database);
    }
    // Creates request for quering the detector names
    makeDetectorNameQuery(index) {
        const header = { 'index': index };
        let body;
        if (index === 'vdmtest') {
            body = {
                '_source': ['detector'],
                'size': 0,
                'aggs': {
                    'detector_names': {
                        'terms': {
                            'field': 'detector.keyword',
                            'size': 1000,
                        }
                    }
                }
            };
        }
        else if (index === 'cmsos-data-bril-vdmshape' || index === 'cmsos-data-bril-vdmsigma') {
            body = {
                '_source': ['detectorname'],
                'size': 1000
            };
        }
        else {
            return '';
        }
        return [header, body];
    }
}
DetectorFormService.ɵfac = function DetectorFormService_Factory(t) { return new (t || DetectorFormService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](app_core_database_service__WEBPACK_IMPORTED_MODULE_0__.DatabaseService)); };
DetectorFormService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: DetectorFormService, factory: DetectorFormService.ɵfac });


/***/ }),

/***/ 73109:
/*!*****************************************************************!*\
  !*** ./src/app/shared/detector-form/detector-form.component.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetectorFormComponent": () => (/* binding */ DetectorFormComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./data.service */ 61402);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @clr/angular */ 4151);






function DetectorFormComponent_ng_container_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0, 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const selected_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", selected_r2, " ");
} }
function DetectorFormComponent_clr_option_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "clr-option", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const detectorName_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("clrValue", detectorName_r3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", detectorName_r3, " ");
} }
class DetectorFormComponent {
    constructor(dataService) {
        this.dataService = dataService;
        this.queryDetectors = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    }
    ngOnInit() {
        // Query detector names
        if (this.database && this.index) {
            const names = this.dataService.queryDetectorNames(this.index, this.database).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(this.setDropdown.bind(this)));
            names.subscribe();
        }
    }
    // Get results of the query for the detector names
    setDropdown(result) {
        if (this.index === "vdmtest") {
            let response = result.responses[0].aggregations.detector_names.buckets;
            this.detectorNames = [];
            response.forEach((detector, i) => {
                this.detectorNames[i] = detector.key;
            });
        }
        else if (this.index === 'cmsos-data-bril-vdmshape' || this.index === 'cmsos-data-bril-vdmsigma') {
            let response = result.responses[0].hits.hits;
            this.detectorNames = [];
            response.forEach((detector, i) => {
                if (!this.detectorNames.includes(detector._source.detectorname)) {
                    this.detectorNames[i] = detector._source.detectorname;
                }
            });
        }
    }
    onChange(event) {
        this.queryDetectors.emit(this.selection);
    }
}
DetectorFormComponent.ɵfac = function DetectorFormComponent_Factory(t) { return new (t || DetectorFormComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_data_service__WEBPACK_IMPORTED_MODULE_0__.DetectorFormService)); };
DetectorFormComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: DetectorFormComponent, selectors: [["wm-detector-form"]], inputs: { database: "database", index: "index" }, outputs: { queryDetectors: "onChange" }, decls: 10, vars: 4, consts: [["name", "multiSelect", "clrMulti", "true", "required", "", 3, "ngModel", "ngModelChange"], ["class", "hey", 4, "clrOptionSelected"], [3, "clrValue", 4, "clrOptionItems", "clrOptionItemsOf"], [1, "hey"], [3, "clrValue"]], template: function DetectorFormComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "clr-combobox-container")(2, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3, "Choose detectors");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "clr-combobox", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function DetectorFormComponent_Template_clr_combobox_ngModelChange_4_listener($event) { return ctx.selection = $event; })("ngModelChange", function DetectorFormComponent_Template_clr_combobox_ngModelChange_4_listener($event) { return ctx.onChange($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](5, DetectorFormComponent_ng_container_5_Template, 2, 1, "ng-container", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "clr-options");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](7, DetectorFormComponent_clr_option_7_Template, 2, 2, "clr-option", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "clr-control-helper");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "Availabe detectors for this preset");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.selection);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵstyleProp"]("width", 200, "%");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("clrOptionItemsOf", ctx.detectorNames);
    } }, dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgModel, _clr_angular__WEBPACK_IMPORTED_MODULE_4__.ClrLabel, _clr_angular__WEBPACK_IMPORTED_MODULE_4__.ClrControlHelper, _clr_angular__WEBPACK_IMPORTED_MODULE_4__.ClrCombobox, _clr_angular__WEBPACK_IMPORTED_MODULE_4__.ClrComboboxContainer, _clr_angular__WEBPACK_IMPORTED_MODULE_4__.ClrOptions, _clr_angular__WEBPACK_IMPORTED_MODULE_4__.ClrOption, _clr_angular__WEBPACK_IMPORTED_MODULE_4__.ClrOptionSelected, _clr_angular__WEBPACK_IMPORTED_MODULE_4__.ClrOptionItems], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkZXRlY3Rvci1mb3JtLmNvbXBvbmVudC5jc3MifQ== */"] });


/***/ }),

/***/ 36959:
/*!***************************************************************!*\
  !*** ./src/app/shared/dynamic-form/dynamic-form.component.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DynamicFormComponent": () => (/* binding */ DynamicFormComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 71989);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _ngx_formly_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-formly/core */ 44599);








function DynamicFormComponent_form_0_Template(rf, ctx) { if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "form", 1)(1, "formly-form", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("modelChange", function DynamicFormComponent_form_0_Template_formly_form_modelChange_1_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r2); const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r1.onChange($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formGroup", ctx_r0.form);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("fields", ctx_r0.fields)("model", ctx_r0.model);
} }
class DynamicFormComponent {
    constructor() {
        this.debounce = 0;
        this.form = null;
        this.fields = null;
        this.model = {};
        this.modelChange = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
        this.rawModelChange = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
        this._formFields = {};
        let modelChange = this.rawModelChange;
        if (this.debounce > 0) {
            modelChange = this.rawModelChange.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.debounceTime)(this.debounce));
        }
        modelChange.subscribe(model => this.modelChange.emit(model));
    }
    set formFields(newFields) {
        this._formFields = newFields;
        this.fields = JSON.parse(JSON.stringify(this._formFields));
        if (this.fields && this.fields.length > 0) {
            this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.UntypedFormGroup({});
        }
        else {
            this.form = null;
        }
    }
    ngOnInit() {
    }
    onChange(model) {
        this.rawModelChange.next(model);
    }
}
DynamicFormComponent.ɵfac = function DynamicFormComponent_Factory(t) { return new (t || DynamicFormComponent)(); };
DynamicFormComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: DynamicFormComponent, selectors: [["wm-dynamic-form"]], inputs: { debounce: "debounce", model: "model", formFields: "formFields" }, outputs: { modelChange: "modelChange" }, decls: 1, vars: 1, consts: [["class", "clr-form clr-form-horizontal inline-form", 3, "formGroup", 4, "ngIf"], [1, "clr-form", "clr-form-horizontal", "inline-form", 3, "formGroup"], [3, "fields", "model", "modelChange"]], template: function DynamicFormComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, DynamicFormComponent_form_0_Template, 2, 3, "form", 0);
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.form);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵNgNoValidate"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatusGroup, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormGroupDirective, _ngx_formly_core__WEBPACK_IMPORTED_MODULE_5__.FormlyForm], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkeW5hbWljLWZvcm0uY29tcG9uZW50LmNzcyJ9 */"] });


/***/ }),

/***/ 28413:
/*!************************************************************!*\
  !*** ./src/app/shared/dynamic-form/dynamic-form.module.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DynamicFormModule": () => (/* binding */ DynamicFormModule)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @clr/angular */ 4151);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _ngx_formly_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-formly/core */ 44599);
/* harmony import */ var _dynamic_form_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dynamic-form.component */ 36959);
/* harmony import */ var _formly_fields_formly_fields__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./formly-fields/formly-fields */ 97875);
/* harmony import */ var _formly_fields_number_number_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./formly-fields/number/number.component */ 45521);
/* harmony import */ var _formly_fields_string_string_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./formly-fields/string/string.component */ 85085);
/* harmony import */ var _formly_fields_delimited_delimited_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./formly-fields/delimited/delimited.component */ 69970);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);











class DynamicFormModule {
}
DynamicFormModule.ɵfac = function DynamicFormModule_Factory(t) { return new (t || DynamicFormModule)(); };
DynamicFormModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineNgModule"]({ type: DynamicFormModule });
DynamicFormModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjector"]({ imports: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
        _clr_angular__WEBPACK_IMPORTED_MODULE_7__.ClarityModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.ReactiveFormsModule,
        _ngx_formly_core__WEBPACK_IMPORTED_MODULE_9__.FormlyModule.forRoot(_formly_fields_formly_fields__WEBPACK_IMPORTED_MODULE_1__.FORMLY_FIELDS_CONFIG)] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsetNgModuleScope"](DynamicFormModule, { declarations: [_dynamic_form_component__WEBPACK_IMPORTED_MODULE_0__.DynamicFormComponent, _formly_fields_number_number_component__WEBPACK_IMPORTED_MODULE_2__.NumberComponent, _formly_fields_string_string_component__WEBPACK_IMPORTED_MODULE_3__.StringComponent,
        _formly_fields_delimited_delimited_component__WEBPACK_IMPORTED_MODULE_4__.DelimitedComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
        _clr_angular__WEBPACK_IMPORTED_MODULE_7__.ClarityModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.ReactiveFormsModule, _ngx_formly_core__WEBPACK_IMPORTED_MODULE_9__.FormlyModule], exports: [_dynamic_form_component__WEBPACK_IMPORTED_MODULE_0__.DynamicFormComponent] }); })();


/***/ }),

/***/ 69970:
/*!************************************************************************************!*\
  !*** ./src/app/shared/dynamic-form/formly-fields/delimited/delimited.component.ts ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DelimitedComponent": () => (/* binding */ DelimitedComponent)
/* harmony export */ });
/* harmony import */ var _ngx_formly_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ngx-formly/core */ 44599);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 71989);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @clr/angular */ 4151);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);








function DelimitedComponent_label_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", ctx_r0.field.templateOptions.label, " ");
} }
class DelimitedComponent extends _ngx_formly_core__WEBPACK_IMPORTED_MODULE_1__.FieldType {
    constructor() {
        super(...arguments);
        this.inputModel = '';
        this.modelChange$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__.Subject();
    }
    ngOnInit() {
        let mapper;
        if (this.field.type == 'delimited-numbers') {
            mapper = (val) => Number(val);
        }
        else {
            mapper = (val) => String(val);
        }
        let delimiter = ',';
        if (typeof this.field.templateOptions['delimiter'] == 'string') {
            delimiter = this.field.templateOptions['delimiter'];
        }
        this.modelChange$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.debounceTime)(300)).subscribe(event => {
            if (event == '') {
                this.formControl.setValue([]);
                return;
            }
            const value = event.split(delimiter).map(mapper);
            this.formControl.setValue(value);
        });
    }
    onModelChange(event) {
        this.modelChange$.next(event);
    }
}
DelimitedComponent.ɵfac = /*@__PURE__*/ function () { let ɵDelimitedComponent_BaseFactory; return function DelimitedComponent_Factory(t) { return (ɵDelimitedComponent_BaseFactory || (ɵDelimitedComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetInheritedFactory"](DelimitedComponent)))(t || DelimitedComponent); }; }();
DelimitedComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: DelimitedComponent, selectors: [["formly-field-delimited"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], decls: 3, vars: 3, consts: [[4, "ngIf"], ["clrInput", "", "type", "text", 3, "ngModel", "formlyAttributes", "ngModelChange"]], template: function DelimitedComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "clr-input-container");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, DelimitedComponent_label_1_Template, 2, 1, "label", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "input", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function DelimitedComponent_Template_input_ngModelChange_2_listener($event) { return ctx.inputModel = $event; })("ngModelChange", function DelimitedComponent_Template_input_ngModelChange_2_listener($event) { return ctx.onModelChange($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.to.label);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx.inputModel)("formlyAttributes", ctx.field);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.NgIf, _clr_angular__WEBPACK_IMPORTED_MODULE_5__.ClrLabel, _clr_angular__WEBPACK_IMPORTED_MODULE_5__.ClrInput, _clr_angular__WEBPACK_IMPORTED_MODULE_5__.ClrInputContainer, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_6__.NgModel, _ngx_formly_core__WEBPACK_IMPORTED_MODULE_1__["ɵFormlyAttributes"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkZWxpbWl0ZWQuY29tcG9uZW50LmNzcyJ9 */"] });


/***/ }),

/***/ 97875:
/*!********************************************************************!*\
  !*** ./src/app/shared/dynamic-form/formly-fields/formly-fields.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FORMLY_FIELDS_CONFIG": () => (/* binding */ FORMLY_FIELDS_CONFIG)
/* harmony export */ });
/* harmony import */ var _number_number_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./number/number.component */ 45521);
/* harmony import */ var _string_string_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./string/string.component */ 85085);
/* harmony import */ var _delimited_delimited_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./delimited/delimited.component */ 69970);



const FORMLY_FIELDS_CONFIG = {
    types: [
        { name: 'number', component: _number_number_component__WEBPACK_IMPORTED_MODULE_0__.NumberComponent },
        { name: 'string', component: _string_string_component__WEBPACK_IMPORTED_MODULE_1__.StringComponent },
        { name: 'delimited-strings', component: _delimited_delimited_component__WEBPACK_IMPORTED_MODULE_2__.DelimitedComponent },
        { name: 'delimited-numbers', component: _delimited_delimited_component__WEBPACK_IMPORTED_MODULE_2__.DelimitedComponent }
    ]
};


/***/ }),

/***/ 45521:
/*!******************************************************************************!*\
  !*** ./src/app/shared/dynamic-form/formly-fields/number/number.component.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NumberComponent": () => (/* binding */ NumberComponent)
/* harmony export */ });
/* harmony import */ var _ngx_formly_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ngx-formly/core */ 44599);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @clr/angular */ 4151);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);






function NumberComponent_label_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", ctx_r0.field.templateOptions.label, " ");
} }
class NumberComponent extends _ngx_formly_core__WEBPACK_IMPORTED_MODULE_1__.FieldType {
    ngAfterContentInit() {
        // bellow overwriting setValue function to avoid
        // FormControl.valueChanges firing multiple times
        // see: https://github.com/angular/angular/issues/12540
        const originalSetValue = this.field.formControl.setValue.bind(this.field.formControl);
        this.field.formControl.setValue = (value, options) => {
            if (value !== this.lastValue) {
                this.lastValue = value;
                originalSetValue(value, options);
            }
        };
    }
}
NumberComponent.ɵfac = /*@__PURE__*/ function () { let ɵNumberComponent_BaseFactory; return function NumberComponent_Factory(t) { return (ɵNumberComponent_BaseFactory || (ɵNumberComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetInheritedFactory"](NumberComponent)))(t || NumberComponent); }; }();
NumberComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: NumberComponent, selectors: [["formly-field-number"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], decls: 3, vars: 6, consts: [[4, "ngIf"], ["clrInput", "", "type", "number", 3, "formControl", "formlyAttributes", "min", "max", "step"]], template: function NumberComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "clr-input-container");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, NumberComponent_label_1_Template, 2, 1, "label", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "input", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.to.label);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formControl", ctx.formControl)("formlyAttributes", ctx.field)("min", ctx.to.min)("max", ctx.to.max)("step", ctx.to.step);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgIf, _clr_angular__WEBPACK_IMPORTED_MODULE_3__.ClrLabel, _clr_angular__WEBPACK_IMPORTED_MODULE_3__.ClrInput, _clr_angular__WEBPACK_IMPORTED_MODULE_3__.ClrInputContainer, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.MinValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.MaxValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControlDirective, _ngx_formly_core__WEBPACK_IMPORTED_MODULE_1__["ɵFormlyAttributes"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJudW1iZXIuY29tcG9uZW50LmNzcyJ9 */"] });


/***/ }),

/***/ 85085:
/*!******************************************************************************!*\
  !*** ./src/app/shared/dynamic-form/formly-fields/string/string.component.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StringComponent": () => (/* binding */ StringComponent)
/* harmony export */ });
/* harmony import */ var _ngx_formly_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ngx-formly/core */ 44599);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @clr/angular */ 4151);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);






function StringComponent_label_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtextInterpolate1"]("", ctx_r0.field.templateOptions.label, " ");
} }
class StringComponent extends _ngx_formly_core__WEBPACK_IMPORTED_MODULE_1__.FieldType {
}
StringComponent.ɵfac = /*@__PURE__*/ function () { let ɵStringComponent_BaseFactory; return function StringComponent_Factory(t) { return (ɵStringComponent_BaseFactory || (ɵStringComponent_BaseFactory = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetInheritedFactory"](StringComponent)))(t || StringComponent); }; }();
StringComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: StringComponent, selectors: [["formly-field-string"]], features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵInheritDefinitionFeature"]], decls: 3, vars: 3, consts: [[4, "ngIf"], ["clrInput", "", "type", "text", 3, "formControl", "formlyAttributes"]], template: function StringComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "clr-input-container");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, StringComponent_label_1_Template, 2, 1, "label", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "input", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.to.label);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("formControl", ctx.formControl)("formlyAttributes", ctx.field);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgIf, _clr_angular__WEBPACK_IMPORTED_MODULE_3__.ClrLabel, _clr_angular__WEBPACK_IMPORTED_MODULE_3__.ClrInput, _clr_angular__WEBPACK_IMPORTED_MODULE_3__.ClrInputContainer, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControlDirective, _ngx_formly_core__WEBPACK_IMPORTED_MODULE_1__["ɵFormlyAttributes"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzdHJpbmcuY29tcG9uZW50LmNzcyJ9 */"] });


/***/ }),

/***/ 6333:
/*!***************************************************************************!*\
  !*** ./src/app/shared/dynamic-query-form/dynamic-query-form.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DynamicQueryFormComponent": () => (/* binding */ DynamicQueryFormComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);


const _c0 = ["content"];
function DynamicQueryFormComponent_ng_template_0_Template(rf, ctx) { }
class DynamicQueryFormComponent {
    constructor(componentFactoryResolver) {
        this.componentFactoryResolver = componentFactoryResolver;
        this.onQuery = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    }
    ngOnInit() {
        const componentFactory = this.componentFactoryResolver
            .resolveComponentFactory(this.component);
        this.content.clear();
        const componentRef = this.content.createComponent(componentFactory);
        if (this.config) {
            Object.keys(this.config).forEach(k => {
                componentRef.instance[k] = this.config[k];
            });
        }
        componentRef.instance.onQuery = this.onQuery;
    }
}
DynamicQueryFormComponent.ɵfac = function DynamicQueryFormComponent_Factory(t) { return new (t || DynamicQueryFormComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ComponentFactoryResolver)); };
DynamicQueryFormComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: DynamicQueryFormComponent, selectors: [["wm-dynamic-query-form"]], viewQuery: function DynamicQueryFormComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵviewQuery"](_c0, 7, _angular_core__WEBPACK_IMPORTED_MODULE_0__.ViewContainerRef);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵloadQuery"]()) && (ctx.content = _t.first);
    } }, inputs: { component: "component", config: "config" }, outputs: { onQuery: "query" }, decls: 2, vars: 0, consts: [["content", ""]], template: function DynamicQueryFormComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](0, DynamicQueryFormComponent_ng_template_0_Template, 0, 0, "ng-template", null, 0, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
    } }, encapsulation: 2 });


/***/ }),

/***/ 49207:
/*!***********************************************************************!*\
  !*** ./src/app/shared/fill-run-ls-form/fill-run-ls-form.component.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FillRunLsFormComponent": () => (/* binding */ FillRunLsFormComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @clr/angular */ 4151);





function FillRunLsFormComponent_clr_input_container_1_Template(rf, ctx) { if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "clr-input-container")(1, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "FILL:");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "input", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function FillRunLsFormComponent_clr_input_container_1_Template_input_ngModelChange_3_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r4); const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r3.fill = $event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r0.fill);
} }
function FillRunLsFormComponent_clr_input_container_2_Template(rf, ctx) { if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "clr-input-container")(1, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "RUN:");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "input", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function FillRunLsFormComponent_clr_input_container_2_Template_input_ngModelChange_3_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r6); const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r5.run = $event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r1.run);
} }
function FillRunLsFormComponent_clr_input_container_3_Template(rf, ctx) { if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "clr-input-container")(1, "label");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](2, "LS:");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](3, "input", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("ngModelChange", function FillRunLsFormComponent_clr_input_container_3_Template_input_ngModelChange_3_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵrestoreView"](_r8); const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵresetView"](ctx_r7.ls = $event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngModel", ctx_r2.ls);
} }
class FillRunLsFormComponent {
    constructor() {
        this.fillEnabled = false;
        this.runEnabled = true;
        this.lsEnabled = true;
        this.onQuery = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    }
    ngOnInit() {
    }
    query() {
        this.onQuery.emit({
            key: this.key,
            fill: this.fill,
            run: this.run,
            ls: this.ls
        });
    }
}
FillRunLsFormComponent.ɵfac = function FillRunLsFormComponent_Factory(t) { return new (t || FillRunLsFormComponent)(); };
FillRunLsFormComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: FillRunLsFormComponent, selectors: [["wm-fill-run-ls-form"]], inputs: { key: "key", fillEnabled: "fillEnabled", runEnabled: "runEnabled", lsEnabled: "lsEnabled" }, outputs: { onQuery: "query" }, decls: 6, vars: 3, consts: [["clrForm", "", 1, "inline-form"], [4, "ngIf"], [1, "btn", "btn-primary", 3, "click"], ["clrInput", "", "type", "number", "step", "1", "min", "1000", "max", "9999", 3, "ngModel", "ngModelChange"], ["clrInput", "", "type", "number", "step", "1", "min", "100000", "max", "999999", 3, "ngModel", "ngModelChange"], ["clrInput", "", "type", "number", "step", "1", "min", "1", "max", "99999", 3, "ngModel", "ngModelChange"]], template: function FillRunLsFormComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, FillRunLsFormComponent_clr_input_container_1_Template, 4, 1, "clr-input-container", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](2, FillRunLsFormComponent_clr_input_container_2_Template, 4, 1, "clr-input-container", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](3, FillRunLsFormComponent_clr_input_container_3_Template, 4, 1, "clr-input-container", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("click", function FillRunLsFormComponent_Template_button_click_4_listener() { return ctx.query(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtext"](5, " Query ");
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.fillEnabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.runEnabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngIf", ctx.lsEnabled);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NumberValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.MinValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.MaxValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgModel, _clr_angular__WEBPACK_IMPORTED_MODULE_3__.ClrLabel, _clr_angular__WEBPACK_IMPORTED_MODULE_3__.ClrForm, _clr_angular__WEBPACK_IMPORTED_MODULE_3__.ClrInput, _clr_angular__WEBPACK_IMPORTED_MODULE_3__.ClrInputContainer], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmaWxsLXJ1bi1scy1mb3JtLmNvbXBvbmVudC5jc3MifQ== */"] });


/***/ }),

/***/ 79577:
/*!*************************************************!*\
  !*** ./src/app/shared/fit-form/data.service.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FitFormService": () => (/* binding */ FitFormService)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var app_core_database_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/core/database.service */ 67084);


class FitFormService {
    constructor(db) {
        this.db = db;
    }
    queryFitNames(index, database) {
        const query = this.makeFitNameQuery(index);
        const queryJSON = this.db.stringifyToNDJSON(query);
        return this.db.queryNDJson('_msearch', queryJSON, database);
    }
    // Creates request for quering the detector names
    makeFitNameQuery(index) {
        const header = { 'index': index };
        let body;
        if (index === 'vdmtest') {
            body = {
                '_source': ['fit'],
                'size': 0,
                'aggs': {
                    'fit_names': {
                        'terms': {
                            'field': 'fit.keyword',
                            'size': 1000,
                        }
                    }
                }
            };
        }
        else {
            return '';
        }
        return [header, body];
    }
}
FitFormService.ɵfac = function FitFormService_Factory(t) { return new (t || FitFormService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](app_core_database_service__WEBPACK_IMPORTED_MODULE_0__.DatabaseService)); };
FitFormService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: FitFormService, factory: FitFormService.ɵfac });


/***/ }),

/***/ 55793:
/*!*******************************************************!*\
  !*** ./src/app/shared/fit-form/fit-form.component.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FitFormComponent": () => (/* binding */ FitFormComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 50635);
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./data.service */ 79577);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @clr/angular */ 4151);






function FitFormComponent_ng_container_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const selected_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", selected_r2, " ");
} }
function FitFormComponent_clr_option_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "clr-option", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const fitName_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("clrValue", fitName_r3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", fitName_r3, " ");
} }
class FitFormComponent {
    constructor(dataService) {
        this.dataService = dataService;
        this.queryFits = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    }
    ngOnInit() {
        // Query detector names
        if (this.database && this.index) {
            const names = this.dataService.queryFitNames(this.index, this.database).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(this.setDropdown.bind(this)));
            names.subscribe();
        }
    }
    // Get results of the query for the detector names
    setDropdown(result) {
        if (this.index === "vdmtest") {
            let response = result.responses[0].aggregations.fit_names.buckets;
            this.fitNames = [];
            response.forEach((fit, i) => {
                this.fitNames[i] = fit.key;
            });
        }
    }
    onChange(event) {
        this.queryFits.emit(this.selection);
    }
}
FitFormComponent.ɵfac = function FitFormComponent_Factory(t) { return new (t || FitFormComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_data_service__WEBPACK_IMPORTED_MODULE_0__.FitFormService)); };
FitFormComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: FitFormComponent, selectors: [["wm-fit-form"]], inputs: { database: "database", index: "index" }, outputs: { queryFits: "onChange" }, decls: 10, vars: 4, consts: [["name", "multiSelect", "clrMulti", "true", "required", "", 3, "ngModel", "ngModelChange"], [4, "clrOptionSelected"], [3, "clrValue", 4, "clrOptionItems", "clrOptionItemsOf"], [3, "clrValue"]], template: function FitFormComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div")(1, "clr-combobox-container")(2, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3, "Choose fits");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "clr-combobox", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function FitFormComponent_Template_clr_combobox_ngModelChange_4_listener($event) { return ctx.selection = $event; })("ngModelChange", function FitFormComponent_Template_clr_combobox_ngModelChange_4_listener($event) { return ctx.onChange($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](5, FitFormComponent_ng_container_5_Template, 2, 1, "ng-container", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "clr-options");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](7, FitFormComponent_clr_option_7_Template, 2, 2, "clr-option", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "clr-control-helper");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](9, "Availabe fits for this preset");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.selection);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵstyleProp"]("width", 200, "%");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("clrOptionItemsOf", ctx.fitNames);
    } }, dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.RequiredValidator, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgModel, _clr_angular__WEBPACK_IMPORTED_MODULE_4__.ClrLabel, _clr_angular__WEBPACK_IMPORTED_MODULE_4__.ClrControlHelper, _clr_angular__WEBPACK_IMPORTED_MODULE_4__.ClrCombobox, _clr_angular__WEBPACK_IMPORTED_MODULE_4__.ClrComboboxContainer, _clr_angular__WEBPACK_IMPORTED_MODULE_4__.ClrOptions, _clr_angular__WEBPACK_IMPORTED_MODULE_4__.ClrOption, _clr_angular__WEBPACK_IMPORTED_MODULE_4__.ClrOptionSelected, _clr_angular__WEBPACK_IMPORTED_MODULE_4__.ClrOptionItems], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmaXQtZm9ybS5jb21wb25lbnQuY3NzIn0= */"] });


/***/ }),

/***/ 94891:
/*!*********************************************************************!*\
  !*** ./src/app/shared/quick-date-form/quick-date-form.component.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QuickDateFormComponent": () => (/* binding */ QuickDateFormComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var app_shared_timestamp_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/shared/timestamp-utils */ 38391);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @clr/angular */ 4151);





function QuickDateFormComponent_button_2_Template(rf, ctx) { if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "button", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function QuickDateFormComponent_button_2_Template_button_click_0_listener() { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r3); const opt_r1 = restoredCtx.$implicit; const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx_r2.query(opt_r1)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const opt_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", opt_r1.text, " ");
} }
class QuickDateFormComponent {
    constructor() {
        this.onQuery = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    }
    ngOnInit() {
    }
    query(opt) {
        const now = new Date();
        let unitMS = 60000;
        if (opt.unit === 'hours') {
            unitMS = 3600000;
        }
        else if (opt.unit === 'days') {
            unitMS = 86400000;
        }
        let end = now;
        if (opt.hasOwnProperty('offset')) {
            end = new Date(now.getTime() + opt.offset * unitMS);
        }
        const start = new Date(end.getTime() - opt.duration * unitMS);
        this.onQuery.emit({
            'key': this.key,
            'from': start,
            'to': end,
            'tsFrom': Math.round(start.getTime() / 1000),
            'tsTo': Math.round(end.getTime() / 1000),
            'msecFrom': start.getTime(),
            'msecTo': end.getTime(),
            'strFrom': app_shared_timestamp_utils__WEBPACK_IMPORTED_MODULE_0__.makeISOWithoutMilliseconds(start, false),
            'strTo': app_shared_timestamp_utils__WEBPACK_IMPORTED_MODULE_0__.makeISOWithoutMilliseconds(end, false),
            'utc': false
        });
    }
}
QuickDateFormComponent.ɵfac = function QuickDateFormComponent_Factory(t) { return new (t || QuickDateFormComponent)(); };
QuickDateFormComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: QuickDateFormComponent, selectors: [["wm-quick-date-form"]], inputs: { key: "key", options: "options" }, outputs: { onQuery: "query" }, decls: 3, vars: 1, consts: [["clrForm", ""], [1, "btn-group", "btn-primary", "btn-sm"], ["class", "btn", 3, "click", 4, "ngFor", "ngForOf"], [1, "btn", 3, "click"]], template: function QuickDateFormComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, QuickDateFormComponent_button_2_Template, 2, 1, "button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx.options);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgForOf, _clr_angular__WEBPACK_IMPORTED_MODULE_3__.ClrForm], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJxdWljay1kYXRlLWZvcm0uY29tcG9uZW50LmNzcyJ9 */"] });


/***/ }),

/***/ 2199:
/*!***********************************************************!*\
  !*** ./src/app/shared/range-form/range-form.component.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RangeFormComponent": () => (/* binding */ RangeFormComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @clr/angular */ 4151);
/* harmony import */ var _detector_form_detector_form_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../detector-form/detector-form.component */ 73109);
/* harmony import */ var _fit_form_fit_form_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../fit-form/fit-form.component */ 55793);







function RangeFormComponent_wm_detector_form_9_Template(rf, ctx) { if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "wm-detector-form", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("onChange", function RangeFormComponent_wm_detector_form_9_Template_wm_detector_form_onChange_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r3); const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r2.changeDetectors($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("database", ctx_r0.database)("index", ctx_r0.index);
} }
function RangeFormComponent_wm_fit_form_10_Template(rf, ctx) { if (rf & 1) {
    const _r5 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "wm-fit-form", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("onChange", function RangeFormComponent_wm_fit_form_10_Template_wm_fit_form_onChange_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵrestoreView"](_r5); const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵresetView"](ctx_r4.changeFits($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("database", ctx_r1.database)("index", ctx_r1.index);
} }
class RangeFormComponent {
    constructor() {
        this.inputType = 'number';
        this.onQuery = new _angular_core__WEBPACK_IMPORTED_MODULE_2__.EventEmitter();
    }
    ngOnInit() {
        this.selectedDetectors = [];
        this.selectedFits = [];
    }
    query() {
        this.onQuery.emit({
            'key': this.key,
            'min': this.inputType === 'number' ? parseFloat(this.minValue) : this.minValue,
            'max': this.inputType === 'number' ? parseFloat(this.maxValue) : this.maxValue,
            'detectors': this.selectedDetectors,
            'fits': this.selectedFits
        });
    }
    changeDetectors(detectors) {
        this.selectedDetectors = detectors;
        if (!this.selectedDetectors) {
            this.selectedDetectors = [];
        }
    }
    changeFits(fits) {
        this.selectedFits = fits;
        if (!this.selectedFits) {
            this.selectedFits = [];
        }
    }
}
RangeFormComponent.ɵfac = function RangeFormComponent_Factory(t) { return new (t || RangeFormComponent)(); };
RangeFormComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: RangeFormComponent, selectors: [["wm-range-form"]], inputs: { key: "key", label: "label", database: "database", index: "index", queryDetectors: "queryDetectors", queryFits: "queryFits", inputType: "inputType" }, outputs: { onQuery: "query" }, decls: 13, vars: 8, consts: [["clrForm", "", 1, "inline-form"], ["clrInput", "", 3, "type", "ngModel", "ngModelChange"], [3, "database", "index", "onChange", 4, "ngIf"], [1, "btn", "btn-primary", 3, "click"], [3, "database", "index", "onChange"]], template: function RangeFormComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 0)(1, "clr-input-container")(2, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "input", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function RangeFormComponent_Template_input_ngModelChange_4_listener($event) { return ctx.minValue = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "clr-input-container")(6, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](8, "input", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function RangeFormComponent_Template_input_ngModelChange_8_listener($event) { return ctx.maxValue = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](9, RangeFormComponent_wm_detector_form_9_Template, 1, 2, "wm-detector-form", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](10, RangeFormComponent_wm_fit_form_10_Template, 1, 2, "wm-fit-form", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](11, "button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function RangeFormComponent_Template_button_click_11_listener() { return ctx.query(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](12, " Query ");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("Min ", ctx.label || ctx.key, ":");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("type", ctx.inputType)("ngModel", ctx.minValue);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtextInterpolate1"]("Max ", ctx.label || ctx.key, ":");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("type", ctx.inputType)("ngModel", ctx.maxValue);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.queryDetectors);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.queryFits);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.NgModel, _clr_angular__WEBPACK_IMPORTED_MODULE_5__.ClrLabel, _clr_angular__WEBPACK_IMPORTED_MODULE_5__.ClrForm, _clr_angular__WEBPACK_IMPORTED_MODULE_5__.ClrInput, _clr_angular__WEBPACK_IMPORTED_MODULE_5__.ClrInputContainer, _detector_form_detector_form_component__WEBPACK_IMPORTED_MODULE_0__.DetectorFormComponent, _fit_form_fit_form_component__WEBPACK_IMPORTED_MODULE_1__.FitFormComponent], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyYW5nZS1mb3JtLmNvbXBvbmVudC5jc3MifQ== */"] });


/***/ }),

/***/ 44466:
/*!*****************************************!*\
  !*** ./src/app/shared/shared.module.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SharedModule": () => (/* binding */ SharedModule)
/* harmony export */ });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @clr/angular */ 4151);
/* harmony import */ var _shtian_ng_pick_datetime__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @shtian/ng-pick-datetime */ 30532);
/* harmony import */ var _dynamic_form_dynamic_form_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dynamic-form/dynamic-form.module */ 28413);
/* harmony import */ var _widget_widget_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./widget/widget.component */ 81522);
/* harmony import */ var _widget_settings_settings_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./widget/settings/settings.component */ 87926);
/* harmony import */ var _quick_date_form_quick_date_form_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./quick-date-form/quick-date-form.component */ 94891);
/* harmony import */ var _date_range_form_date_range_form_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./date-range-form/date-range-form.component */ 63747);
/* harmony import */ var _range_form_range_form_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./range-form/range-form.component */ 2199);
/* harmony import */ var _delimited_form_delimited_form_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./delimited-form/delimited-form.component */ 5263);
/* harmony import */ var _fill_run_ls_form_fill_run_ls_form_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./fill-run-ls-form/fill-run-ls-form.component */ 49207);
/* harmony import */ var _string_plus_date_form_string_plus_date_form_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./string-plus-date-form/string-plus-date-form.component */ 37054);
/* harmony import */ var _dynamic_query_form_dynamic_query_form_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./dynamic-query-form/dynamic-query-form.component */ 6333);
/* harmony import */ var _detector_form_detector_form_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./detector-form/detector-form.component */ 73109);
/* harmony import */ var _fit_form_fit_form_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./fit-form/fit-form.component */ 55793);
/* harmony import */ var _detector_form_data_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./detector-form/data.service */ 61402);
/* harmony import */ var _fit_form_data_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./fit-form/data.service */ 79577);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 22560);



















class SharedModule {
}
SharedModule.ɵfac = function SharedModule_Factory(t) { return new (t || SharedModule)(); };
SharedModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineNgModule"]({ type: SharedModule });
SharedModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵdefineInjector"]({ providers: [_detector_form_data_service__WEBPACK_IMPORTED_MODULE_12__.DetectorFormService, _fit_form_data_service__WEBPACK_IMPORTED_MODULE_13__.FitFormService], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_15__.CommonModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_16__.FormsModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_16__.ReactiveFormsModule,
        _clr_angular__WEBPACK_IMPORTED_MODULE_17__.ClarityModule,
        _shtian_ng_pick_datetime__WEBPACK_IMPORTED_MODULE_18__.OwlNativeDateTimeModule,
        _shtian_ng_pick_datetime__WEBPACK_IMPORTED_MODULE_18__.OwlDateTimeModule,
        _dynamic_form_dynamic_form_module__WEBPACK_IMPORTED_MODULE_0__.DynamicFormModule, _angular_common__WEBPACK_IMPORTED_MODULE_15__.CommonModule,
        _clr_angular__WEBPACK_IMPORTED_MODULE_17__.ClarityModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_16__.FormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.ReactiveFormsModule,
        _shtian_ng_pick_datetime__WEBPACK_IMPORTED_MODULE_18__.OwlNativeDateTimeModule, _shtian_ng_pick_datetime__WEBPACK_IMPORTED_MODULE_18__.OwlDateTimeModule, _dynamic_form_dynamic_form_module__WEBPACK_IMPORTED_MODULE_0__.DynamicFormModule] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵsetNgModuleScope"](SharedModule, { declarations: [_widget_widget_component__WEBPACK_IMPORTED_MODULE_1__.WidgetComponent,
        _widget_settings_settings_component__WEBPACK_IMPORTED_MODULE_2__.SettingsComponent,
        _date_range_form_date_range_form_component__WEBPACK_IMPORTED_MODULE_4__.DateRangeFormComponent,
        _fill_run_ls_form_fill_run_ls_form_component__WEBPACK_IMPORTED_MODULE_7__.FillRunLsFormComponent,
        _range_form_range_form_component__WEBPACK_IMPORTED_MODULE_5__.RangeFormComponent,
        _delimited_form_delimited_form_component__WEBPACK_IMPORTED_MODULE_6__.DelimitedFormComponent,
        _quick_date_form_quick_date_form_component__WEBPACK_IMPORTED_MODULE_3__.QuickDateFormComponent,
        _string_plus_date_form_string_plus_date_form_component__WEBPACK_IMPORTED_MODULE_8__.StringPlusDateFormComponent,
        _dynamic_query_form_dynamic_query_form_component__WEBPACK_IMPORTED_MODULE_9__.DynamicQueryFormComponent,
        _detector_form_detector_form_component__WEBPACK_IMPORTED_MODULE_10__.DetectorFormComponent,
        _fit_form_fit_form_component__WEBPACK_IMPORTED_MODULE_11__.FitFormComponent], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_15__.CommonModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_16__.FormsModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_16__.ReactiveFormsModule,
        _clr_angular__WEBPACK_IMPORTED_MODULE_17__.ClarityModule,
        _shtian_ng_pick_datetime__WEBPACK_IMPORTED_MODULE_18__.OwlNativeDateTimeModule,
        _shtian_ng_pick_datetime__WEBPACK_IMPORTED_MODULE_18__.OwlDateTimeModule,
        _dynamic_form_dynamic_form_module__WEBPACK_IMPORTED_MODULE_0__.DynamicFormModule], exports: [_angular_common__WEBPACK_IMPORTED_MODULE_15__.CommonModule,
        _clr_angular__WEBPACK_IMPORTED_MODULE_17__.ClarityModule,
        _angular_forms__WEBPACK_IMPORTED_MODULE_16__.FormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_16__.ReactiveFormsModule,
        _shtian_ng_pick_datetime__WEBPACK_IMPORTED_MODULE_18__.OwlNativeDateTimeModule, _shtian_ng_pick_datetime__WEBPACK_IMPORTED_MODULE_18__.OwlDateTimeModule, _dynamic_form_dynamic_form_module__WEBPACK_IMPORTED_MODULE_0__.DynamicFormModule,
        _widget_widget_component__WEBPACK_IMPORTED_MODULE_1__.WidgetComponent, _date_range_form_date_range_form_component__WEBPACK_IMPORTED_MODULE_4__.DateRangeFormComponent, _fill_run_ls_form_fill_run_ls_form_component__WEBPACK_IMPORTED_MODULE_7__.FillRunLsFormComponent,
        _range_form_range_form_component__WEBPACK_IMPORTED_MODULE_5__.RangeFormComponent, _delimited_form_delimited_form_component__WEBPACK_IMPORTED_MODULE_6__.DelimitedFormComponent, _quick_date_form_quick_date_form_component__WEBPACK_IMPORTED_MODULE_3__.QuickDateFormComponent,
        _string_plus_date_form_string_plus_date_form_component__WEBPACK_IMPORTED_MODULE_8__.StringPlusDateFormComponent, _dynamic_query_form_dynamic_query_form_component__WEBPACK_IMPORTED_MODULE_9__.DynamicQueryFormComponent, _detector_form_detector_form_component__WEBPACK_IMPORTED_MODULE_10__.DetectorFormComponent,
        _fit_form_fit_form_component__WEBPACK_IMPORTED_MODULE_11__.FitFormComponent] }); })();


/***/ }),

/***/ 37054:
/*!*********************************************************************************!*\
  !*** ./src/app/shared/string-plus-date-form/string-plus-date-form.component.ts ***!
  \*********************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StringPlusDateFormComponent": () => (/* binding */ StringPlusDateFormComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var app_shared_timestamp_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! app/shared/timestamp-utils */ 38391);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @clr/angular */ 4151);
/* harmony import */ var _shtian_ng_pick_datetime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @shtian/ng-pick-datetime */ 30532);






class StringPlusDateFormComponent {
    constructor() {
        this.onQuery = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
    }
    ngOnInit() { }
    query() {
        let makeTSSec, makeTSMSec;
        if (this.utc) {
            makeTSSec = app_shared_timestamp_utils__WEBPACK_IMPORTED_MODULE_0__.makeUTCTimestampSec;
            makeTSMSec = app_shared_timestamp_utils__WEBPACK_IMPORTED_MODULE_0__.makeUTCTimestampMSec;
        }
        else {
            makeTSSec = app_shared_timestamp_utils__WEBPACK_IMPORTED_MODULE_0__.makeTimestampSec;
            makeTSMSec = app_shared_timestamp_utils__WEBPACK_IMPORTED_MODULE_0__.makeTimestampMSec;
        }
        this.onQuery.emit({
            'key': this.key,
            'text': this.textValue,
            'date': this.dateValue,
            'ts': makeTSSec(this.dateValue),
            'msec': makeTSMSec(this.dateValue),
            'dateStr': app_shared_timestamp_utils__WEBPACK_IMPORTED_MODULE_0__.makeISOWithoutMilliseconds(this.dateValue, this.utc),
            'utc': this.utc
        });
    }
}
StringPlusDateFormComponent.ɵfac = function StringPlusDateFormComponent_Factory(t) { return new (t || StringPlusDateFormComponent)(); };
StringPlusDateFormComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: StringPlusDateFormComponent, selectors: [["wm-string-plus-date-form"]], inputs: { key: "key", label: "label" }, outputs: { onQuery: "query" }, decls: 17, vars: 6, consts: [["clrForm", "", 1, "inline-form"], ["clrInput", "", "type", "text", 3, "ngModel", "ngModelChange"], ["clrInput", "", "type", "text", 3, "owlDateTimeTrigger", "owlDateTime", "ngModel", "ngModelChange"], ["dt", ""], ["type", "checkbox", "clrCheckbox", "", 3, "ngModel", "ngModelChange"], [1, "btn", "btn-primary", 3, "click"]], template: function StringPlusDateFormComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "clr-input-container")(2, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "input", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function StringPlusDateFormComponent_Template_input_ngModelChange_4_listener($event) { return ctx.textValue = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "clr-input-container")(6, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](7, "Date:");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "input", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function StringPlusDateFormComponent_Template_input_ngModelChange_8_listener($event) { return ctx.dateValue = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](9, "owl-date-time", null, 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "clr-checkbox-wrapper")(12, "input", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function StringPlusDateFormComponent_Template_input_ngModelChange_12_listener($event) { return ctx.utc = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](14, "UTC");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function StringPlusDateFormComponent_Template_button_click_15_listener() { return ctx.query(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](16, " Query ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    } if (rf & 2) {
        const _r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵreference"](10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"]("", ctx.label || ctx.key, ":");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.textValue);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("owlDateTimeTrigger", _r0)("owlDateTime", _r0)("ngModel", ctx.dateValue);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.utc);
    } }, dependencies: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.CheckboxControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.NgModel, _clr_angular__WEBPACK_IMPORTED_MODULE_3__.ClrLabel, _clr_angular__WEBPACK_IMPORTED_MODULE_3__.ClrForm, _clr_angular__WEBPACK_IMPORTED_MODULE_3__.ClrCheckbox, _clr_angular__WEBPACK_IMPORTED_MODULE_3__.ClrCheckboxWrapper, _clr_angular__WEBPACK_IMPORTED_MODULE_3__.ClrInput, _clr_angular__WEBPACK_IMPORTED_MODULE_3__.ClrInputContainer, _shtian_ng_pick_datetime__WEBPACK_IMPORTED_MODULE_4__.OwlDateTimeTriggerDirective, _shtian_ng_pick_datetime__WEBPACK_IMPORTED_MODULE_4__.OwlDateTimeInputDirective, _shtian_ng_pick_datetime__WEBPACK_IMPORTED_MODULE_4__.OwlDateTimeComponent], styles: [".inline-form[_ngcontent-%COMP%]    > clr-input-container[_ngcontent-%COMP%] {\r\n    padding-top: 0px;\r\n}\r\n\r\n.inline-form[_ngcontent-%COMP%]    > clr-checkbox-wrapper[_ngcontent-%COMP%]    > label[_ngcontent-%COMP%] {\r\n    padding-right: 1em;\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN0cmluZy1wbHVzLWRhdGUtZm9ybS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksZ0JBQWdCO0FBQ3BCOztBQUVBO0lBQ0ksa0JBQWtCO0FBQ3RCIiwiZmlsZSI6InN0cmluZy1wbHVzLWRhdGUtZm9ybS5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmlubGluZS1mb3JtID4gY2xyLWlucHV0LWNvbnRhaW5lciB7XHJcbiAgICBwYWRkaW5nLXRvcDogMHB4O1xyXG59XHJcblxyXG4uaW5saW5lLWZvcm0gPiBjbHItY2hlY2tib3gtd3JhcHBlciA+IGxhYmVsIHtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDFlbTtcclxufVxyXG4iXX0= */"] });


/***/ }),

/***/ 38391:
/*!*******************************************!*\
  !*** ./src/app/shared/timestamp-utils.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "makeISOWithoutMilliseconds": () => (/* binding */ makeISOWithoutMilliseconds),
/* harmony export */   "makeTimestampMSec": () => (/* binding */ makeTimestampMSec),
/* harmony export */   "makeTimestampSec": () => (/* binding */ makeTimestampSec),
/* harmony export */   "makeUTCTimestampMSec": () => (/* binding */ makeUTCTimestampMSec),
/* harmony export */   "makeUTCTimestampSec": () => (/* binding */ makeUTCTimestampSec)
/* harmony export */ });
function makeUTCTimestampMSec(date) {
    return date.getTime() - date.getTimezoneOffset() * 60000;
}
function makeTimestampMSec(date) {
    return date.getTime();
}
function makeUTCTimestampSec(date) {
    return Math.round((date.getTime() - date.getTimezoneOffset() * 60000) / 1000);
}
function makeTimestampSec(date) {
    return Math.round(date.getTime() / 1000);
}
function makeISOWithoutMilliseconds(date, utc) {
    if (utc) {
        date = new Date(makeUTCTimestampMSec(date));
    }
    return date.toISOString().split('.')[0] + 'Z';
}


/***/ }),

/***/ 87926:
/*!**************************************************************!*\
  !*** ./src/app/shared/widget/settings/settings.component.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SettingsComponent": () => (/* binding */ SettingsComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _core_timers_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../core/timers.service */ 75805);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @clr/angular */ 4151);






function SettingsComponent_option_11_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "option", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const timer_r1 = ctx.$implicit;
    const i_r2 = ctx.index;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngValue", timer_r1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate2"](" ", i_r2, ": ", timer_r1.interval, " seconds ");
} }
class SettingsComponent {
    constructor(timersService) {
        this.timersService = timersService;
        this.selectedTimerChange = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
        this.timers = [];
    }
    set timer(newTimer) {
        this._selectedTimer = newTimer;
    }
    set selectedTimer(newTimer) {
        this._selectedTimer = newTimer;
        this.selectedTimerChange.emit(newTimer);
    }
    get selectedTimer() {
        return this._selectedTimer;
    }
    ngOnInit() {
        this.timersSubscription = this.timersService.timers$.subscribe(timers => {
            this.timers = timers;
        });
    }
    ngOnDestroy() {
        this.timersSubscription.unsubscribe();
    }
}
SettingsComponent.ɵfac = function SettingsComponent_Factory(t) { return new (t || SettingsComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_core_timers_service__WEBPACK_IMPORTED_MODULE_0__.TimersService)); };
SettingsComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: SettingsComponent, selectors: [["wm-widget-general-settings"]], inputs: { config: "config", timer: "timer" }, outputs: { selectedTimerChange: "timerChange" }, decls: 12, vars: 5, consts: [[1, "form"], ["clrForm", "", 1, "form-block"], ["clrInput", "", "type", "text", 3, "ngModel", "ngModelChange"], ["clrSelect", "", 3, "ngModel", "disabled", "ngModelChange"], [3, "ngValue"], [3, "ngValue", 4, "ngFor", "ngForOf"]], template: function SettingsComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "div", 0)(1, "section", 1)(2, "clr-input-container")(3, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](4, "Title");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "input", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function SettingsComponent_Template_input_ngModelChange_5_listener($event) { return ctx.config.title = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "clr-select-container")(7, "label");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](8, "Timer");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "select", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function SettingsComponent_Template_select_ngModelChange_9_listener($event) { return ctx.selectedTimer = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "option", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](11, SettingsComponent_option_11_Template, 2, 3, "option", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()()()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.config.title);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.selectedTimer)("disabled", !ctx.config.startEnabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngValue", undefined);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx.timers);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgForOf, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgSelectOption, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵNgSelectMultipleOption"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__.DefaultValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.SelectControlValueAccessor, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgModel, _clr_angular__WEBPACK_IMPORTED_MODULE_4__.ClrLabel, _clr_angular__WEBPACK_IMPORTED_MODULE_4__.ClrForm, _clr_angular__WEBPACK_IMPORTED_MODULE_4__.ClrInput, _clr_angular__WEBPACK_IMPORTED_MODULE_4__.ClrInputContainer, _clr_angular__WEBPACK_IMPORTED_MODULE_4__.ClrSelect, _clr_angular__WEBPACK_IMPORTED_MODULE_4__.ClrSelectContainer], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzZXR0aW5ncy5jb21wb25lbnQuY3NzIn0= */"] });


/***/ }),

/***/ 81522:
/*!***************************************************!*\
  !*** ./src/app/shared/widget/widget.component.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WidgetComponent": () => (/* binding */ WidgetComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 80228);
/* harmony import */ var _core_timers_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../core/timers.service */ 75805);
/* harmony import */ var _core_event_bus_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../core/event-bus.service */ 40699);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _clr_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @clr/angular */ 4151);
/* harmony import */ var _dynamic_form_dynamic_form_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../dynamic-form/dynamic-form.component */ 36959);
/* harmony import */ var _settings_settings_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./settings/settings.component */ 87926);
/* harmony import */ var _dynamic_query_form_dynamic_query_form_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../dynamic-query-form/dynamic-query-form.component */ 6333);










function WidgetComponent_span_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const label_r6 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](label_r6.text);
} }
function WidgetComponent_div_4_button_2_Template(rf, ctx) { if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function WidgetComponent_div_4_button_2_Template_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r12); const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2); return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r11.onClickStart()); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "clr-icon");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵclassMap"](ctx_r7.timer ? ctx_r7.config.started ? "btn btn-success" : "btn btn-primary" : "btn disabled");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵattribute"]("shape", ctx_r7.timer && ctx_r7.config.started ? "stop" : "play");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx_r7.timer && ctx_r7.config.started ? "Stop" : "Start", " ");
} }
function WidgetComponent_div_4_button_3_Template(rf, ctx) { if (rf & 1) {
    const _r14 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "button", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function WidgetComponent_div_4_button_3_Template_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r14); const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2); return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r13.onClickRefresh()); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "clr-icon", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2, " Refresh ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} }
function WidgetComponent_div_4_button_4_Template(rf, ctx) { if (rf & 1) {
    const _r16 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "button", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function WidgetComponent_div_4_button_4_Template_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r16); const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2); return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r15.config.queriesOpen = !ctx_r15.config.queriesOpen); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "clr-icon", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2, " Queries ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("config.queries", ctx_r9.config.queriesOpen);
} }
function WidgetComponent_div_4_button_5_Template(rf, ctx) { if (rf & 1) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "button", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("click", function WidgetComponent_div_4_button_5_Template_button_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r18); const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2); return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r17.config.optionsOpen = !ctx_r17.config.optionsOpen); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelement"](1, "clr-icon", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2, " Options ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("config.queries", ctx_r10.config.optionsOpen);
} }
function WidgetComponent_div_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 11)(1, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, WidgetComponent_div_4_button_2_Template, 3, 4, "button", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](3, WidgetComponent_div_4_button_3_Template, 3, 0, "button", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](4, WidgetComponent_div_4_button_4_Template, 3, 1, "button", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](5, WidgetComponent_div_4_button_5_Template, 3, 1, "button", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r1.config.startEnabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r1.config.refreshEnabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r1.config.queriesEnabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r1.config.optionsEnabled);
} }
function WidgetComponent_div_5_span_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1, " timer: ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "code", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
} if (rf & 2) {
    const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"]("", ctx_r19.timer ? ctx_r19.timer.interval : "-", "s");
} }
function WidgetComponent_div_5_span_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](2, "code", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()();
} if (rf & 2) {
    const item_r21 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", item_r21[0], ": ");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate"](item_r21[1]);
} }
function WidgetComponent_div_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](1, WidgetComponent_div_5_span_1_Template, 4, 1, "span", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, WidgetComponent_div_5_span_2_Template, 4, 2, "span", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx_r2.config.startEnabled);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx_r2.infoItems);
} }
function WidgetComponent_div_7_wm_dynamic_query_form_2_Template(rf, ctx) { if (rf & 1) {
    const _r25 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "wm-dynamic-query-form", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("query", function WidgetComponent_div_7_wm_dynamic_query_form_2_Template_wm_dynamic_query_form_query_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r25); const ctx_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](2); return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r24.extraQueriesEvents.next($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const q_r23 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("component", q_r23.component)("config", q_r23.config);
} }
function WidgetComponent_div_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵprojection"](1, 1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](2, WidgetComponent_div_7_wm_dynamic_query_form_2_Template, 1, 2, "wm-dynamic-query-form", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("hidden", !ctx_r3.config.queriesOpen);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx_r3.extraQueries);
} }
function WidgetComponent_div_10_clr_alert_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "clr-alert", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const l_r27 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("clrAlertType", l_r27.level)("clrAlertClosable", false);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", l_r27.text, " ");
} }
function WidgetComponent_div_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](1, WidgetComponent_div_10_clr_alert_1_Template, 2, 3, "clr-alert", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx_r4.logs);
} }
function WidgetComponent_clr_modal_11_Template(rf, ctx) { if (rf & 1) {
    const _r29 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "clr-modal", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("clrModalOpenChange", function WidgetComponent_clr_modal_11_Template_clr_modal_clrModalOpenChange_0_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r29); const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r28.config.optionsOpen = $event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](1, "h3", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2, "Widget options");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](3, "div", 34)(4, "clr-tabs")(5, "clr-tab")(6, "button", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](7, "General");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](8, "clr-tab-content")(9, "wm-widget-general-settings", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("timerChange", function WidgetComponent_clr_modal_11_Template_wm_widget_general_settings_timerChange_9_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r29); const ctx_r30 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r30.timer = $event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](10, "clr-tab")(11, "button", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](12, "Widget");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](13, "clr-tab-content");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵprojection"](14, 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](15, "wm-dynamic-form", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵlistener"]("modelChange", function WidgetComponent_clr_modal_11_Template_wm_dynamic_form_modelChange_15_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵrestoreView"](_r29); const ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵresetView"](ctx_r31.extraOptionsModelChange.next($event)); });
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]()()()()()();
} if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("clrModalOpen", ctx_r5.config.optionsOpen)("clrModalSize", "md");
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("config", ctx_r5.config)("timer", ctx_r5.timer);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("formFields", ctx_r5.extraOptions)("model", ctx_r5.extraOptionsModel);
} }
const _c0 = [[["", 8, "widget-content"]], [["", 8, "widget-queries"]], [["", 8, "widget-options"]]];
const _c1 = [".widget-content", ".widget-queries", ".widget-options"];
class WidgetComponent {
    constructor(timers, changeDetector, eventBus) {
        this.timers = timers;
        this.changeDetector = changeDetector;
        this.eventBus = eventBus;
        this.extraQueries = null;
        this.extraQueriesEvents = new rxjs__WEBPACK_IMPORTED_MODULE_6__.Subject();
        this.extraOptions = null;
        this.extraOptionsModel = {};
        this.extraOptionsModelChange = new rxjs__WEBPACK_IMPORTED_MODULE_6__.Subject();
        this._config = {};
        this.infoItems = [];
        this.startEmmiter = new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter(true);
        this.stopEmmiter = new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter(true);
        this.timerEmmiter = new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter(true);
        this.refreshEmmiter = new _angular_core__WEBPACK_IMPORTED_MODULE_5__.EventEmitter(true);
        this.labels = [];
        this.logs = [];
    }
    set config(newConfig) {
        this._config = this.parseConfig(newConfig);
    }
    get config() {
        return this._config;
    }
    set info(newInfo) {
        newInfo = newInfo || {};
        this.infoItems = Object.keys(newInfo).map(key => {
            return [key, newInfo[key]];
        });
    }
    set timer(newTimer) {
        this.stop();
        this._timer = newTimer;
        this.changeDetector.detectChanges();
    }
    get timer() {
        return this._timer;
    }
    ngOnInit() {
        const initiallyStarted = this.config.started;
        this.timersSubscription = this.timers.timers$.subscribe(newTimers => {
            if (this.timer && newTimers.indexOf(this.timer) < 0) {
                this.timer = undefined;
            }
            this.changeDetector.detectChanges();
        });
        if (Number.isInteger(this.config.initialTimer)) {
            try {
                this.timer = this.timers.getTimers()[this.config.initialTimer];
            }
            catch { }
        }
        if (initiallyStarted) {
            this.start();
        }
        this.eventsSubscription = this.eventBus.getEvents(0, 'global_startstop')
            .subscribe(this.handle_global_startstop.bind(this));
    }
    ngOnDestroy() {
        this.makeStop();
        this.extraQueriesEvents.complete();
        this.extraOptionsModelChange.complete();
        if (this.eventsSubscription) {
            this.eventsSubscription.unsubscribe();
        }
        if (this.timersSubscription) {
            this.timersSubscription.unsubscribe();
        }
    }
    onClickStart() {
        if (this.config.started) {
            this.stop();
        }
        else {
            this.start();
        }
    }
    onClickRefresh() {
        this.stop();
        this.refreshEmmiter.emit();
    }
    start() {
        if (!this.config.started) {
            if (this.makeStart()) {
                this.config.started = true;
                this.startEmmiter.emit();
            }
        }
        this.changeDetector.detectChanges();
    }
    stop() {
        if (this.config.started) {
            this.makeStop();
            this.config.started = false;
            this.stopEmmiter.emit();
        }
        this.changeDetector.detectChanges();
    }
    addLabel(text) {
        const newLabel = { id: (new Date()).getTime(), text: text };
        this.labels.push(newLabel);
        return newLabel;
    }
    removeLabel(label) {
        const index = this.labels.indexOf(label);
        if (index >= 0) {
            this.labels.splice(index, 1);
        }
    }
    log(text, level = 'info', timeout) {
        const logEvent = {
            text: text,
            level: level
        };
        if (!timeout) {
            if (level === 'info') {
                timeout = 2000;
            }
            else if (level === 'warning') {
                timeout = 3500;
            }
            else {
                timeout = 5000;
            }
        }
        this.logs.push(logEvent);
        setTimeout(() => {
            const index = this.logs.indexOf(logEvent);
            if (index > -1) {
                this.logs.splice(index, 1);
            }
            this.changeDetector.detectChanges();
        }, timeout);
        this.changeDetector.detectChanges();
    }
    clearLogs() {
        this.logs.length = 0;
    }
    makeStart() {
        if (this._timer) {
            this.makeStop();
            this.timerSubscription = this._timer.subscribe(() => {
                this.timerEmmiter.emit();
                this.changeDetector.detectChanges();
            }, err => {
                this.changeDetector.detectChanges();
            }, () => {
                this.stop();
                this._timer = undefined;
                this.changeDetector.detectChanges();
            });
            return true;
        }
        return false;
    }
    makeStop() {
        if (this.timerSubscription) {
            this.timerSubscription.unsubscribe();
            this.timerSubscription = undefined;
        }
        return true;
    }
    parseConfig(config) {
        config = config || {};
        const defaults = {
            title: '',
            startEnabled: true,
            started: false,
            refreshEnabled: true,
            optionsEnabled: true,
            optionsOpen: false,
            queryDetectors: false,
            queryFits: false,
            queriesEnabled: true,
            queriesOpen: false,
            initialTimer: null
        };
        Object.keys(defaults).forEach(key => {
            config[key] = config.hasOwnProperty(key) ? config[key] : defaults[key];
        });
        return config;
    }
    handle_global_startstop(event) {
        if (event.payload === 'start') {
            this.start();
        }
        else if (event.payload === 'stop') {
            this.stop();
        }
        this.changeDetector.detectChanges();
    }
}
WidgetComponent.ɵfac = function WidgetComponent_Factory(t) { return new (t || WidgetComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_core_timers_service__WEBPACK_IMPORTED_MODULE_0__.TimersService), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_5__.ChangeDetectorRef), _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdirectiveInject"](_core_event_bus_service__WEBPACK_IMPORTED_MODULE_1__.EventBusService)); };
WidgetComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineComponent"]({ type: WidgetComponent, selectors: [["wm-widget"]], inputs: { config: "config", info: "info" }, outputs: { startEmmiter: "start", stopEmmiter: "stop", timerEmmiter: "timer", refreshEmmiter: "refresh" }, ngContentSelectors: _c1, decls: 12, vars: 8, consts: [[1, "widget"], [1, "title", 3, "hidden"], ["class", "label title-label", 4, "ngFor", "ngForOf"], ["class", "controls", 4, "ngIf"], ["class", "info", 4, "ngIf"], [1, "queries-wrapper"], ["class", "queries", 3, "hidden", 4, "ngIf"], [1, "content"], ["class", "logs", 4, "ngIf"], [3, "clrModalOpen", "clrModalSize", "clrModalOpenChange", 4, "ngIf"], [1, "label", "title-label"], [1, "controls"], [1, "btn-group", "btn-sm"], [3, "class", "click", 4, "ngIf"], ["class", "btn", 3, "click", 4, "ngIf"], ["class", "btn", 3, "config.queries", "click", 4, "ngIf"], [3, "click"], [1, "btn", 3, "click"], ["shape", "refresh"], [1, "btn", 3, "config.queries", "click"], ["shape", "search"], ["shape", "cog"], [1, "info"], [4, "ngIf"], [4, "ngFor", "ngForOf"], [1, "clr-code"], [1, "queries", 3, "hidden"], [3, "component", "config", "query", 4, "ngFor", "ngForOf"], [3, "component", "config", "query"], [1, "logs"], [3, "clrAlertType", "clrAlertClosable", 4, "ngFor", "ngForOf"], [3, "clrAlertType", "clrAlertClosable"], [3, "clrModalOpen", "clrModalSize", "clrModalOpenChange"], [1, "modal-title"], [1, "modal-body", 2, "height", "500px"], ["clrTabLink", ""], [3, "config", "timer", "timerChange"], [3, "formFields", "model", "modelChange"]], template: function WidgetComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵprojectionDef"](_c0);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](0, "div", 0)(1, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtext"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](3, WidgetComponent_span_3_Template, 2, 1, "span", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](4, WidgetComponent_div_4_Template, 6, 4, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](5, WidgetComponent_div_5_Template, 3, 2, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](6, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](7, WidgetComponent_div_7_Template, 3, 2, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementStart"](8, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵprojection"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](10, WidgetComponent_div_10_Template, 2, 1, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtemplate"](11, WidgetComponent_clr_modal_11_Template, 16, 6, "clr-modal", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("hidden", !ctx.config.title);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵtextInterpolate1"](" ", ctx.config.title, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngForOf", ctx.labels);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.config.controlsEnabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.config.infoEnabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.config.queriesEnabled);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.logs.length);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵproperty"]("ngIf", ctx.config.optionsEnabled);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _clr_angular__WEBPACK_IMPORTED_MODULE_8__.ClrAlert, _clr_angular__WEBPACK_IMPORTED_MODULE_8__.ClrIconCustomTag, _clr_angular__WEBPACK_IMPORTED_MODULE_8__.ClrModal, _clr_angular__WEBPACK_IMPORTED_MODULE_8__.ClrModalBody, _clr_angular__WEBPACK_IMPORTED_MODULE_8__.ClrTabContent, _clr_angular__WEBPACK_IMPORTED_MODULE_8__.ClrTab, _clr_angular__WEBPACK_IMPORTED_MODULE_8__.ClrTabs, _clr_angular__WEBPACK_IMPORTED_MODULE_8__.ClrTabLink, _clr_angular__WEBPACK_IMPORTED_MODULE_8__["ÇlrTabsWillyWonka"], _clr_angular__WEBPACK_IMPORTED_MODULE_8__["ÇlrActiveOompaLoompa"], _dynamic_form_dynamic_form_component__WEBPACK_IMPORTED_MODULE_2__.DynamicFormComponent, _settings_settings_component__WEBPACK_IMPORTED_MODULE_3__.SettingsComponent, _dynamic_query_form_dynamic_query_form_component__WEBPACK_IMPORTED_MODULE_4__.DynamicQueryFormComponent], styles: [".title[_ngcontent-%COMP%] {\r\n    padding: 0px 12px 0px 36px;\r\n    width: 100%;\r\n    max-width: 100%;\r\n    overflow: hidden;\r\n    text-align: left;\r\n    font-size: 14px;\r\n    line-height: 1em;\r\n    height: 1.1em;\r\n    min-height: 1.1em;\r\n    font-weight: bold;\r\n    background-color: #f0f0f0;\r\n    box-shadow: 0px 3px 6px -3px gray;\r\n    z-index: 1;\r\n}\r\n\r\n.title-label[_ngcontent-%COMP%] {\r\n    float: right;\r\n    height: 14px;\r\n    margin-top: 1px;\r\n}\r\n\r\n.widget[_ngcontent-%COMP%] {\r\n    display: flex;\r\n    flex-direction: column;\r\n    overflow: hidden;\r\n    border: 1px solid silver;\r\n    max-height: 100%;\r\n    height: 100%;\r\n    max-width: 100%;\r\n    width: 100%;\r\n    position: relative;\r\n    background-color: white;\r\n}\r\n\r\n.controls[_ngcontent-%COMP%] {\r\n    padding: 0px 12px;\r\n    background-color: #f0f0f0;\r\n    \r\n    box-shadow: 0px 3px 6px -3px gray;\r\n    z-index: 2;\r\n}\r\n\r\n.controls[_ngcontent-%COMP%]   .btn[_ngcontent-%COMP%] {\r\n    \r\n    line-height: 1rem;\r\n}\r\n\r\n.info[_ngcontent-%COMP%] {\r\n    text-align: center;\r\n    font-size: 11px;\r\n    background-color: #f0f0f0;\r\n    max-height: 2em;\r\n    line-height: 2em;\r\n    overflow: hidden;\r\n    \r\n    box-shadow: 0px 3px 6px -3px gray;\r\n    z-index: 3;\r\n}\r\n\r\n.queries[_ngcontent-%COMP%] {\r\n    \r\n    box-shadow: 0px 3px 6px -3px gray;\r\n    background-color: #f0f0f0;\r\n    border-top: 1px dashed gray;\r\n    position: absolute;\r\n    left: 0;\r\n    width: 100%;\r\n    overflow: auto;\r\n    z-index: 4;\r\n}\r\n\r\n.queries-wrapper[_ngcontent-%COMP%] {\r\n    position: relative;\r\n    height: 0;\r\n    width: 100%;\r\n    overflow: visible;\r\n}\r\n\r\n.content[_ngcontent-%COMP%] {\r\n    width: 100%;\r\n    height: 100%;\r\n    overflow: auto;\r\n}\r\n\r\n.logs[_ngcontent-%COMP%] {\r\n    z-index: 5;\r\n    background-color: whitesmoke;\r\n    opacity: 0.9;\r\n    position: absolute;\r\n    padding: 24px;\r\n    bottom: 0;\r\n    left: 8%;\r\n    width: 84%;\r\n    height: 100%;\r\n    box-shadow: 0px 3px 6px -3px gray;\r\n}\r\n\r\n.log[_ngcontent-%COMP%] {\r\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndpZGdldC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksMEJBQTBCO0lBQzFCLFdBQVc7SUFDWCxlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLGdCQUFnQjtJQUNoQixlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLGFBQWE7SUFDYixpQkFBaUI7SUFDakIsaUJBQWlCO0lBQ2pCLHlCQUF5QjtJQUN6QixpQ0FBaUM7SUFDakMsVUFBVTtBQUNkOztBQUVBO0lBQ0ksWUFBWTtJQUNaLFlBQVk7SUFDWixlQUFlO0FBQ25COztBQUVBO0lBQ0ksYUFBYTtJQUNiLHNCQUFzQjtJQUN0QixnQkFBZ0I7SUFDaEIsd0JBQXdCO0lBQ3hCLGdCQUFnQjtJQUNoQixZQUFZO0lBQ1osZUFBZTtJQUNmLFdBQVc7SUFDWCxrQkFBa0I7SUFDbEIsdUJBQXVCO0FBQzNCOztBQUVBO0lBQ0ksaUJBQWlCO0lBQ2pCLHlCQUF5QjtJQUN6Qix1Q0FBdUM7SUFDdkMsaUNBQWlDO0lBQ2pDLFVBQVU7QUFDZDs7QUFFQTtJQUNJLCtEQUErRDtJQUMvRCxpQkFBaUI7QUFDckI7O0FBRUE7SUFDSSxrQkFBa0I7SUFDbEIsZUFBZTtJQUNmLHlCQUF5QjtJQUN6QixlQUFlO0lBQ2YsZ0JBQWdCO0lBQ2hCLGdCQUFnQjtJQUNoQix1Q0FBdUM7SUFDdkMsaUNBQWlDO0lBQ2pDLFVBQVU7QUFDZDs7QUFFQTtJQUNJLHVDQUF1QztJQUN2QyxpQ0FBaUM7SUFDakMseUJBQXlCO0lBQ3pCLDJCQUEyQjtJQUMzQixrQkFBa0I7SUFDbEIsT0FBTztJQUNQLFdBQVc7SUFDWCxjQUFjO0lBQ2QsVUFBVTtBQUNkOztBQUVBO0lBQ0ksa0JBQWtCO0lBQ2xCLFNBQVM7SUFDVCxXQUFXO0lBQ1gsaUJBQWlCO0FBQ3JCOztBQUVBO0lBQ0ksV0FBVztJQUNYLFlBQVk7SUFDWixjQUFjO0FBQ2xCOztBQUVBO0lBQ0ksVUFBVTtJQUNWLDRCQUE0QjtJQUM1QixZQUFZO0lBQ1osa0JBQWtCO0lBQ2xCLGFBQWE7SUFDYixTQUFTO0lBQ1QsUUFBUTtJQUNSLFVBQVU7SUFDVixZQUFZO0lBQ1osaUNBQWlDO0FBQ3JDOztBQUVBO0FBQ0EiLCJmaWxlIjoid2lkZ2V0LmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudGl0bGUge1xyXG4gICAgcGFkZGluZzogMHB4IDEycHggMHB4IDM2cHg7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIG1heC13aWR0aDogMTAwJTtcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDFlbTtcclxuICAgIGhlaWdodDogMS4xZW07XHJcbiAgICBtaW4taGVpZ2h0OiAxLjFlbTtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2YwZjBmMDtcclxuICAgIGJveC1zaGFkb3c6IDBweCAzcHggNnB4IC0zcHggZ3JheTtcclxuICAgIHotaW5kZXg6IDE7XHJcbn1cclxuXHJcbi50aXRsZS1sYWJlbCB7XHJcbiAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICBoZWlnaHQ6IDE0cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAxcHg7XHJcbn1cclxuXHJcbi53aWRnZXQge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgc2lsdmVyO1xyXG4gICAgbWF4LWhlaWdodDogMTAwJTtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIG1heC13aWR0aDogMTAwJTtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbn1cclxuXHJcbi5jb250cm9scyB7XHJcbiAgICBwYWRkaW5nOiAwcHggMTJweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNmMGYwZjA7XHJcbiAgICAvKiBib3gtc2hhZG93OiAwcHggNnB4IDZweCAtNnB4IGdyYXk7ICovXHJcbiAgICBib3gtc2hhZG93OiAwcHggM3B4IDZweCAtM3B4IGdyYXk7XHJcbiAgICB6LWluZGV4OiAyO1xyXG59XHJcblxyXG4uY29udHJvbHMgLmJ0biB7XHJcbiAgICAvKiBmaXggZm9yIG9sZCBicm93c2VycyB3aGVuIGNhbGMoMXJlbSAtMXB4KSBpcyBub3Qgc3VwcG9ydGVkICovXHJcbiAgICBsaW5lLWhlaWdodDogMXJlbTtcclxufVxyXG5cclxuLmluZm8ge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgZm9udC1zaXplOiAxMXB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2YwZjBmMDtcclxuICAgIG1heC1oZWlnaHQ6IDJlbTtcclxuICAgIGxpbmUtaGVpZ2h0OiAyZW07XHJcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgLyogYm94LXNoYWRvdzogMHB4IDZweCA2cHggLTZweCBncmF5OyAqL1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDNweCA2cHggLTNweCBncmF5O1xyXG4gICAgei1pbmRleDogMztcclxufVxyXG5cclxuLnF1ZXJpZXMge1xyXG4gICAgLyogYm94LXNoYWRvdzogMHB4IDZweCA2cHggLTZweCBncmF5OyAqL1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDNweCA2cHggLTNweCBncmF5O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2YwZjBmMDtcclxuICAgIGJvcmRlci10b3A6IDFweCBkYXNoZWQgZ3JheTtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGxlZnQ6IDA7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIG92ZXJmbG93OiBhdXRvO1xyXG4gICAgei1pbmRleDogNDtcclxufVxyXG5cclxuLnF1ZXJpZXMtd3JhcHBlciB7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBoZWlnaHQ6IDA7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIG92ZXJmbG93OiB2aXNpYmxlO1xyXG59XHJcblxyXG4uY29udGVudCB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIG92ZXJmbG93OiBhdXRvO1xyXG59XHJcblxyXG4ubG9ncyB7XHJcbiAgICB6LWluZGV4OiA1O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGVzbW9rZTtcclxuICAgIG9wYWNpdHk6IDAuOTtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHBhZGRpbmc6IDI0cHg7XHJcbiAgICBib3R0b206IDA7XHJcbiAgICBsZWZ0OiA4JTtcclxuICAgIHdpZHRoOiA4NCU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICBib3gtc2hhZG93OiAwcHggM3B4IDZweCAtM3B4IGdyYXk7XHJcbn1cclxuXHJcbi5sb2cge1xyXG59XHJcbiJdfQ== */"], changeDetection: 0 });


/***/ }),

/***/ 36214:
/*!***************************************************!*\
  !*** ./src/app/widgets/widget-module-selector.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "widgetModuleSelector": () => (/* binding */ widgetModuleSelector)
/* harmony export */ });
// This object contains the path to the module and the module name for each widget name
const widgetModuleSelector = {
    'static-label': ['app/widgets/static-label-widget/static-label-widget.module', 'StaticLabelWidgetModule'],
    'label': ['app/widgets/label-widget/label-widget.module', 'LabelWidgetModule'],
    'time-query': ['app/widgets/time-query-widget/time-query-widget.module', 'TimeQueryWidgetModule'],
    'range-query': ['app/widgets/range-query/range-query.module', 'RangeQueryModule'],
    'fill-run-ls-query': ['app/widgets/fill-run-ls-query-widget/fill-run-ls-query-widget.module', 'FillRunLsQueryWidgetModule'],
    'event-bus-tester': ['app/widgets/event-bus-test-widget/event-bus-test-widget.module', 'EventBusTestWidgetModule'],
    'numeric-field': ['app/widgets/numeric-field/numeric-field.module', 'NumericFieldModule'],
    'array-snapshot': ['app/widgets/array-snapshot/array-snapshot.module', 'ArraySnapshotModule'],
    'array-lines': ['app/widgets/array-field/array-lines.module', 'ArrayLinesModule'],
    'array-lines-basicx': ['app/widgets/array-field/array-lines-basicx.module', 'ArrayLinesBasicXModule'],
    'array-heatmap': ['app/widgets/array-field/array-heatmap.module', 'ArrayHeatmapModule'],
    'numeric-field-with-ratios': ['app/widgets/numeric-field-with-ratios/numeric-field-with-ratios.module', 'NumericFieldWithRatiosModule'],
    'pileup': ['app/widgets/pileup/pileup.module', 'PileupModule'],
    'images': ['app/widgets/binary-images/binary-images.module', 'BinaryImagesModule'],
    'dynamic-form-test': ['app/widgets/dynamic-form-test/dynamic-form-test.module', 'DynamicFormTestModule'],
    'numeric-field-split': ['app/widgets/numeric-field-split/numeric-field-split.module', 'NumericFieldSplitModule'],
    'vdm-bx': ['app/widgets/vdm-bx/vdm-bx.module', 'VDMBXModule'],
    'string-plus-date-query': ['app/widgets/string-plus-date-query/string-plus-date-query.module', 'StringPlusDateQueryModule'],
};


/***/ }),

/***/ 50546:
/*!*******************************************!*\
  !*** ./src/app/widgets/widgets.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "WidgetsModule": () => (/* binding */ WidgetsModule)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 22560);

class WidgetsModule {
}
WidgetsModule.ɵfac = function WidgetsModule_Factory(t) { return new (t || WidgetsModule)(); };
WidgetsModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: WidgetsModule });
WidgetsModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({});


/***/ }),

/***/ 92340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment)
/* harmony export */ });
// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.
const environment = {
    production: false
};


/***/ }),

/***/ 14431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ 34497);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 36747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 92340);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
_angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__.platformBrowser().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule);
// console.trace = function() {};


/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(14431)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map